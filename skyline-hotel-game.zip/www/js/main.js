import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

/* ============================================================
   SKYLINE HOTEL – 10 FLOORS
   Brighter atmosphere + monsters with counters
   ============================================================ */

const CONFIG = {
  floors: 10,
  floorHeight: 4.5,
  corridorWidth: 7,
  corridorLength: 32,
  playerHeight: 1.7,
  playerSpeed: 5.2
};

let scene, camera, renderer, controls;
let currentFloor = 1;
let partsCollected = 0;
const TOTAL_PARTS = 10;
let move = { f: false, b: false, l: false, r: false };
let isMobile = false;
let joy = { x: 0, y: 0 };
let lookD = { x: 0, y: 0 };
let interactables = [];
let monsters = [];
let elevators = []; // {floor, side, doorL, doorR, group, zone}
let insideElevator = false;
let elevPromptShown = false;
let ridingElevator = false;
let rideTimer = 0;
let ridePhase = null; // closing | moving | opening
let rideTarget = null;
let parts = [];
let clock = new THREE.Clock();
let raycaster = new THREE.Raycaster();
let elevatorOpen = false;
let gameOver = false;
let holdingItem = null; // for toy / meat
let stunCooldown = 0;   // seconds remaining before stun can be used again
let stunActive = 0;     // seconds remaining of current stun

// DOM
const loadingEl = document.getElementById('loading');
const progressEl = document.getElementById('progress');
const hud = document.getElementById('hud');
const floorInd = document.getElementById('floor-indicator');
const partsEl = document.getElementById('parts');
const mobileControls = document.getElementById('mobile-controls');
const dialogue = document.getElementById('dialogue');
const npcNameEl = document.getElementById('npc-name');
const npcTextEl = document.getElementById('npc-text');
const winScreen = document.getElementById('win-screen');
const elevatorUI = document.getElementById('elevator-ui');
const msgEl = document.getElementById('msg');
const stunBtn = document.getElementById('stun-btn');
const stunCdEl = document.getElementById('stun-cd');

function showMsg(text, time = 3000) {
  msgEl.textContent = text;
  msgEl.classList.remove('hidden');
  setTimeout(() => msgEl.classList.add('hidden'), time);
}

async function init() {
  // MOBILE ONLY game
  isMobile = true;

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x4a4a5e);
  scene.fog = new THREE.FogExp2(0x4a4a5e, 0.006);

  camera = new THREE.PerspectiveCamera(72, innerWidth / innerHeight, 0.1, 90);
  camera.position.set(0, CONFIG.playerHeight, 12);
  camera.rotation.order = 'YXZ';

  renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setSize(innerWidth, innerHeight);
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  document.body.appendChild(renderer.domElement);

  // Bright clear lighting
  scene.add(new THREE.AmbientLight(0xffffff, 1.25));
  scene.add(new THREE.HemisphereLight(0xffffff, 0x9999bb, 1.05));
  const dir = new THREE.DirectionalLight(0xfffaf5, 1.0);
  dir.position.set(8, 22, 12);
  scene.add(dir);

  buildHotel();
  placeParts();
  placeMonsters();
  placeNPCs();

  setupMobile();
  setupKeys();
  setupUI();

  progressEl.style.width = '100%';
  setTimeout(() => {
    loadingEl.classList.add('hidden');
    hud.classList.remove('hidden');
    mobileControls.classList.remove('hidden');
  }, 700);

  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });

  animate();
}

/* -------------------- HOTEL -------------------- */
function buildHotel() {
  const wallMat = new THREE.MeshStandardMaterial({ color: 0x6a5e52, roughness: 0.75 });
  const floorMat = new THREE.MeshStandardMaterial({ color: 0x5a4e42, roughness: 0.85 });
  const ceilMat  = new THREE.MeshStandardMaterial({ color: 0x4a423a, roughness: 0.9 });
  const carpetMat = new THREE.MeshStandardMaterial({ color: 0x8a3a3a, roughness: 0.9 });
  const goldMat = new THREE.MeshStandardMaterial({ color: 0xd4a84b, metalness: 0.5, roughness: 0.35 });

  for (let f = 1; f <= CONFIG.floors; f++) {
    const y = (f - 1) * CONFIG.floorHeight;
    const g = new THREE.Group();
    g.position.y = y;

    // Floor
    const slab = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength + 18, 0.3, CONFIG.corridorWidth + 10),
      floorMat
    );
    slab.position.y = -0.15;
    slab.receiveShadow = true;
    g.add(slab);

    // Carpet
    const carpet = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength - 1, 0.02, 2.4),
      carpetMat
    );
    carpet.position.y = 0.01;
    g.add(carpet);

    // Ceiling
    const ceil = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength + 18, 0.2, CONFIG.corridorWidth + 10),
      ceilMat
    );
    ceil.position.y = CONFIG.floorHeight - 0.1;
    g.add(ceil);

    // Walls
    const h = CONFIG.floorHeight - 0.3;
    const long = new THREE.BoxGeometry(CONFIG.corridorLength + 2, h, 0.35);
    const n = new THREE.Mesh(long, wallMat); n.position.set(0, h/2, -CONFIG.corridorWidth/2); g.add(n);
    const s = new THREE.Mesh(long, wallMat); s.position.set(0, h/2,  CONFIG.corridorWidth/2); g.add(s);

    const end = new THREE.BoxGeometry(0.35, h, CONFIG.corridorWidth + 1);
    const e = new THREE.Mesh(end, wallMat); e.position.set( CONFIG.corridorLength/2 + 0.4, h/2, 0); g.add(e);
    const w = new THREE.Mesh(end, wallMat); w.position.set(-CONFIG.corridorLength/2 - 0.4, h/2, 0); g.add(w);

    // Room doors visual
    for (let i = -3; i <= 3; i++) {
      if (i === 0) continue;
      const door = new THREE.Mesh(
        new THREE.BoxGeometry(1.5, 2.5, 0.12),
        new THREE.MeshStandardMaterial({ color: 0x4a3525 })
      );
      door.position.set(i * 4.5, 1.25, i > 0 ? CONFIG.corridorWidth/2 - 0.1 : -CONFIG.corridorWidth/2 + 0.1);
      g.add(door);
    }

    // No small lamps – global bright lighting only

    // Elevator doors both ends
    createElevator(g,  CONFIG.corridorLength/2 - 0.3, f);
    createElevator(g, -CONFIG.corridorLength/2 + 0.3, f);



    // Floor number
    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 64;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#222'; ctx.fillRect(0,0,128,64);
    ctx.fillStyle = '#d4a84b'; ctx.font = 'bold 36px system-ui';
    ctx.textAlign = 'center'; ctx.fillText('F' + f, 64, 44);
    const tex = new THREE.CanvasTexture(canvas);
    const label = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.7), new THREE.MeshBasicMaterial({ map: tex }));
    label.position.set(0, 2.4, -CONFIG.corridorWidth/2 + 0.2);
    g.add(label);

    scene.add(g);
  }

  // Roof + helicopter
  const roofY = CONFIG.floors * CONFIG.floorHeight;
  const roof = new THREE.Group();
  roof.position.y = roofY;

  const roofSlab = new THREE.Mesh(
    new THREE.BoxGeometry(42, 0.4, 32),
    new THREE.MeshStandardMaterial({ color: 0x333333 })
  );
  roofSlab.position.y = 0.2;
  roof.add(roofSlab);

  const pad = new THREE.Mesh(
    new THREE.CylinderGeometry(6, 6, 0.15, 32),
    new THREE.MeshStandardMaterial({ color: 0x222222 })
  );
  pad.position.y = 0.35;
  roof.add(pad);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(4.5, 5, 32),
    new THREE.MeshBasicMaterial({ color: 0xd4a84b, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI/2;
  ring.position.y = 0.43;
  roof.add(ring);

  const heli = createHelicopter();
  heli.position.set(0, 1.9, 0);
  roof.add(heli);

  const rl = new THREE.PointLight(0xffffff, 1.4, 30);
  rl.position.set(0, 7, 0);
  roof.add(rl);

  scene.add(roof);
}




function createElevator(parent, x, floorNum) {
  // Real wall elevator cabin at corridor end
  const side = x > 0 ? 1 : -1;
  const group = new THREE.Group();
  group.position.set(x, 0, 0);

  const metal = new THREE.MeshStandardMaterial({ color: 0x6a6a72, metalness: 0.85, roughness: 0.25 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x1a1a20, metalness: 0.4, roughness: 0.5 });
  const brushed = new THREE.MeshStandardMaterial({ color: 0x9a9aa2, metalness: 0.7, roughness: 0.3 });
  const gold = new THREE.MeshStandardMaterial({ color: 0xd4a84b, emissive: 0x5a3a10, emissiveIntensity: 0.4, metalness: 0.5, roughness: 0.35 });

  // Deep cabin box (walk inside)
  const cabinW = 2.2;
  const cabinD = 2.0;
  // back wall
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.12, 2.8, cabinW), brushed);
  back.position.set(-side * cabinD, 1.4, 0);
  group.add(back);
  // left / right cabin walls
  const sideWall1 = new THREE.Mesh(new THREE.BoxGeometry(cabinD, 2.8, 0.12), brushed);
  sideWall1.position.set(-side * cabinD * 0.5, 1.4, cabinW * 0.5);
  group.add(sideWall1);
  const sideWall2 = new THREE.Mesh(new THREE.BoxGeometry(cabinD, 2.8, 0.12), brushed);
  sideWall2.position.set(-side * cabinD * 0.5, 1.4, -cabinW * 0.5);
  group.add(sideWall2);
  // cabin floor
  const cFloor = new THREE.Mesh(new THREE.BoxGeometry(cabinD, 0.1, cabinW), dark);
  cFloor.position.set(-side * cabinD * 0.5, 0.05, 0);
  group.add(cFloor);
  // cabin ceiling
  const cCeil = new THREE.Mesh(new THREE.BoxGeometry(cabinD, 0.1, cabinW), dark);
  cCeil.position.set(-side * cabinD * 0.5, 2.75, 0);
  group.add(cCeil);

  // Sliding doors at entrance (open by default)
  const doorW = 1.05;
  const doorGeo = new THREE.BoxGeometry(0.1, 2.6, doorW);
  const doorL = new THREE.Mesh(doorGeo, metal);
  doorL.position.set(0, 1.4, -doorW * 0.5);
  group.add(doorL);
  const doorR = new THREE.Mesh(doorGeo, metal);
  doorR.position.set(0, 1.4, doorW * 0.5);
  group.add(doorR);
  // start open
  doorL.position.z = -doorW * 0.5 - 1.0;
  doorR.position.z = doorW * 0.5 + 1.0;

  // Frame
  const frame = new THREE.Mesh(new THREE.BoxGeometry(0.25, 3.0, 2.5), metal);
  frame.position.set(side * 0.05, 1.5, 0);
  group.add(frame);

  // Light
  const cLight = new THREE.PointLight(0xfff5e6, 0.9, 6);
  cLight.position.set(-side * 0.8, 2.5, 0);
  group.add(cLight);

  // INSIDE floor button panel (real elevator panel)
  const panel = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.6, 0.7), dark);
  panel.position.set(-side * 0.3, 1.5, cabinW * 0.42);
  group.add(panel);

  const floorBtns = [];
  for (let i = 1; i <= 10; i++) {
    const row = Math.floor((i - 1) / 2);
    const col = (i - 1) % 2;
    const b = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.08, 0.06, 12),
      new THREE.MeshStandardMaterial({
        color: i === floorNum ? 0x44ff66 : 0xd4a84b,
        emissive: i === floorNum ? 0x228833 : 0x5a3a10,
        emissiveIntensity: 0.55
      })
    );
    b.rotation.z = Math.PI / 2;
    b.position.set(
      -side * 0.26,
      2.05 - row * 0.22,
      cabinW * 0.42 + (col === 0 ? -0.15 : 0.15)
    );
    b.userData = { type: 'floor-btn', targetFloor: i };
    group.add(b);
    interactables.push(b);
    floorBtns.push(b);
  }
  // Roof button
  const roofB = new THREE.Mesh(
    new THREE.CylinderGeometry(0.1, 0.1, 0.06, 12),
    new THREE.MeshStandardMaterial({ color: 0xff4444, emissive: 0x882222, emissiveIntensity: 0.5 })
  );
  roofB.rotation.z = Math.PI / 2;
  roofB.position.set(-side * 0.26, 0.85, cabinW * 0.42);
  roofB.userData = { type: 'floor-btn', targetFloor: 'roof' };
  group.add(roofB);
  interactables.push(roofB);

  // Outer call button
  const call = new THREE.Mesh(
    new THREE.CylinderGeometry(0.09, 0.09, 0.06, 14),
    gold
  );
  call.rotation.z = Math.PI / 2;
  call.position.set(side * 0.2, 1.4, side > 0 ? -1.5 : 1.5);
  call.userData = { type: 'elevator-btn', floor: floorNum };
  group.add(call);
  interactables.push(call);

  // Hit zone = whole cabin
  const hit = new THREE.Mesh(
    new THREE.BoxGeometry(cabinD + 1.5, 3, cabinW + 0.5),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hit.position.set(-side * cabinD * 0.4, 1.5, 0);
  hit.userData = { type: 'elevator', floor: floorNum };
  group.add(hit);
  interactables.push(hit);
  doorL.userData = { type: 'elevator', floor: floorNum };
  doorR.userData = { type: 'elevator', floor: floorNum };
  interactables.push(doorL, doorR);

  parent.add(group);
  elevators.push({
    floor: floorNum,
    side,
    doorL,
    doorR,
    closedZL: -doorW * 0.5,
    closedZR: doorW * 0.5,
    group,
    openAmount: 1,
    targetOpen: 1,
    floorBtns
  });
}

function createHelicopter() {
  const g = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x2a2a2a, metalness: 0.5, roughness: 0.4 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(1, 2.4, 4, 12), bodyMat);
  body.rotation.z = Math.PI/2;
  g.add(body);
  const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.28, 3.2, 8), bodyMat);
  tail.rotation.z = Math.PI/2;
  tail.position.set(-2.8, 0.25, 0);
  g.add(tail);
  const rotor = new THREE.Mesh(new THREE.BoxGeometry(7.5, 0.1, 0.4), new THREE.MeshStandardMaterial({ color: 0x111 }));
  rotor.position.y = 1.25;
  g.add(rotor);
  return g;
}

/* -------------------- PARTS (1 per floor) -------------------- */
function placeParts() {
  for (let f = 1; f <= 10; f++) {
    const part = createPart(f);
    const y = (f - 1) * CONFIG.floorHeight + 0.5;
    const side = (f % 2 === 0) ? 1 : -1;
    part.position.set((Math.random() * 10 - 5), y, side * 1.8);
    part.userData = { type: 'part', id: f, collected: false, floor: f };
    scene.add(part);
    parts.push(part);
    interactables.push(part);
  }
}

function createPart(id) {
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({
    color: 0xd4a84b, metalness: 0.7, roughness: 0.3,
    emissive: 0x3a2a10, emissiveIntensity: 0.4
  });
  let mesh;
  if (id % 3 === 0) mesh = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.4, 0.55), mat);
  else if (id % 3 === 1) mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.65, 10), mat);
  else mesh = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.12, 8, 16), mat);
  g.add(mesh);
  const light = new THREE.PointLight(0xd4a84b, 0.7, 3.5);
  light.position.y = 0.3;
  g.add(light);
  return g;
}

/* -------------------- MONSTERS -------------------- */

function placeMonsters() {
  // 9 enemies from concept gallery
  addMonster({
    name: 'The Watcher',
    floor: 2,
    pos: [8, 0, 1.4],
    color: 0x2a2a28,
    type: 'watcher',
    speed: 2.6,
    desc: 'Keep looking at him or he comes.'
  });
  addMonster({
    name: 'Gaze Beast',
    floor: 3,
    pos: [-9, 0, -1.5],
    color: 0x2e2a24,
    type: 'gaze',
    speed: 1.4,
    desc: 'Do not stare more than 2 seconds.'
  });
  addMonster({
    name: 'Hungry Zombie',
    floor: 4,
    pos: [6, 0, 1.6],
    color: 0x6b8a72,
    type: 'hungry',
    speed: 3.0,
    desc: 'Find meat and give it to him.'
  });
  addMonster({
    name: 'Backwatcher',
    floor: 5,
    pos: [-7, 0, -1.3],
    color: 0x1c1a17,
    type: 'backtext',
    speed: 2.0,
    desc: 'Never look behind near him.'
  });
  addMonster({
    name: 'Pale Woman',
    floor: 6,
    pos: [4, 0, 1.7],
    color: 0x141315,
    type: 'stalker',
    speed: 2.3,
    desc: 'She cuts you off. Keep changing path.'
  });
  addMonster({
    name: 'Toy Doll',
    floor: 7,
    pos: [-5, 0, -1.6],
    color: 0x2a2024,
    type: 'toy',
    speed: 1.7,
    desc: 'Put the toy in the box to calm her.'
  });
  addMonster({
    name: 'Blood Crier',
    floor: 8,
    pos: [9, 0, 1.2],
    color: 0xd8d2c6,
    type: 'crier',
    speed: 2.5,
    desc: 'Stand still and look at his face.'
  });
  addMonster({
    name: 'Shadow Step',
    floor: 9,
    pos: [-8, 0, 1.4],
    color: 0x070708,
    type: 'shadowstep',
    speed: 3.8,
    desc: 'Only moves when you move. Stand still.'
  });
  addMonster({
    name: 'Whisper Doll',
    floor: 1,
    pos: [0, 0, -2],
    color: 0x3a3228,
    type: 'whisper',
    speed: 1.1,
    desc: 'Interact to silence her whisper.'
  });
}

function addMonster(data) {
  const m = createMonsterMesh(data.color, data.name, data.type);
  const y = (data.floor - 1) * CONFIG.floorHeight;
  m.position.set(data.pos[0], y, data.pos[2]);
  m.userData = {
    type: 'monster',
    kind: data.type,
    name: data.name,
    speed: data.speed,
    floor: data.floor,
    alive: true,
    lookTimer: 0,
    state: 'idle',
    desc: data.desc,
    stunned: false
  };
  scene.add(m);
  monsters.push(m);
  interactables.push(m);
}




function createMonsterMesh(color, name, kind) {
  const g = new THREE.Group();
  const skinCol = (kind === 'hungry' || kind === 'whisper') ? 0x6b8a72
    : (kind === 'crier') ? 0xd8cebd
    : (kind === 'stalker' || kind === 'toy') ? 0xd8cebd
    : 0xb7ab97;
  const skin = new THREE.MeshStandardMaterial({ color: skinCol, roughness: 0.85 });
  const cloth = new THREE.MeshStandardMaterial({
    color: kind === 'crier' ? 0xd8d2c6 : (kind === 'toy' ? 0x2a2024 : 0x1a1a18),
    roughness: 0.9
  });
  const hairM = new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: 1 });
  const voidEye = new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: 0.25 });
  const blood = new THREE.MeshStandardMaterial({ color: 0x6b1414, roughness: 0.55, emissive: 0x3a0000, emissiveIntensity: 0.3 });
  const fur = new THREE.MeshStandardMaterial({ color: 0x2e2a24, roughness: 1 });

  if (kind === 'gaze') {
    // Hunched multi-eyed beast
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.55, 14, 12), fur);
    body.position.y = 0.9; body.scale.set(1.1, 0.9, 1.3); g.add(body);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.35, 12, 10), fur);
    head.position.set(0, 1.35, 0.35); g.add(head);
    const snout = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.4, 8), fur);
    snout.rotation.x = Math.PI / 2; snout.position.set(0, 1.25, 0.7); g.add(snout);
    for (let i = 0; i < 10; i++) {
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.04, 6, 5), voidEye);
      const ang = (i / 10) * Math.PI * 2;
      e.position.set(Math.cos(ang) * 0.2, 1.4 + Math.sin(ang) * 0.12, 0.5);
      g.add(e);
      const pin = new THREE.Mesh(new THREE.SphereGeometry(0.012, 4, 4),
        new THREE.MeshStandardMaterial({ color: 0x5c1414, emissive: 0x5c1414, emissiveIntensity: 1 }));
      pin.position.copy(e.position); pin.position.z += 0.03; g.add(pin);
    }
    for (const s of [-1, 1]) {
      const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.5, 4, 6), fur);
      leg.position.set(s * 0.25, 0.35, 0); g.add(leg);
    }
  } else if (kind === 'backtext') {
    // Backwatcher – face twisted backward
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.25, 0.55, 6, 10), cloth);
    torso.position.y = 1.3; g.add(torso);
    for (const s of [-1, 1]) {
      const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.7, 4, 6), fur);
      leg.position.set(s * 0.12, 0.5, 0); leg.rotation.x = 0.2; g.add(leg);
    }
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 12, 10), skin);
    head.position.set(0, 1.85, -0.15); head.rotation.y = Math.PI; g.add(head);
    for (const x of [-0.06, 0.06]) {
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 6),
        new THREE.MeshStandardMaterial({ color: 0x4a1414, emissive: 0x4a1414, emissiveIntensity: 0.8 }));
      e.position.set(x, 1.88, -0.32); g.add(e);
    }
    for (const s of [-1, 1]) {
      const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.5, 4, 6), cloth);
      arm.position.set(s * 0.4, 1.3, 0); g.add(arm);
    }
  } else if (kind === 'shadowstep') {
    // Almost pure black silhouette + red eyes
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 1.2, 6, 10),
      new THREE.MeshStandardMaterial({ color: 0x050506, roughness: 1 }));
    body.position.y = 1.4; body.scale.x = 0.75; g.add(body);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 8),
      new THREE.MeshStandardMaterial({ color: 0x080809 }));
    head.position.y = 2.2; g.add(head);
    for (const x of [-0.05, 0.05]) {
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 6),
        new THREE.MeshStandardMaterial({ color: 0x8a1414, emissive: 0x8a1414, emissiveIntensity: 2, toneMapped: false }));
      e.position.set(x, 2.22, 0.15); g.add(e);
    }
    const glow = new THREE.PointLight(0x8a1414, 0.6, 4);
    glow.position.set(0, 2.2, 0.3); g.add(glow);
  } else {
    // Humanoid: Watcher, Hungry, Pale Woman, Toy Doll, Blood Crier, Whisper
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.27, 0.6, 6, 12), cloth);
    torso.position.y = 1.32; g.add(torso);
    if (kind === 'stalker') {
      const jacket = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.55, 0.32), cloth);
      jacket.position.y = 1.4; g.add(jacket);
    }
    if (kind === 'toy') {
      const dress = new THREE.Mesh(new THREE.ConeGeometry(0.45, 0.85, 10), cloth);
      dress.position.y = 0.85; g.add(dress);
    }
    for (const s of [-1, 1]) {
      const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.65, 4, 8), cloth);
      leg.position.set(s * 0.11, 0.5, 0); g.add(leg);
      const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.5, 4, 6), skin);
      arm.position.set(s * 0.38, 1.35, 0); arm.rotation.z = s * 0.3; g.add(arm);
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 6), skin);
      hand.position.set(s * 0.5, 1.0, 0.05); g.add(hand);
    }
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 16, 14), skin);
    head.position.y = 1.92; head.scale.set(0.95, 1.08, 0.92); g.add(head);

    if (kind === 'stalker') {
      const hair = new THREE.Mesh(new THREE.SphereGeometry(0.24, 12, 10), hairM);
      hair.position.set(0, 1.95, 0.02); hair.scale.set(1.2, 1.3, 1.25); g.add(hair);
      for (let i = 0; i < 6; i++) {
        const s = new THREE.Mesh(new THREE.CapsuleGeometry(0.03, 0.5, 3, 5), hairM);
        s.position.set((i - 2.5) * 0.06, 1.65, 0.2); s.rotation.x = 0.5; g.add(s);
      }
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 6), voidEye);
      eye.position.set(0.08, 1.95, 0.2); g.add(eye);
    } else {
      const hair = new THREE.Mesh(new THREE.SphereGeometry(0.19, 10, 8), hairM);
      hair.position.set(0, 2.05, -0.04); hair.scale.set(1.1, 0.5, 1.0); g.add(hair);
      for (const x of [-0.07, 0.07]) {
        const sock = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 6), voidEye);
        sock.position.set(x, 1.95, 0.17); g.add(sock);
      }
    }
    if (kind === 'crier') {
      const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.1, 0.08), blood);
      mouth.position.set(0, 1.82, 0.18); g.add(mouth);
      for (const x of [-0.06, 0.06]) {
        const tear = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.14, 0.02), blood);
        tear.position.set(x, 1.88, 0.18); g.add(tear);
      }
      const stain = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 6), blood);
      stain.position.set(0.1, 1.3, 0.22); stain.scale.set(1.3, 0.5, 0.35); g.add(stain);
    } else if (kind === 'hungry') {
      const wound = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), blood);
      wound.position.set(0.15, 1.3, 0.22); g.add(wound);
      const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.06, 0.05),
        new THREE.MeshStandardMaterial({ color: 0x1c1414 }));
      mouth.position.set(0, 1.84, 0.18); g.add(mouth);
    } else if (kind === 'toy') {
      const smile = new THREE.Mesh(new THREE.TorusGeometry(0.06, 0.012, 6, 12, Math.PI),
        new THREE.MeshStandardMaterial({ color: 0x8a3838 }));
      smile.position.set(0, 1.84, 0.18); smile.rotation.x = Math.PI; g.add(smile);
    } else if (kind === 'whisper') {
      const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.07, 0.05),
        new THREE.MeshStandardMaterial({ color: 0x100c0a }));
      mouth.position.set(0, 1.84, 0.18); g.add(mouth);
    }
  }

  // Name plate
  const canvas = document.createElement('canvas');
  canvas.width = 256; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(10,0,0,0.85)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.strokeStyle = '#aa2222';
  ctx.lineWidth = 2;
  ctx.strokeRect(2, 2, 252, 60);
  ctx.fillStyle = '#ff6666';
  ctx.font = 'bold 18px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText(name, 128, 40);
  const tex = new THREE.CanvasTexture(canvas);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  spr.scale.set(1.9, 0.48, 1);
  spr.position.y = 2.55;
  g.add(spr);

  return g;
}

/* -------------------- ITEMS for counters -------------------- */
function placeNPCs() {
  // Meat on floor 4
  const meat = createItem(0x8b0000, 'meat');
  meat.position.set(-4, (4-1)*CONFIG.floorHeight + 0.4, 1.5);
  meat.userData = { type: 'item', item: 'meat' };
  scene.add(meat);
  interactables.push(meat);

  // Toy on floor 7
  const toy = createItem(0xff69b4, 'toy');
  toy.position.set(7, (7-1)*CONFIG.floorHeight + 0.4, -1.6);
  toy.userData = { type: 'item', item: 'toy' };
  scene.add(toy);
  interactables.push(toy);

  // Box on floor 7
  const box = new THREE.Mesh(
    new THREE.BoxGeometry(0.8, 0.5, 0.8),
    new THREE.MeshStandardMaterial({ color: 0x5a3a1a })
  );
  box.position.set(-2, (7-1)*CONFIG.floorHeight + 0.3, 1.7);
  box.userData = { type: 'box' };
  scene.add(box);
  interactables.push(box);
}

function createItem(color, name) {
  const g = new THREE.Group();
  const m = new THREE.Mesh(
    new THREE.SphereGeometry(0.25, 10, 8),
    new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.3 })
  );
  g.add(m);
  const light = new THREE.PointLight(color, 0.6, 2.5);
  g.add(light);
  return g;
}

/* -------------------- CONTROLS -------------------- */
function setupKeys() {
  const on = (e, p) => {
    switch (e.code) {
      case 'KeyW': case 'ArrowUp':    move.f = p; break;
      case 'KeyS': case 'ArrowDown':  move.b = p; break;
      case 'KeyA': case 'ArrowLeft':  move.l = p; break;
      case 'KeyD': case 'ArrowRight': move.r = p; break;
      case 'KeyE': case 'Space': if (p) tryInteract(); break;
      case 'KeyQ': case 'KeyF': if (p) tryStun(); break;
    }
  };
  addEventListener('keydown', e => on(e, true));
  addEventListener('keyup',   e => on(e, false));
}

function setupMobile() {
  const base = document.getElementById('joystick-base');
  const stick = document.getElementById('joystick-stick');
  const lookZone = document.getElementById('look-zone');
  const interactBtn = document.getElementById('interact-btn');

  let joyId = null, lookId = null, last = { x:0, y:0 };

  base.addEventListener('touchstart', e => {
    e.preventDefault();
    joyId = e.changedTouches[0].identifier;
  }, { passive: false });

  addEventListener('touchmove', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        const r = base.getBoundingClientRect();
        const cx = r.left + r.width/2, cy = r.top + r.height/2;
        let dx = t.clientX - cx, dy = t.clientY - cy;
        const max = r.width/2 - 8;
        const len = Math.hypot(dx, dy);
        if (len > max) { dx = dx/len*max; dy = dy/len*max; }
        stick.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
        joy.x = dx / max;
        joy.y = -dy / max;
      }
      if (t.identifier === lookId) {
        lookD.x += (t.clientX - last.x) * 0.004;
        lookD.y += (t.clientY - last.y) * 0.004;
        last.x = t.clientX; last.y = t.clientY;
      }
    }
  }, { passive: false });

  addEventListener('touchend', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        joyId = null;
        stick.style.transform = 'translate(-50%, -50%)';
        joy.x = 0; joy.y = 0;
      }
      if (t.identifier === lookId) lookId = null;
    }
  });

  lookZone.addEventListener('touchstart', e => {
    e.preventDefault();
    lookId = e.changedTouches[0].identifier;
    last.x = e.changedTouches[0].clientX;
    last.y = e.changedTouches[0].clientY;
  }, { passive: false });

  interactBtn.addEventListener('touchstart', e => {
    e.preventDefault();
    tryInteract();
  }, { passive: false });
}

/* -------------------- INTERACTION + ELEVATOR -------------------- */
function tryInteract() {
  if (gameOver) return;
  // If elevator panel is already open, ignore
  if (elevatorOpen && elevatorUI && !elevatorUI.classList.contains('hidden')) return;

  const origin = camera.getWorldPosition(new THREE.Vector3());
  const dir = camera.getWorldDirection(new THREE.Vector3());
  raycaster.set(origin, dir);
  raycaster.far = 4.0;

  const hits = raycaster.intersectObjects(interactables, true);
  let obj = null;
  if (hits.length) {
    obj = hits[0].object;
    while (obj && !obj.userData.type) obj = obj.parent;
  }

  // Proximity fallback for elevators (so it always works near doors)
  if (!obj || (obj.userData.type !== 'elevator' && obj.userData.type !== 'elevator-btn')) {
    const mover = isMobile || !controls ? camera.position : controls.getObject().position;
    const nearElev = interactables.find(o => {
      if (!o.userData || (o.userData.type !== 'elevator' && o.userData.type !== 'elevator-btn')) return false;
      const wp = new THREE.Vector3();
      o.getWorldPosition(wp);
      return wp.distanceTo(mover) < 4.5 && Math.abs(wp.y - mover.y) < 3.0;
    });
    if (nearElev) obj = nearElev;
  }

  if (!obj) return;
  const d = obj.userData;

  if (d.type === 'part' && !d.collected) {
    d.collected = true;
    partsCollected++;
    partsEl.textContent = `Parts: ${partsCollected} / ${TOTAL_PARTS}`;
    obj.visible = false;
    showMsg(`Part ${d.id} collected!`);
    if (partsCollected >= TOTAL_PARTS) {
      document.getElementById('objective').textContent = 'All parts found! Go to the roof and fix the helicopter.';
    }
  }
  else if (d.type === 'floor-btn') {
    startElevatorRide(d.targetFloor);
  }
  else if (d.type === 'elevator' || d.type === 'elevator-btn') {
    showMsg('Walk inside. Press a floor button on the wall panel.');
  }
  else if (d.type === 'item') {
    holdingItem = d.item;
    obj.visible = false;
    showMsg(`Picked up ${d.item}`);
  }
  else if (d.type === 'box' && holdingItem === 'toy') {
    holdingItem = null;
    showMsg('Toy placed in the box. Toy Girl is calm and shows the part.');
  }
  else if (d.type === 'monster') {
    handleMonsterInteract(obj);
  }
}



function openElevatorUI() {
  // Minimal panel only as backup — prefer 3D buttons inside cabin
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (!ui) return;
  elevatorOpen = true;
  const box = document.getElementById('elevator-buttons');
  if (box) {
    [...box.querySelectorAll('button')].forEach(b => {
      b.classList.remove('current');
      if (String(currentFloor) === b.textContent || (currentFloor === 'Roof' && b.textContent === 'ROOF')) {
        b.classList.add('current');
      }
    });
  }
  const label = document.getElementById('elevator-current');
  if (label) label.textContent = currentFloor === 'Roof' ? 'Now: Roof' : `Now: Floor ${currentFloor}`;
  ui.classList.remove('hidden');
}

function startElevatorRide(target) {
  if (ridingElevator || gameOver) return;
  if (target !== 'roof' && Number(target) === Number(currentFloor)) {
    showMsg('Already here');
    return;
  }
  // close HTML panel if open
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (ui) ui.classList.add('hidden');
  elevatorOpen = false;

  ridingElevator = true;
  rideTarget = target;
  ridePhase = 'closing';
  rideTimer = 1.2; // doors close
  // close doors on this floor
  elevators.forEach(el => {
    if (el.floor === currentFloor) el.targetOpen = 0;
  });
  showMsg('Doors closing…');
  // pull player into cabin center
  const halfL = CONFIG.corridorLength / 2;
  const side = camera.position.x >= 0 ? 1 : -1;
  camera.position.x = side * (halfL - 1.0);
  camera.position.z = 0;
}

function goToFloor(f) {
  startElevatorRide(f);
}

function updateElevatorRide(dt) {
  if (!ridingElevator) return;
  rideTimer -= dt;
  if (rideTimer > 0) return;

  if (ridePhase === 'closing') {
    ridePhase = 'moving';
    // travel time depends on distance
    let dist = 3;
    if (rideTarget === 'roof') {
      dist = currentFloor === 'Roof' ? 1 : (11 - Number(currentFloor || 1));
    } else if (currentFloor === 'Roof') {
      dist = Number(rideTarget);
    } else {
      dist = Math.abs(Number(rideTarget) - Number(currentFloor)) || 1;
    }
    rideTimer = 1.2 + dist * 0.7; // slower = more realistic
    showMsg(rideTarget === 'roof' ? 'Going to Roof…' : `Going to Floor ${rideTarget}…`);
  } else if (ridePhase === 'moving') {
    // arrive
    const mover = camera;
    if (rideTarget === 'roof') {
      mover.position.set(0, CONFIG.floors * CONFIG.floorHeight + CONFIG.playerHeight, 0);
      currentFloor = 'Roof';
      if (floorInd) floorInd.textContent = 'Roof';
      showMsg('Roof');
      ridingElevator = false;
      ridePhase = null;
      if (partsCollected >= TOTAL_PARTS) {
        setTimeout(() => {
          if (winScreen) winScreen.classList.remove('hidden');
          gameOver = true;
        }, 600);
      } else {
        showMsg('Need all 10 parts for the helicopter');
      }
    } else {
      const floorNum = Number(rideTarget);
      const y = (floorNum - 1) * CONFIG.floorHeight + CONFIG.playerHeight;
      const side = camera.position.x >= 0 ? 1 : -1;
      const halfL = CONFIG.corridorLength / 2;
      mover.position.set(side * (halfL - 1.2), y, 0);
      currentFloor = floorNum;
      if (floorInd) floorInd.textContent = `Floor ${floorNum}`;
      // open doors on arrival floor
      elevators.forEach(el => {
        if (el.floor === floorNum) el.targetOpen = 1;
      });
      ridePhase = 'opening';
      rideTimer = 1.4;
      showMsg(`Floor ${floorNum}`);
    }
  } else if (ridePhase === 'opening') {
    ridingElevator = false;
    ridePhase = null;
    showMsg('Doors open');
  }
}

function handleMonsterInteract(m) {
  const k = m.userData.kind;
  if (k === 'hungry' && holdingItem === 'meat') {
    holdingItem = null;
    m.userData.alive = false;
    m.visible = false;
    showMsg('Hungry Zombie is satisfied. He leaves.');
  } else if (k === 'whisper') {
    showMsg('Whisper silenced… for now.');
    m.userData.state = 'calm';
  } else {
    showMsg(m.userData.desc);
  }
}

/* -------------------- MONSTER AI -------------------- */
function updateMonsters(dt) {
  if (gameOver) return;
  const playerPos = (isMobile || !controls) ? camera.position : controls.getObject().position;

  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor !== currentFloor && currentFloor !== 'Roof') return;

    // Stunned monsters do nothing
    if (m.userData.stunned) return;

    const kind = m.userData.kind;
    const toPlayer = new THREE.Vector3().subVectors(playerPos, m.position);
    const dist = toPlayer.length();
    toPlayer.y = 0;
    toPlayer.normalize();

    // Is player looking at monster?
    const lookDir = camera.getWorldDirection(new THREE.Vector3());
    const toM = new THREE.Vector3().subVectors(m.position, camera.position).normalize();
    const lookingAt = lookDir.dot(toM) > 0.85 && dist < 12;

    if (kind === 'watcher') {
      if (lookingAt) {
        // freeze
      } else if (dist > 1.5) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      } else kill('The Watcher caught you');
    }
    else if (kind === 'gaze') {
      if (lookingAt) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 2.0) kill('You stared too long at the Gaze Beast');
      } else {
        m.userData.lookTimer = Math.max(0, m.userData.lookTimer - dt * 0.5);
      }
    }
    else if (kind === 'hungry') {
      if (dist > 1.8) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (holdingItem !== 'meat') kill('The Hungry Zombie reached you');
    }
    else if (kind === 'backtext') {
      // if player is looking roughly away from monster while close
      const away = lookDir.dot(toM) < -0.3;
      if (away && dist < 8) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.2) kill('You looked at your back…');
      } else m.userData.lookTimer = 0;
      if (dist > 2) m.position.addScaledVector(toPlayer, m.userData.speed * 0.6 * dt);
    }
    else if (kind === 'stalker') {
      // moves toward where player is going
      const predict = playerPos.clone().add(lookDir.clone().multiplyScalar(3));
      const toPred = new THREE.Vector3().subVectors(predict, m.position);
      toPred.y = 0; toPred.normalize();
      if (dist > 1.6) m.position.addScaledVector(toPred, m.userData.speed * dt);
      else kill('The Pale Girl caught you');
    }
    else if (kind === 'toy') {
      if (holdingItem === 'toy') {
        // follows calmly
        if (dist > 2.5) m.position.addScaledVector(toPlayer, 1.5 * dt);
      } else if (dist < 2.0) {
        // aggressive until toy is placed
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      }
    }
    else if (kind === 'crier') {
      if (lookingAt && Math.abs(joy.x) + Math.abs(joy.y) < 0.1 && !move.f && !move.b && !move.l && !move.r) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.5) {
          m.userData.alive = false;
          m.visible = false;
          showMsg('Blood Crier calmed down and vanished.');
        }
      } else {
        m.userData.lookTimer = 0;
        if (dist > 1.7) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
        else kill('The Blood Crier reached you');
      }
    }
    else if (kind === 'shadowstep') {
      const moving = Math.abs(joy.x) + Math.abs(joy.y) > 0.1 || move.f || move.b || move.l || move.r;
      if (moving && dist > 1.5) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (!moving) { /* frozen */ }
      else kill('Shadow Step touched you');
    }
    else if (kind === 'whisper') {
      if (m.userData.state !== 'calm' && dist < 4) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 4) kill('The Whisper Doll’s voice took you');
      }
    }
  });
}

function kill(reason) {
  if (gameOver) return;
  gameOver = true;
  showMsg(reason, 5000);
  setTimeout(() => location.reload(), 3500);
}

function tryStun() {
  if (gameOver || stunCooldown > 0 || stunActive > 0) return;
  // Stun every monster on the current floor
  let hit = 0;
  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor === currentFloor || currentFloor === 'Roof') {
      m.userData.stunned = true;
      hit++;
    }
  });
  if (hit > 0) {
    stunActive = 3;
    stunCooldown = 15;
    showMsg(`Monster stunned for 3 seconds! (${hit})`);
  } else {
    showMsg('No monster on this floor');
    stunCooldown = 2; // small anti-spam
  }
  updateStunUI();
}

function updateStunUI() {
  const desk = document.getElementById('stun-btn-desktop');
  const setState = (btn, text, disabled) => {
    if (!btn) return;
    btn.disabled = disabled;
    btn.textContent = text;
  };
  if (stunCooldown > 0) {
    const t = Math.ceil(stunCooldown) + 's';
    setState(stunBtn, t, true);
    setState(desk, t, true);
    if (stunCdEl) stunCdEl.textContent = 'Cooldown';
  } else if (stunActive > 0) {
    setState(stunBtn, 'STUNNED', true);
    setState(desk, 'STUNNED', true);
  } else {
    setState(stunBtn, 'STUN', false);
    setState(desk, 'STUN (Q)', false);
    if (stunCdEl) stunCdEl.textContent = 'Ready';
  }
}

/* -------------------- ANIMATION -------------------- */
// Cap at ~45 FPS for stable mobile performance
const FPS_LIMIT = 45;
const FRAME_TIME = 1 / FPS_LIMIT;
let fpsAccum = 0;

function animate() {
  requestAnimationFrame(animate);
  const rawDt = clock.getDelta();
  fpsAccum += rawDt;
  if (fpsAccum < FRAME_TIME) return;
  const dt = Math.min(fpsAccum, 0.05);
  fpsAccum = 0;

  if (gameOver) {
    renderer.render(scene, camera);
    return;
  }

  // Stun timers
  if (stunActive > 0) {
    stunActive -= dt;
    if (stunActive <= 0) {
      stunActive = 0;
      monsters.forEach(m => { m.userData.stunned = false; });
    }
  }
  if (stunCooldown > 0) {
    stunCooldown -= dt;
    if (stunCooldown < 0) stunCooldown = 0;
  }
  updateStunUI();

  const speed = ridingElevator ? 0 : CONFIG.playerSpeed * dt;
  const forward = new THREE.Vector3();
  const right = new THREE.Vector3();
  const mover = isMobile || !controls ? camera : controls.getObject();

  if (isMobile) {
    camera.rotation.order = 'YXZ';
    camera.rotation.y -= lookD.x;
    camera.rotation.x -= lookD.y;
    camera.rotation.x = Math.max(-1.2, Math.min(1.2, camera.rotation.x));
    lookD.x = 0; lookD.y = 0;

    camera.getWorldDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    mover.position.addScaledVector(forward, joy.y * speed);
    mover.position.addScaledVector(right, joy.x * speed);
  } else if (controls && controls.isLocked) {
    controls.getDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    if (move.f) mover.position.addScaledVector(forward, speed);
    if (move.b) mover.position.addScaledVector(forward, -speed);
    if (move.l) mover.position.addScaledVector(right, -speed);
    if (move.r) mover.position.addScaledVector(right, speed);
  }

  // Bounds
  const halfL = CONFIG.corridorLength/2 - 1;
  const halfW = CONFIG.corridorWidth/2 - 0.7;
  mover.position.x = Math.max(-halfL, Math.min(halfL, mover.position.x));
  mover.position.z = Math.max(-halfW, Math.min(halfW, mover.position.z));

  // Floor height lock
  if (currentFloor !== 'Roof') {
    const targetY = (currentFloor - 1) * CONFIG.floorHeight + CONFIG.playerHeight;
    mover.position.y += (targetY - mover.position.y) * 0.3;
  }

  updateElevatorRide(dt);

  // Hint when near elevator (no auto app panel)
  {
    const pos = camera.position;
    let inElev = false;
    if (currentFloor !== 'Roof') {
      for (const el of elevators) {
        if (el.floor !== currentFloor) continue;
        const wp = new THREE.Vector3();
        el.group.getWorldPosition(wp);
        // Standing at the wall elevator opening
        if (Math.abs(pos.x - wp.x) < 2.5 && Math.abs(pos.z - wp.z) < 2.2) {
          inElev = true;
          break;
        }
      }
      // Also detect by corridor ends
      const halfL = CONFIG.corridorLength / 2;
      if (Math.abs(Math.abs(pos.x) - halfL) < 2.8 && Math.abs(pos.z) < 2.5) {
        inElev = true;
      }
    }
    insideElevator = inElev;
    if (inElev && !elevPromptShown && !gameOver && !ridingElevator) {
      elevPromptShown = true;
      showMsg('Inside elevator — aim at a floor button and INTERACT', 2500);
    }
    if (!inElev) {
      elevPromptShown = false;
    }
  }

  // Elevator door slide animation (wall elevator)
  elevators.forEach(el => {
    const speed = 2.2 * dt;
    if (el.openAmount < el.targetOpen) el.openAmount = Math.min(el.targetOpen, el.openAmount + speed);
    if (el.openAmount > el.targetOpen) el.openAmount = Math.max(el.targetOpen, el.openAmount - speed);
    const o = el.openAmount;
    el.doorL.position.z = el.closedZL - o * 0.95;
    el.doorR.position.z = el.closedZR + o * 0.95;
  });

  updateMonsters(dt);

  // Part bob
  parts.forEach(p => {
    if (!p.userData.collected) {
      p.rotation.y += dt * 1.3;
      p.position.y += Math.sin(clock.elapsedTime * 2 + p.userData.id) * 0.002;
    }
  });

  renderer.render(scene, camera);
}

function setupUI() {
  // Elevator buttons – large, mobile-friendly
  const box = document.getElementById('elevator-buttons');
  if (box) box.innerHTML = '';
  for (let i = 1; i <= 10; i++) {
    const b = document.createElement('button');
    b.textContent = i;
    b.type = 'button';
    const go = (e) => { e.preventDefault(); goToFloor(i); };
    b.addEventListener('click', go);
    b.addEventListener('touchend', go, { passive: false });
    box.appendChild(b);
  }
  const roofBtn = document.createElement('button');
  roofBtn.textContent = 'ROOF';
  roofBtn.className = 'roof';
  roofBtn.type = 'button';
  const goRoof = (e) => { e.preventDefault(); goToFloor('roof'); };
  roofBtn.addEventListener('click', goRoof);
  roofBtn.addEventListener('touchend', goRoof, { passive: false });
  box.appendChild(roofBtn);

  document.getElementById('elevator-close').onclick = () => {
    elevatorUI.classList.add('hidden');
    elevatorOpen = false;
  };

  const hudElev = document.getElementById('hud-elevator-btn');
  if (hudElev) {
    const openElev = (e) => {
      e.preventDefault();
      e.stopPropagation();
      openElevatorUI();
    };
    hudElev.addEventListener('click', openElev);
    hudElev.addEventListener('touchstart', openElev, { passive: false });
    hudElev.addEventListener('touchend', openElev, { passive: false });
  }

  document.getElementById('dialogue-close').onclick = () => dialogue.classList.add('hidden');
  document.getElementById('restart-btn').onclick = () => location.reload();

  if (stunBtn) {
    stunBtn.addEventListener('click', tryStun);
    stunBtn.addEventListener('touchstart', e => { e.preventDefault(); tryStun(); }, { passive: false });
  }
  const stunDesk = document.getElementById('stun-btn-desktop');
  if (stunDesk) {
    stunDesk.addEventListener('click', tryStun);
  }

  let p = 0;
  const iv = setInterval(() => {
    p += 15;
    progressEl.style.width = Math.min(p, 95) + '%';
    if (p >= 95) clearInterval(iv);
  }, 60);
}

init().catch(console.error);

import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

/* ============================================================
   SKYLINE HOTEL – 10 FLOORS
   Brighter atmosphere + monsters with counters
   ============================================================ */

const CONFIG = {
  floors: 10,
  floorHeight: 4.5,
  corridorWidth: 7,
  corridorLength: 32,
  playerHeight: 1.7,
  playerSpeed: 5.2
};

let scene, camera, renderer, controls;
let currentFloor = 1;
let partsCollected = 0;
const TOTAL_PARTS = 10;
let gameMode = 'normal'; // normal | peaceful
let multiplayer = false;
let isHost = false;
let peer = null;
let myPeerId = null;
let roomCode = null;
const peerConns = []; // DataConnections
const remotePlayers = {}; // id -> { mesh, last }
const MAX_PLAYERS = 3;
const PLAYER_COLORS = [0x4488ff, 0x44cc66, 0xff8844];


let move = { f: false, b: false, l: false, r: false };
let isMobile = false;
let joy = { x: 0, y: 0 };
let lookD = { x: 0, y: 0 };
let interactables = [];
let monsters = [];
let elevators = []; // {floor, side, doorL, doorR, group, zone}
let insideElevator = false;
let elevPromptShown = false;
let ridingElevator = false;
let rideTimer = 0;
let ridePhase = null; // closing | moving | opening
let rideTarget = null;
let parts = [];
let clock = new THREE.Clock();
let raycaster = new THREE.Raycaster();
let elevatorOpen = false;
let gameOver = false;
let holdingItem = null; // for toy / meat
let stunCooldown = 0;   // seconds remaining before stun can be used again
let stunActive = 0;     // seconds remaining of current stun

// DOM
const loadingEl = document.getElementById('loading');
const progressEl = document.getElementById('progress');
const hud = document.getElementById('hud');
const floorInd = document.getElementById('floor-indicator');
const partsEl = document.getElementById('parts');
const mobileControls = document.getElementById('mobile-controls');
const dialogue = document.getElementById('dialogue');
const npcNameEl = document.getElementById('npc-name');
const npcTextEl = document.getElementById('npc-text');
const winScreen = document.getElementById('win-screen');
const elevatorUI = document.getElementById('elevator-ui');
const msgEl = document.getElementById('msg');
const stunBtn = document.getElementById('stun-btn');
const stunCdEl = document.getElementById('stun-cd');

function showMsg(text, time = 3000) {
  msgEl.textContent = text;
  msgEl.classList.remove('hidden');
  setTimeout(() => msgEl.classList.add('hidden'), time);
}



function setupStartMenu() {
  const btnN = document.getElementById('btn-normal');
  const btnP = document.getElementById('btn-peaceful');
  const btnPlay = document.getElementById('btn-play');
  const btnHost = document.getElementById('btn-host');
  const btnJoin = document.getElementById('btn-join');
  const status = document.getElementById('mp-status');

  btnN.onclick = () => {
    gameMode = 'normal';
    btnN.classList.add('active');
    btnP.classList.remove('active');
  };
  btnP.onclick = () => {
    gameMode = 'peaceful';
    btnP.classList.add('active');
    btnN.classList.remove('active');
  };
  btnPlay.onclick = () => {
    multiplayer = false;
    beginGame();
  };

  btnHost.onclick = () => {
    if (typeof Peer === 'undefined') {
      status.textContent = 'PeerJS failed to load — check internet and retry';
      return;
    }
    status.textContent = 'Creating room…';
    multiplayer = true;
    isHost = true;
    // Short readable code as peer id prefix
    const code = Math.random().toString(36).slice(2, 6).toUpperCase();
    roomCode = code;
    const id = 'sky' + code.toLowerCase();
    peer = new Peer(id, { debug: 1 });
    peer.on('open', (pid) => {
      myPeerId = pid;
      status.textContent = 'ROOM CODE: ' + code + ' — tell your friends. Waiting (you + 2)...';
      // Host can start once ready — auto start after short wait so host can play
      setTimeout(() => {
        if (!document.getElementById('start-menu').classList.contains('hidden')) {
          status.textContent = 'ROOM: ' + code + ' — game starting. Friends join with this code.';
          beginGame();
        }
      }, 1500);
    });
    peer.on('connection', (conn) => {
      setupConn(conn);
    });
    peer.on('error', (err) => {
      status.textContent = 'Host error: ' + (err.type || err.message || err);
    });
  };

  btnJoin.onclick = () => {
    if (typeof Peer === 'undefined') {
      status.textContent = 'PeerJS failed to load — check internet and retry';
      return;
    }
    const code = (document.getElementById('join-code').value || '').trim().toUpperCase();
    if (code.length < 3) {
      status.textContent = 'Enter the host room code';
      return;
    }
    status.textContent = 'Connecting to ' + code + '…';
    multiplayer = true;
    isHost = false;
    roomCode = code;
    peer = new Peer({ debug: 1 });
    peer.on('open', () => {
      myPeerId = peer.id;
      const hostId = 'sky' + code.toLowerCase();
      const conn = peer.connect(hostId, { reliable: true });
      setupConn(conn);
      conn.on('open', () => {
        status.textContent = 'Connected! Starting…';
        beginGame();
      });
      conn.on('error', (e) => {
        status.textContent = 'Join failed — is host online? Code correct?';
      });
    });
    peer.on('error', (err) => {
      status.textContent = 'Join error: ' + (err.type || err.message || err);
    });
  };
}

function setupConn(conn) {
  conn.on('open', () => {
    if (peerConns.length >= MAX_PLAYERS - 1) {
      conn.send({ type: 'full' });
      conn.close();
      return;
    }
    peerConns.push(conn);
    // Introduce ourselves
    conn.send({
      type: 'hello',
      id: myPeerId,
      mode: gameMode,
      name: isHost ? 'Host' : 'Player'
    });
  });
  conn.on('data', (data) => {
    if (!data || !data.type) return;
    if (data.type === 'full') {
      const status = document.getElementById('mp-status');
      if (status) status.textContent = 'Room full (max 3)';
      return;
    }
    if (data.type === 'hello') {
      ensureRemotePlayer(data.id, data.name);
      // reply with our state
      conn.send({ type: 'hello', id: myPeerId, name: isHost ? 'Host' : 'Player' });
    }
    if (data.type === 'pos') {
      updateRemotePlayer(data);
    }
    if (data.type === 'part' && isHost) {
      // optional: host tracks — skip for simplicity
    }
  });
  conn.on('close', () => {
    const i = peerConns.indexOf(conn);
    if (i >= 0) peerConns.splice(i, 1);
  });
}

function ensureRemotePlayer(id, name) {
  if (!id || id === myPeerId) return;
  if (remotePlayers[id]) return;
  if (!scene) return;
  const color = PLAYER_COLORS[Object.keys(remotePlayers).length % PLAYER_COLORS.length];
  const g = new THREE.Group();
  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.28, 0.9, 4, 8),
    new THREE.MeshLambertMaterial({ color })
  );
  body.position.y = 1.0;
  g.add(body);
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.22, 8, 6),
    new THREE.MeshLambertMaterial({ color: 0xffddbb })
  );
  head.position.y = 1.75;
  g.add(head);
  // name sprite
  const c = document.createElement('canvas');
  c.width = 128; c.height = 32;
  const ctx = c.getContext('2d');
  ctx.fillStyle = 'rgba(0,0,0,0.7)';
  ctx.fillRect(0, 0, 128, 32);
  ctx.fillStyle = '#fff';
  ctx.font = '14px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText((name || 'Player').slice(0, 12), 64, 22);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true }));
  spr.scale.set(1.2, 0.3, 1);
  spr.position.y = 2.2;
  g.add(spr);
  scene.add(g);
  remotePlayers[id] = { mesh: g, last: performance.now() };
}

function updateRemotePlayer(data) {
  if (!data.id || data.id === myPeerId) return;
  ensureRemotePlayer(data.id, data.name);
  const rp = remotePlayers[data.id];
  if (!rp || !rp.mesh) return;
  rp.mesh.position.set(data.x, data.y, data.z);
  if (typeof data.ry === 'number') rp.mesh.rotation.y = data.ry;
  rp.last = performance.now();
}

let _mpSendAcc = 0;
function multiplayerTick(dt) {
  if (!multiplayer || !peerConns.length) return;
  _mpSendAcc += dt;
  if (_mpSendAcc < 0.08) return; // ~12 Hz
  _mpSendAcc = 0;
  const payload = {
    type: 'pos',
    id: myPeerId,
    x: camera.position.x,
    y: camera.position.y,
    z: camera.position.z,
    ry: camera.rotation.y,
    floor: currentFloor,
    parts: partsCollected
  };
  peerConns.forEach(c => {
    if (c.open) c.send(payload);
  });
}

async function init() {
  // Wait for start menu
  setupStartMenu();
}

function beginGame() {
  document.getElementById('start-menu').classList.add('hidden');
  document.getElementById('loading').classList.remove('hidden');
  isMobile = true;

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x4a4a5e);
  scene.fog = null; // fog costs FPS on mobile

  camera = new THREE.PerspectiveCamera(72, innerWidth / innerHeight, 0.1, 90);
  camera.position.set(0, CONFIG.playerHeight, 0);
  camera.rotation.order = 'YXZ';
  camera.rotation.y = -Math.PI / 2; // face +X elevator in the end wall
  camera.rotation.order = 'YXZ';

  renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', alpha: false });
  renderer.setSize(innerWidth, innerHeight);
  // Critical for mid-range phones: never above 1
  renderer.setPixelRatio(1);
  renderer.shadowMap.enabled = false;
  document.body.appendChild(renderer.domElement);

  // Cheap lighting only (point lights kill mobile FPS)
  scene.add(new THREE.AmbientLight(0xffffff, 1.4));
  scene.add(new THREE.HemisphereLight(0xffffff, 0x888899, 0.9));

  buildHotel();
  placeParts();
  placeMonsters();
  placeNPCs();

  setupMobile();
  setupKeys();
  setupUI();

  progressEl.style.width = '100%';
  setTimeout(() => {
    loadingEl.classList.add('hidden');
    hud.classList.remove('hidden');
    mobileControls.classList.remove('hidden');
  }, 700);

  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });

  animate();
}

/* -------------------- HOTEL -------------------- */
function buildHotel() {
  // Lambert = much cheaper than Standard on mobile GPUs
  const wallMat = new THREE.MeshLambertMaterial({ color: 0x6a5e52 });
  const floorMat = new THREE.MeshLambertMaterial({ color: 0x5a4e42 });
  const ceilMat  = new THREE.MeshLambertMaterial({ color: 0x4a423a });
  const carpetMat = new THREE.MeshLambertMaterial({ color: 0x8a3a3a });
  const goldMat = new THREE.MeshLambertMaterial({ color: 0xd4a84b });

  scene.userData.floorGroups = [];
  for (let f = 1; f <= CONFIG.floors; f++) {
    const y = (f - 1) * CONFIG.floorHeight;
    const g = new THREE.Group();
    g.position.y = y;
    scene.userData.floorGroups.push(g);

    // Floor
    const slab = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength + 18, 0.3, CONFIG.corridorWidth + 10),
      floorMat
    );
    slab.position.y = -0.15;
    slab.receiveShadow = true;
    g.add(slab);

    // Carpet
    const carpet = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength - 1, 0.02, 2.4),
      carpetMat
    );
    carpet.position.y = 0.01;
    g.add(carpet);

    // Ceiling
    const ceil = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength + 18, 0.2, CONFIG.corridorWidth + 10),
      ceilMat
    );
    ceil.position.y = CONFIG.floorHeight - 0.1;
    g.add(ceil);

    // Walls
    const h = CONFIG.floorHeight - 0.3;
    const long = new THREE.BoxGeometry(CONFIG.corridorLength + 2, h, 0.35);
    const n = new THREE.Mesh(long, wallMat); n.position.set(0, h/2, -CONFIG.corridorWidth/2); g.add(n);
    const s = new THREE.Mesh(long, wallMat); s.position.set(0, h/2,  CONFIG.corridorWidth/2); g.add(s);

    // End walls with CENTER OPENING for elevator (not a solid block)
    const endSideH = (CONFIG.corridorWidth + 1 - 2.6) / 2;
    for (const sx of [1, -1]) {
      const baseX = sx * (CONFIG.corridorLength/2 + 0.2);
      // left and right pillars of end wall
      for (const zSign of [-1, 1]) {
        const pillar = new THREE.Mesh(
          new THREE.BoxGeometry(0.4, h, endSideH),
          wallMat
        );
        const zOff = zSign * (CONFIG.corridorWidth/2 + 0.5 - endSideH/2);
        pillar.position.set(baseX, h/2, zOff);
        g.add(pillar);
      }
      // top lintel above elevator
      const lintel = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 2.8), wallMat);
      lintel.position.set(baseX, h - 0.25, 0);
      g.add(lintel);
    }

    // Fewer room doors (perf)
    for (const i of [-4, -2, 2, 4]) {
      const door = new THREE.Mesh(
        new THREE.BoxGeometry(1.4, 2.4, 0.1),
        new THREE.MeshLambertMaterial({ color: 0x4a3525 })
      );
      door.position.set(i * 3.5, 1.2, i > 0 ? CONFIG.corridorWidth/2 - 0.1 : -CONFIG.corridorWidth/2 + 0.1);
      g.add(door);
    }

    // No small lamps – global bright lighting only

    // Elevator doors both ends
    // Dead center of each corridor END (crosshair target)
    createElevator(g,  CONFIG.corridorLength/2 - 0.8, f);
    createElevator(g, -CONFIG.corridorLength/2 + 0.8, f);



    // Floor number
    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 64;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#222'; ctx.fillRect(0,0,128,64);
    ctx.fillStyle = '#d4a84b'; ctx.font = 'bold 36px system-ui';
    ctx.textAlign = 'center'; ctx.fillText('F' + f, 64, 44);
    const tex = new THREE.CanvasTexture(canvas);
    const label = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.7), new THREE.MeshBasicMaterial({ map: tex }));
    label.position.set(0, 2.4, -CONFIG.corridorWidth/2 + 0.2);
    g.add(label);

    scene.add(g);
  }

  // Roof + helicopter
  const roofY = CONFIG.floors * CONFIG.floorHeight;
  const roof = new THREE.Group();
  roof.position.y = roofY;

  const roofSlab = new THREE.Mesh(
    new THREE.BoxGeometry(42, 0.4, 32),
    new THREE.MeshStandardMaterial({ color: 0x333333 })
  );
  roofSlab.position.y = 0.2;
  roof.add(roofSlab);

  const pad = new THREE.Mesh(
    new THREE.CylinderGeometry(6, 6, 0.15, 32),
    new THREE.MeshStandardMaterial({ color: 0x222222 })
  );
  pad.position.y = 0.35;
  roof.add(pad);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(4.5, 5, 32),
    new THREE.MeshBasicMaterial({ color: 0xd4a84b, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI/2;
  ring.position.y = 0.43;
  roof.add(ring);

  const heli = createHelicopter();
  heli.position.set(0, 1.9, 0);
  roof.add(heli);

  // no point light on roof (perf)

  scene.add(roof);
}








function createElevator(parent, x, floorNum) {
  // Big always-open gold portal in the CENTER of the end wall
  const side = x > 0 ? 1 : -1;
  const group = new THREE.Group();
  group.position.set(x, 0, 0);

  const gold = new THREE.MeshLambertMaterial({ color: 0xe8b84a });
  const dark = new THREE.MeshLambertMaterial({ color: 0x111118 });
  const green = new THREE.MeshLambertMaterial({ color: 0x44ff66 });

  // Wide gold arch (centered on z=0 = middle of hallway)
  const top = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.45, 3.2), gold);
  top.position.set(0, 2.9, 0); group.add(top);
  const bot = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.25, 3.2), gold);
  bot.position.set(0, 0.12, 0); group.add(bot);
  const L = new THREE.Mesh(new THREE.BoxGeometry(0.5, 3.0, 0.45), gold);
  L.position.set(0, 1.5, -1.6); group.add(L);
  const R = new THREE.Mesh(new THREE.BoxGeometry(0.5, 3.0, 0.45), gold);
  R.position.set(0, 1.5, 1.6); group.add(R);

  // Open hole (no doors ever)
  const hole = new THREE.Mesh(new THREE.BoxGeometry(0.6, 2.7, 2.6), dark);
  hole.position.set(-side * 0.35, 1.45, 0); group.add(hole);
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.2, 2.6, 2.5),
    new THREE.MeshLambertMaterial({ color: 0x333340 }));
  back.position.set(-side * 1.5, 1.4, 0); group.add(back);

  // Green light bar
  const lite = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.25, 2.4), green);
  lite.position.set(0.05 * side, 3.25, 0); group.add(lite);

  // Giant hitbox
  const hit = new THREE.Mesh(
    new THREE.BoxGeometry(4, 3.5, 4),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hit.position.set(-side * 0.5, 1.5, 0);
  hit.userData = { type: 'elevator', floor: floorNum };
  group.add(hit);
  interactables.push(hit);

  parent.add(group);
  elevators.push({ floor: floorNum, side, doorL: null, doorR: null, group, openAmount: 1, targetOpen: 1, closedZL: 0, closedZR: 0 });
}

function createHelicopter() {
  const g = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x2a2a2a, metalness: 0.5, roughness: 0.4 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(1, 2.4, 4, 12), bodyMat);
  body.rotation.z = Math.PI/2;
  g.add(body);
  const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.28, 3.2, 8), bodyMat);
  tail.rotation.z = Math.PI/2;
  tail.position.set(-2.8, 0.25, 0);
  g.add(tail);
  const rotor = new THREE.Mesh(new THREE.BoxGeometry(7.5, 0.1, 0.4), new THREE.MeshStandardMaterial({ color: 0x111 }));
  rotor.position.y = 1.25;
  g.add(rotor);
  return g;
}

/* -------------------- PARTS (1 per floor) -------------------- */
function placeParts() {
  for (let f = 1; f <= 10; f++) {
    const part = createPart(f);
    const y = (f - 1) * CONFIG.floorHeight + 0.5;
    const side = (f % 2 === 0) ? 1 : -1;
    part.position.set((Math.random() * 10 - 5), y, side * 1.8);
    part.userData = { type: 'part', id: f, collected: false, floor: f };
    scene.add(part);
    parts.push(part);
    interactables.push(part);
  }
}

function createPart(id) {
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({
    color: 0xd4a84b, metalness: 0.7, roughness: 0.3,
    emissive: 0x3a2a10, emissiveIntensity: 0.4
  });
  let mesh;
  if (id % 3 === 0) mesh = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.4, 0.55), mat);
  else if (id % 3 === 1) mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.65, 10), mat);
  else mesh = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.12, 8, 16), mat);
  g.add(mesh);
  // no point light (mobile perf)
  return g;
}

/* -------------------- MONSTERS -------------------- */

function placeMonsters() {
  // 9 enemies from concept gallery
  addMonster({
    name: 'The Watcher',
    floor: 2,
    pos: [8, 0, 1.4],
    color: 0x2a2a28,
    type: 'watcher',
    speed: 2.6,
    desc: 'Keep looking at him or he comes.'
  });
  addMonster({
    name: 'Gaze Beast',
    floor: 3,
    pos: [-9, 0, -1.5],
    color: 0x2e2a24,
    type: 'gaze',
    speed: 1.4,
    desc: 'Do not stare more than 2 seconds.'
  });
  addMonster({
    name: 'Hungry Zombie',
    floor: 4,
    pos: [6, 0, 1.6],
    color: 0x6b8a72,
    type: 'hungry',
    speed: 3.0,
    desc: 'Find meat and give it to him.'
  });
  addMonster({
    name: 'Backwatcher',
    floor: 5,
    pos: [-7, 0, -1.3],
    color: 0x1c1a17,
    type: 'backtext',
    speed: 2.0,
    desc: 'Never look behind near him.'
  });
  addMonster({
    name: 'Pale Woman',
    floor: 6,
    pos: [4, 0, 1.7],
    color: 0x141315,
    type: 'stalker',
    speed: 2.3,
    desc: 'She cuts you off. Keep changing path.'
  });
  addMonster({
    name: 'Toy Doll',
    floor: 7,
    pos: [-5, 0, -1.6],
    color: 0x2a2024,
    type: 'toy',
    speed: 1.7,
    desc: 'Put the toy in the box to calm her.'
  });
  addMonster({
    name: 'Blood Crier',
    floor: 8,
    pos: [9, 0, 1.2],
    color: 0xd8d2c6,
    type: 'crier',
    speed: 2.5,
    desc: 'Stand still and look at his face.'
  });
  addMonster({
    name: 'Shadow Step',
    floor: 9,
    pos: [-8, 0, 1.4],
    color: 0x070708,
    type: 'shadowstep',
    speed: 3.8,
    desc: 'Only moves when you move. Stand still.'
  });
  addMonster({
    name: 'Whisper Doll',
    floor: 1,
    pos: [0, 0, -2],
    color: 0x3a3228,
    type: 'whisper',
    speed: 1.1,
    desc: 'Interact to silence her whisper.'
  });
}

function addMonster(data) {
  const m = createMonsterMesh(data.color, data.name, data.type);
  const y = (data.floor - 1) * CONFIG.floorHeight;
  m.position.set(data.pos[0], y, data.pos[2]);
  m.userData = {
    type: 'monster',
    kind: data.type,
    name: data.name,
    speed: data.speed,
    floor: data.floor,
    alive: true,
    lookTimer: 0,
    state: 'idle',
    desc: data.desc,
    stunned: false
  };
  scene.add(m);
  monsters.push(m);
  interactables.push(m);
}






function createMonsterMesh(color, name, kind) {
  let g;
  switch (kind) {
    case 'watcher': g = createWatcherMesh(); break;
    case 'gaze': g = createGazeBeastMesh(); break;
    case 'hungry': g = createHungryZombieMesh(); break;
    case 'backtext': g = createBackwatcherMesh(); break;
    case 'stalker': g = createPaleGirlMesh(); break;
    case 'toy': g = createToyGirlMesh(); break;
    case 'crier': g = createBloodCrierMesh(); break;
    case 'shadowstep': g = createShadowStepMesh(); break;
    case 'whisper': g = createWhisperDollMesh(); break;
    default: g = createWatcherMesh(); break;
  }

  // Slightly larger so readable on phone
  g.scale.set(1.15, 1.15, 1.15);

  // Name plate above head
  const canvas = document.createElement('canvas');
  canvas.width = 256; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(10,0,0,0.88)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.strokeStyle = '#cc2222';
  ctx.lineWidth = 2;
  ctx.strokeRect(2, 2, 252, 60);
  ctx.fillStyle = '#ff6666';
  ctx.font = 'bold 18px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText(name, 128, 40);
  const tex = new THREE.CanvasTexture(canvas);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  spr.scale.set(1.9, 0.48, 1);
  spr.position.y = 2.55;
  g.add(spr);
  return g;
}



function createWatcherMesh() {
  const g = new THREE.Group();
  const suit = new THREE.MeshLambertMaterial({ color: 0x3b2b25 });
  const suitDark = new THREE.MeshLambertMaterial({ color: 0x211a18 });
  const shirt = new THREE.MeshLambertMaterial({ color: 0xaaa196 });
  const skin = new THREE.MeshLambertMaterial({ color: 0x9f9189 });
  const eyeWhite = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0x666666, emissiveIntensity: 0.35 });
  const pupil = new THREE.MeshLambertMaterial({ color: 0x090809 });
  const tieMat = new THREE.MeshLambertMaterial({ color: 0x181519 });
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.43, 0.72, 0.27), suit);
  torso.position.y = 1.24; g.add(torso);
  const vest = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.59, 0.285), suitDark);
  vest.position.set(0, 1.27, -0.145); g.add(vest);
  const shirtFront = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.57, 0.035), shirt);
  shirtFront.position.set(0, 1.30, -0.305); g.add(shirtFront);
  const tie = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.36, 6), tieMat);
  tie.position.set(0, 1.37, -0.33); g.add(tie);
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.085, 0.17, 7), skin);
  neck.position.y = 1.69; g.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.225, 10, 8), skin);
  head.scale.set(0.88, 1.16, 0.86); head.position.set(0, 1.86, -0.01); g.add(head);
  const cheekL = new THREE.Mesh(new THREE.SphereGeometry(0.075, 7, 5), suitDark);
  cheekL.scale.set(1.15, 0.65, 0.25); cheekL.position.set(-0.105, 1.77, -0.205); g.add(cheekL);
  const cheekR = cheekL.clone(); cheekR.position.x = 0.105; g.add(cheekR);
  const hair = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.225, 0.12, 9), suitDark);
  hair.position.y = 2.00; g.add(hair);
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.068, 8, 6), eyeWhite);
  eyeL.scale.z = 0.35; eyeL.position.set(-0.087, 1.875, -0.205); g.add(eyeL);
  const eyeR = eyeL.clone(); eyeR.position.x = 0.087; g.add(eyeR);
  const pupilL = new THREE.Mesh(new THREE.SphereGeometry(0.027, 7, 5), pupil);
  pupilL.position.set(-0.087, 1.875, -0.232); g.add(pupilL);
  const pupilR = pupilL.clone(); pupilR.position.x = 0.087; g.add(pupilR);
  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.13, 6), skin);
  nose.rotation.x = -Math.PI / 2; nose.position.set(0, 1.80, -0.235); g.add(nose);
  const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.065, 0.48, 4, 7), suit);
  armL.position.set(-0.29, 1.18, 0); g.add(armL);
  const armR = armL.clone(); armR.position.x = 0.29; g.add(armR);
  const handL = new THREE.Mesh(new THREE.SphereGeometry(0.068, 7, 5), skin);
  handL.scale.y = 1.2; handL.position.set(-0.29, 0.83, 0); g.add(handL);
  const handR = handL.clone(); handR.position.x = 0.29; g.add(handR);
  const legL = new THREE.Mesh(new THREE.CapsuleGeometry(0.085, 0.57, 4, 7), suitDark);
  legL.position.set(-0.115, 0.43, 0); g.add(legL);
  const legR = legL.clone(); legR.position.x = 0.115; g.add(legR);
  const shoeL = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.075, 0.32), suitDark);
  shoeL.position.set(-0.115, 0.055, -0.035); g.add(shoeL);
  const shoeR = shoeL.clone(); shoeR.position.x = 0.115; g.add(shoeR);
  return g;
}

function createGazeBeastMesh() {
  const g = new THREE.Group();
  const fur = new THREE.MeshLambertMaterial({ color: 0x302824 });
  const furDark = new THREE.MeshLambertMaterial({ color: 0x171313 });
  const muzzle = new THREE.MeshLambertMaterial({ color: 0x62514b });
  const eyeMat = new THREE.MeshLambertMaterial({ color: 0x050505 });
  const clawMat = new THREE.MeshLambertMaterial({ color: 0x4b403b });
  const body = new THREE.Mesh(new THREE.SphereGeometry(0.42, 9, 7), fur);
  body.scale.set(1.0, 1.25, 0.72); body.rotation.x = -0.48; body.position.set(0, 0.91, 0.06); g.add(body);
  const shoulder = new THREE.Mesh(new THREE.SphereGeometry(0.38, 8, 6), fur);
  shoulder.scale.set(1.2, 0.8, 0.72); shoulder.position.set(0, 1.28, -0.02); g.add(shoulder);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.31, 9, 7), fur);
  head.scale.set(1.0, 0.92, 0.85); head.position.set(0, 1.47, -0.19); g.add(head);
  const muzzleMesh = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.52, 8), muzzle);
  muzzleMesh.rotation.x = Math.PI / 2; muzzleMesh.position.set(0, 1.43, -0.52); g.add(muzzleMesh);
  const nose = new THREE.Mesh(new THREE.SphereGeometry(0.085, 7, 5), furDark);
  nose.scale.z = 0.5; nose.position.set(0, 1.43, -0.77); g.add(nose);
  [[-0.15,1.53,-0.43],[0.15,1.53,-0.43],[-0.09,1.45,-0.49],[0.09,1.45,-0.49],[-0.18,1.43,-0.43],[0.18,1.43,-0.43],[-0.07,1.58,-0.40],[0.07,1.58,-0.40]].forEach(p => {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 5), eyeMat);
    eye.position.set(p[0], p[1], p[2]); g.add(eye);
  });
  const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.085, 0.66, 4, 7), fur);
  armL.position.set(-0.42, 0.78, -0.18); armL.rotation.z = -0.18; armL.rotation.x = -0.18; g.add(armL);
  const armR = armL.clone(); armR.position.x = 0.42; armR.rotation.z = 0.18; g.add(armR);
  const handL = new THREE.Mesh(new THREE.SphereGeometry(0.09, 7, 5), clawMat);
  handL.scale.y = 1.35; handL.position.set(-0.50, 0.34, -0.25); g.add(handL);
  const handR = handL.clone(); handR.position.x = 0.50; g.add(handR);
  for (let i = 0; i < 4; i++) {
    const fingerL = new THREE.Mesh(new THREE.CapsuleGeometry(0.018, 0.13, 3, 5), clawMat);
    fingerL.position.set(-0.55 + i * 0.035, 0.23, -0.28); fingerL.rotation.z = -0.12; g.add(fingerL);
    const fingerR = fingerL.clone(); fingerR.position.x = 0.55 - i * 0.035; fingerR.rotation.z = 0.12; g.add(fingerR);
  }
  const thighL = new THREE.Mesh(new THREE.CapsuleGeometry(0.14, 0.38, 4, 7), furDark);
  thighL.position.set(-0.22, 0.50, 0.08); thighL.rotation.z = -0.16; g.add(thighL);
  const thighR = thighL.clone(); thighR.position.x = 0.22; thighR.rotation.z = 0.16; g.add(thighR);
  const shinL = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.30, 4, 7), furDark);
  shinL.position.set(-0.29, 0.21, -0.04); shinL.rotation.z = 0.18; g.add(shinL);
  const shinR = shinL.clone(); shinR.position.x = 0.29; shinR.rotation.z = -0.18; g.add(shinR);
  const footL = new THREE.Mesh(new THREE.SphereGeometry(0.13, 7, 5), furDark);
  footL.scale.set(0.75, 0.45, 1.5); footL.position.set(-0.32, 0.07, -0.14); g.add(footL);
  const footR = footL.clone(); footR.position.x = 0.32; g.add(footR);
  return g;
}

function createHungryZombieMesh() {
  const g = new THREE.Group();
  const skin = new THREE.MeshLambertMaterial({ color: 0x65705d });
  const skinDark = new THREE.MeshLambertMaterial({ color: 0x3f4a3c });
  const shirt = new THREE.MeshLambertMaterial({ color: 0x686762 });
  const pants = new THREE.MeshLambertMaterial({ color: 0x292729 });
  const blood = new THREE.MeshLambertMaterial({ color: 0x4b1515 });
  const mouthMat = new THREE.MeshLambertMaterial({ color: 0x120b0b });
  const teeth = new THREE.MeshLambertMaterial({ color: 0xb5ad8e });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.25, 0.57, 5, 8), shirt);
  torso.scale.z = 0.62; torso.position.y = 1.20; g.add(torso);
  const tearL = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.25, 0.035), skinDark);
  tearL.position.set(-0.16, 1.31, -0.19); tearL.rotation.z = -0.18; g.add(tearL);
  const tearR = tearL.clone(); tearR.position.x = 0.15; tearR.rotation.z = 0.22; g.add(tearR);
  const chestWound = new THREE.Mesh(new THREE.SphereGeometry(0.17, 8, 6), blood);
  chestWound.scale.set(1.0, 1.35, 0.28); chestWound.position.set(0, 1.25, -0.215); g.add(chestWound);
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.105, 0.18, 7), skin);
  neck.position.y = 1.67; g.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.245, 9, 7), skin);
  head.scale.set(0.91, 1.12, 0.85); head.position.y = 1.84; g.add(head);
  const mouth = new THREE.Mesh(new THREE.SphereGeometry(0.105, 8, 6), mouthMat);
  mouth.scale.set(1.15, 1.55, 0.42); mouth.position.set(0, 1.73, -0.225); g.add(mouth);
  const toothTop = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.025, 0.025), teeth);
  toothTop.position.set(0, 1.79, -0.26); g.add(toothTop);
  const toothBottom = toothTop.clone(); toothBottom.position.y = 1.66; g.add(toothBottom);
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.045, 6, 5), skinDark);
  eyeL.position.set(-0.09, 1.87, -0.22); g.add(eyeL);
  const eyeR = eyeL.clone(); eyeR.position.x = 0.09; g.add(eyeR);
  const reachingUpper = new THREE.Mesh(new THREE.CapsuleGeometry(0.085, 0.42, 4, 7), shirt);
  reachingUpper.position.set(0.34, 1.22, -0.13); reachingUpper.rotation.z = -0.50; reachingUpper.rotation.x = -0.35; g.add(reachingUpper);
  const reachingForearm = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.42, 4, 7), skin);
  reachingForearm.position.set(0.62, 1.02, -0.42); reachingForearm.rotation.z = -0.32; reachingForearm.rotation.x = -0.72; g.add(reachingForearm);
  const reachingHand = new THREE.Mesh(new THREE.SphereGeometry(0.10, 7, 5), skin);
  reachingHand.position.set(0.72, 0.91, -0.63); g.add(reachingHand);
  for (let i = 0; i < 4; i++) {
    const finger = new THREE.Mesh(new THREE.CapsuleGeometry(0.018, 0.13, 3, 5), skin);
    finger.position.set(0.65 + i * 0.045, 0.88, -0.70); finger.rotation.x = -0.65; g.add(finger);
  }
  const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.53, 4, 7), shirt);
  armL.position.set(-0.32, 1.03, 0); armL.rotation.z = 0.10; g.add(armL);
  const handL = new THREE.Mesh(new THREE.SphereGeometry(0.085, 7, 5), skin);
  handL.position.set(-0.34, 0.66, -0.02); g.add(handL);
  const legL = new THREE.Mesh(new THREE.CapsuleGeometry(0.105, 0.50, 4, 7), pants);
  legL.position.set(-0.13, 0.43, 0); g.add(legL);
  const legR = legL.clone(); legR.position.x = 0.13; g.add(legR);
  const shoeL = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.08, 0.34), pants);
  shoeL.position.set(-0.13, 0.055, -0.04); g.add(shoeL);
  const shoeR = shoeL.clone(); shoeR.position.x = 0.13; g.add(shoeR);
  return g;
}

function createBackwatcherMesh() {
  const g = new THREE.Group();
  const bodyMat = new THREE.MeshLambertMaterial({ color: 0x24201f });
  const skin = new THREE.MeshLambertMaterial({ color: 0x746965 });
  const dark = new THREE.MeshLambertMaterial({ color: 0x0e0d0d });
  const eyeMat = new THREE.MeshLambertMaterial({ color: 0x080707 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.58, 5, 7), bodyMat);
  torso.scale.set(0.78, 1.08, 0.60); torso.position.y = 1.18; g.add(torso);
  const shoulders = new THREE.Mesh(new THREE.SphereGeometry(0.29, 8, 6), bodyMat);
  shoulders.scale.set(1.25, 0.55, 0.65); shoulders.position.y = 1.45; g.add(shoulders);
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.095, 0.22, 7), skin);
  neck.position.y = 1.67; g.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.225, 9, 7), skin);
  head.scale.set(0.9, 1.08, 0.86); head.position.set(0.08, 1.82, 0.04);
  head.rotation.y = Math.PI; head.rotation.z = -0.38; g.add(head);
  const face = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 6), skin);
  face.scale.set(0.9, 1.05, 0.45); face.position.set(0.01, 1.80, 0.25); g.add(face);
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.032, 6, 5), eyeMat);
  eyeL.position.set(-0.07, 1.84, 0.34); g.add(eyeL);
  const eyeR = eyeL.clone(); eyeR.position.x = 0.10; g.add(eyeR);
  const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.065, 0.52, 4, 7), bodyMat);
  armL.position.set(-0.29, 1.04, 0); armL.rotation.z = 0.08; g.add(armL);
  const armR = armL.clone(); armR.position.x = 0.29; armR.rotation.z = -0.08; g.add(armR);
  const thighL = new THREE.Mesh(new THREE.CapsuleGeometry(0.12, 0.38, 4, 7), dark);
  thighL.position.set(-0.17, 0.54, 0); thighL.rotation.z = -0.18; g.add(thighL);
  const thighR = thighL.clone(); thighR.position.x = 0.17; thighR.rotation.z = 0.18; g.add(thighR);
  const shinL = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.32, 4, 7), dark);
  shinL.position.set(-0.24, 0.22, -0.02); shinL.rotation.z = 0.12; g.add(shinL);
  const shinR = shinL.clone(); shinR.position.x = 0.24; shinR.rotation.z = -0.12; g.add(shinR);
  const footL = new THREE.Mesh(new THREE.SphereGeometry(0.13, 7, 5), dark);
  footL.scale.set(0.75, 0.45, 1.4); footL.position.set(-0.26, 0.06, -0.08); g.add(footL);
  const footR = footL.clone(); footR.position.x = 0.26; g.add(footR);
  return g;
}

function createPaleGirlMesh() {
  const g = new THREE.Group();
  const suit = new THREE.MeshLambertMaterial({ color: 0x141318 });
  const hairMat = new THREE.MeshLambertMaterial({ color: 0x050506 });
  const skin = new THREE.MeshLambertMaterial({ color: 0xd0c4bd });
  const eyeWhite = new THREE.MeshLambertMaterial({ color: 0xe7e2d9 });
  const pupil = new THREE.MeshLambertMaterial({ color: 0x080708 });
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.39, 0.58, 0.25), suit);
  torso.position.y = 1.30; g.add(torso);
  const skirt = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.58, 10), suit);
  skirt.position.y = 0.82; g.add(skirt);
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.10, 0.14, 8), skin);
  neck.position.y = 1.65; g.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 9, 7), skin);
  head.scale.set(0.88, 1.12, 0.85); head.position.y = 1.82; g.add(head);
  const hair = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.30, 0.65, 10), hairMat);
  hair.scale.z = 0.8; hair.position.set(0, 1.75, 0.02); g.add(hair);
  const hairFront = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.55, 0.14), hairMat);
  hairFront.position.set(0, 1.78, -0.22); g.add(hairFront);
  for (let i = 0; i < 6; i++) {
    const strand = new THREE.Mesh(new THREE.CapsuleGeometry(0.025, 0.5, 3, 5), hairMat);
    strand.position.set((i - 2.5) * 0.06, 1.45, -0.28); strand.rotation.x = 0.35; g.add(strand);
  }
  const visibleEye = new THREE.Mesh(new THREE.SphereGeometry(0.045, 7, 5), eyeWhite);
  visibleEye.scale.z = 0.35; visibleEye.position.set(0.10, 1.84, -0.285); g.add(visibleEye);
  const visiblePupil = new THREE.Mesh(new THREE.SphereGeometry(0.020, 6, 5), pupil);
  visiblePupil.position.set(0.10, 1.84, -0.302); g.add(visiblePupil);
  const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.062, 0.48, 4, 7), suit);
  armL.position.set(-0.265, 1.25, 0); g.add(armL);
  const armR = armL.clone(); armR.position.x = 0.265; g.add(armR);
  const handL = new THREE.Mesh(new THREE.SphereGeometry(0.065, 7, 5), skin);
  handL.position.set(-0.265, 0.88, 0); g.add(handL);
  const handR = handL.clone(); handR.position.x = 0.265; g.add(handR);
  const legL = new THREE.Mesh(new THREE.CapsuleGeometry(0.065, 0.37, 4, 6), skin);
  legL.position.set(-0.10, 0.27, 0); g.add(legL);
  const legR = legL.clone(); legR.position.x = 0.10; g.add(legR);
  const shoeL = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.07, 0.27), hairMat);
  shoeL.position.set(-0.10, 0.045, -0.04); g.add(shoeL);
  const shoeR = shoeL.clone(); shoeR.position.x = 0.10; g.add(shoeR);
  return g;
}

function createToyGirlMesh() {
  const g = new THREE.Group();
  const dressMat = new THREE.MeshLambertMaterial({ color: 0x292426 });
  const dressDark = new THREE.MeshLambertMaterial({ color: 0x171416 });
  const porcelain = new THREE.MeshLambertMaterial({ color: 0xc9c1b8 });
  const crack = new THREE.MeshLambertMaterial({ color: 0x393233 });
  const eyeMat = new THREE.MeshLambertMaterial({ color: 0x151215 });
  const teddyMat = new THREE.MeshLambertMaterial({ color: 0x604a3d });
  const dress = new THREE.Mesh(new THREE.ConeGeometry(0.27, 0.47, 9), dressMat);
  dress.position.y = 0.57; g.add(dress);
  const collar = new THREE.Mesh(new THREE.TorusGeometry(0.105, 0.025, 5, 8), porcelain);
  collar.rotation.x = Math.PI / 2; collar.position.y = 0.82; g.add(collar);
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.065, 0.10, 7), porcelain);
  neck.position.y = 0.87; g.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.20, 9, 7), porcelain);
  head.scale.set(0.94, 1.05, 0.85); head.position.y = 1.04; g.add(head);
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.215, 8, 6), dressDark);
  hair.scale.set(1.08, 0.72, 0.88); hair.position.set(0, 1.13, 0.015); g.add(hair);
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.032, 6, 5), eyeMat);
  eyeL.position.set(-0.075, 1.06, -0.175); g.add(eyeL);
  const eyeR = eyeL.clone(); eyeR.position.x = 0.075; g.add(eyeR);
  const smile = new THREE.Mesh(new THREE.TorusGeometry(0.055, 0.012, 4, 8, Math.PI), crack);
  smile.rotation.x = Math.PI; smile.position.set(0, 0.97, -0.18); g.add(smile);
  const crackLine = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.14, 0.008), crack);
  crackLine.position.set(0.035, 1.10, -0.182); crackLine.rotation.z = 0.25; g.add(crackLine);
  const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.045, 0.28, 4, 6), dressMat);
  armL.position.set(-0.22, 0.66, 0); armL.rotation.z = 0.18; g.add(armL);
  const armR = armL.clone(); armR.position.x = 0.22; armR.rotation.z = -0.18; g.add(armR);
  const teddyBody = new THREE.Mesh(new THREE.SphereGeometry(0.085, 7, 5), teddyMat);
  teddyBody.scale.y = 1.25; teddyBody.position.set(0.28, 0.53, -0.15); g.add(teddyBody);
  const teddyHead = new THREE.Mesh(new THREE.SphereGeometry(0.065, 7, 5), teddyMat);
  teddyHead.position.set(0.28, 0.65, -0.16); g.add(teddyHead);
  const teddyEarL = new THREE.Mesh(new THREE.SphereGeometry(0.028, 6, 5), teddyMat);
  teddyEarL.position.set(0.235, 0.70, -0.15); g.add(teddyEarL);
  const teddyEarR = teddyEarL.clone(); teddyEarR.position.x = 0.325; g.add(teddyEarR);
  const handL = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 5), porcelain);
  handL.position.set(-0.24, 0.47, 0); g.add(handL);
  const handR = handL.clone(); handR.position.set(0.25, 0.54, -0.13); g.add(handR);
  const legL = new THREE.Mesh(new THREE.CapsuleGeometry(0.052, 0.23, 4, 6), porcelain);
  legL.position.set(-0.085, 0.22, 0); g.add(legL);
  const legR = legL.clone(); legR.position.x = 0.085; g.add(legR);
  const shoeL = new THREE.Mesh(new THREE.BoxGeometry(0.10, 0.06, 0.18), dressDark);
  shoeL.position.set(-0.085, 0.035, -0.025); g.add(shoeL);
  const shoeR = shoeL.clone(); shoeR.position.x = 0.085; g.add(shoeR);
  return g;
}

function createBloodCrierMesh() {
  const g = new THREE.Group();
  const skin = new THREE.MeshLambertMaterial({ color: 0xb7a49d });
  const shirt = new THREE.MeshLambertMaterial({ color: 0xd0cbc0 });
  const pants = new THREE.MeshLambertMaterial({ color: 0x252327 });
  const blood = new THREE.MeshLambertMaterial({ color: 0x5a1415 });
  const mouthMat = new THREE.MeshLambertMaterial({ color: 0x12090a });
  const teeth = new THREE.MeshLambertMaterial({ color: 0xb8ae93 });
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.70, 0.28), shirt);
  torso.position.y = 1.20; g.add(torso);
  const bloodFront = new THREE.Mesh(new THREE.SphereGeometry(0.21, 8, 6), blood);
  bloodFront.scale.set(0.95, 1.65, 0.30); bloodFront.position.set(0, 1.21, -0.185); g.add(bloodFront);
  for (let i = 0; i < 4; i++) {
    const streak = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.025, 0.30 + i * 0.04, 6), blood);
    streak.position.set(-0.16 + i * 0.105, 1.03 - (i % 2) * 0.08, -0.22); g.add(streak);
  }
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.095, 0.17, 7), skin);
  neck.position.y = 1.66; g.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.24, 9, 7), skin);
  head.scale.set(0.91, 1.13, 0.85); head.position.y = 1.82; g.add(head);
  const mouth = new THREE.Mesh(new THREE.SphereGeometry(0.115, 8, 6), mouthMat);
  mouth.scale.set(1.20, 1.70, 0.42); mouth.position.set(0, 1.73, -0.225); g.add(mouth);
  const upperTeeth = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.027, 0.025), teeth);
  upperTeeth.position.set(0, 1.82, -0.265); g.add(upperTeeth);
  const lowerTeeth = upperTeeth.clone(); lowerTeeth.position.y = 1.64; g.add(lowerTeeth);
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.043, 6, 5), blood);
  eyeL.position.set(-0.09, 1.87, -0.22); g.add(eyeL);
  const eyeR = eyeL.clone(); eyeR.position.x = 0.09; g.add(eyeR);
  const tearL = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.012, 0.14, 5), blood);
  tearL.position.set(-0.09, 1.77, -0.23); g.add(tearL);
  const tearR = tearL.clone(); tearR.position.x = 0.09; g.add(tearR);
  const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.47, 4, 7), shirt);
  armL.position.set(-0.33, 1.27, -0.05); armL.rotation.z = -0.62; armL.rotation.x = -0.18; g.add(armL);
  const armR = armL.clone(); armR.position.x = 0.33; armR.rotation.z = 0.62; g.add(armR);
  const handL = new THREE.Mesh(new THREE.SphereGeometry(0.09, 7, 5), skin);
  handL.position.set(-0.53, 1.48, -0.18); g.add(handL);
  const handR = handL.clone(); handR.position.x = 0.53; g.add(handR);
  for (let i = 0; i < 4; i++) {
    const fingerL = new THREE.Mesh(new THREE.CapsuleGeometry(0.017, 0.13, 3, 5), skin);
    fingerL.position.set(-0.55 + i * 0.035, 1.52 + Math.abs(i - 1.5) * 0.035, -0.20); fingerL.rotation.z = -0.35; g.add(fingerL);
    const fingerR = fingerL.clone(); fingerR.position.x = 0.55 - i * 0.035; fingerR.rotation.z = 0.35; g.add(fingerR);
  }
  const legL = new THREE.Mesh(new THREE.CapsuleGeometry(0.10, 0.49, 4, 7), pants);
  legL.position.set(-0.13, 0.43, 0); g.add(legL);
  const legR = legL.clone(); legR.position.x = 0.13; g.add(legR);
  const shoeL = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.08, 0.33), pants);
  shoeL.position.set(-0.13, 0.055, -0.035); g.add(shoeL);
  const shoeR = shoeL.clone(); shoeR.position.x = 0.13; g.add(shoeR);
  return g;
}

function createShadowStepMesh() {
  const g = new THREE.Group();
  const shadow = new THREE.MeshLambertMaterial({ color: 0x030305 });
  const redEyes = new THREE.MeshLambertMaterial({ color: 0xff2222, emissive: 0xaa0000, emissiveIntensity: 0.8 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.20, 0.74, 4, 7), shadow);
  torso.scale.set(0.72, 1.18, 0.52); torso.position.y = 1.25; g.add(torso);
  const shoulders = new THREE.Mesh(new THREE.SphereGeometry(0.27, 7, 5), shadow);
  shoulders.scale.set(1.05, 0.55, 0.55); shoulders.position.y = 1.55; g.add(shoulders);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.21, 8, 6), shadow);
  head.scale.set(0.80, 1.10, 0.72); head.position.y = 1.91; g.add(head);
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.022, 6, 5), redEyes);
  eyeL.position.set(-0.068, 1.93, -0.18); g.add(eyeL);
  const eyeR = eyeL.clone(); eyeR.position.x = 0.068; g.add(eyeR);
  const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.75, 4, 7), shadow);
  armL.position.set(-0.30, 1.08, 0); armL.rotation.z = 0.035; g.add(armL);
  const armR = armL.clone(); armR.position.x = 0.30; armR.rotation.z = -0.035; g.add(armR);
  const handL = new THREE.Mesh(new THREE.SphereGeometry(0.058, 6, 5), shadow);
  handL.position.set(-0.31, 0.53, 0); g.add(handL);
  const handR = handL.clone(); handR.position.x = 0.31; g.add(handR);
  const legL = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.66, 4, 7), shadow);
  legL.position.set(-0.115, 0.43, 0); g.add(legL);
  const legR = legL.clone(); legR.position.x = 0.115; g.add(legR);
  const footL = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.06, 0.29), shadow);
  footL.position.set(-0.115, 0.04, -0.035); g.add(footL);
  const footR = footL.clone(); footR.position.x = 0.115; g.add(footR);
  return g;
}

function createWhisperDollMesh() {
  const g = new THREE.Group();
  const dress = new THREE.MeshLambertMaterial({ color: 0x453c3a });
  const dressDark = new THREE.MeshLambertMaterial({ color: 0x211d1e });
  const skin = new THREE.MeshLambertMaterial({ color: 0xa89d94 });
  const crack = new THREE.MeshLambertMaterial({ color: 0x272224 });
  const mouthMat = new THREE.MeshLambertMaterial({ color: 0x0d090a });
  const body = new THREE.Mesh(new THREE.ConeGeometry(0.25, 0.46, 8), dress);
  body.position.y = 0.50; g.add(body);
  for (let i = 0; i < 5; i++) {
    const fray = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.16, 5), dressDark);
    fray.position.set(-0.18 + i * 0.09, 0.30 + (i % 2) * 0.035, 0); g.add(fray);
  }
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.09, 6), skin);
  neck.position.y = 0.78; g.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 7), skin);
  head.scale.set(0.94, 1.08, 0.84); head.position.y = 0.94; g.add(head);
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.19, 8, 6), dressDark);
  hair.scale.set(1.06, 0.80, 0.88); hair.position.set(0, 1.00, 0.01); g.add(hair);
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.027, 6, 5), crack);
  eyeL.position.set(-0.06, 0.96, -0.16); g.add(eyeL);
  const eyeR = eyeL.clone(); eyeR.position.x = 0.06; g.add(eyeR);
  const mouth = new THREE.Mesh(new THREE.TorusGeometry(0.045, 0.014, 5, 8), mouthMat);
  mouth.position.set(0, 0.88, -0.17); g.add(mouth);
  const crackLine = new THREE.Mesh(new THREE.BoxGeometry(0.010, 0.13, 0.008), crack);
  crackLine.position.set(-0.035, 1.02, -0.17); crackLine.rotation.z = -0.28; g.add(crackLine);
  const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.042, 0.28, 4, 6), dress);
  armL.position.set(-0.22, 0.57, 0); armL.rotation.z = 0.12; g.add(armL);
  const armR = armL.clone(); armR.position.x = 0.22; armR.rotation.z = -0.12; g.add(armR);
  const handL = new THREE.Mesh(new THREE.SphereGeometry(0.045, 6, 5), skin);
  handL.position.set(-0.24, 0.37, 0); g.add(handL);
  const handR = handL.clone(); handR.position.x = 0.24; g.add(handR);
  const legL = new THREE.Mesh(new THREE.CapsuleGeometry(0.048, 0.25, 4, 6), skin);
  legL.position.set(-0.08, 0.19, 0); g.add(legL);
  const legR = legL.clone(); legR.position.x = 0.08; g.add(legR);
  const shoeL = new THREE.Mesh(new THREE.BoxGeometry(0.095, 0.055, 0.17), dressDark);
  shoeL.position.set(-0.08, 0.032, -0.02); g.add(shoeL);
  const shoeR = shoeL.clone(); shoeR.position.x = 0.08; g.add(shoeR);
  return g;
}


/* -------------------- ITEMS for counters -------------------- */
function placeNPCs() {
  // Meat on floor 4
  const meat = createItem(0x8b0000, 'meat');
  meat.position.set(-4, (4-1)*CONFIG.floorHeight + 0.4, 1.5);
  meat.userData = { type: 'item', item: 'meat' };
  scene.add(meat);
  interactables.push(meat);

  // Toy on floor 7
  const toy = createItem(0xff69b4, 'toy');
  toy.position.set(7, (7-1)*CONFIG.floorHeight + 0.4, -1.6);
  toy.userData = { type: 'item', item: 'toy' };
  scene.add(toy);
  interactables.push(toy);

  // Box on floor 7
  const box = new THREE.Mesh(
    new THREE.BoxGeometry(0.8, 0.5, 0.8),
    new THREE.MeshStandardMaterial({ color: 0x5a3a1a })
  );
  box.position.set(-2, (7-1)*CONFIG.floorHeight + 0.3, 1.7);
  box.userData = { type: 'box' };
  scene.add(box);
  interactables.push(box);
}

function createItem(color, name) {
  const g = new THREE.Group();
  const m = new THREE.Mesh(
    new THREE.SphereGeometry(0.25, 10, 8),
    new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.3 })
  );
  g.add(m);
  // no point light
  return g;
}

/* -------------------- CONTROLS -------------------- */
function setupKeys() {
  const on = (e, p) => {
    switch (e.code) {
      case 'KeyW': case 'ArrowUp':    move.f = p; break;
      case 'KeyS': case 'ArrowDown':  move.b = p; break;
      case 'KeyA': case 'ArrowLeft':  move.l = p; break;
      case 'KeyD': case 'ArrowRight': move.r = p; break;
      case 'KeyE': case 'Space': if (p) tryInteract(); break;
      case 'KeyQ': case 'KeyF': if (p) tryStun(); break;
    }
  };
  addEventListener('keydown', e => on(e, true));
  addEventListener('keyup',   e => on(e, false));
}


function setupMobile() {
  const base = document.getElementById('joystick-base');
  const stick = document.getElementById('joystick-stick');
  const lookZone = document.getElementById('look-zone');
  const interactBtn = document.getElementById('interact-btn');
  const stunBtn = document.getElementById('stun-btn');

  let joyId = null, lookId = null;
  let lastX = 0, lastY = 0;

  // --- JOYSTICK (left) ---
  if (base) {
    base.addEventListener('touchstart', e => {
      e.preventDefault();
      e.stopPropagation();
      const t = e.changedTouches[0];
      joyId = t.identifier;
    }, { passive: false });
  }

  // --- LOOK (right half of screen) ---
  if (lookZone) {
    lookZone.addEventListener('touchstart', e => {
      e.preventDefault();
      e.stopPropagation();
      const t = e.changedTouches[0];
      lookId = t.identifier;
      lastX = t.clientX;
      lastY = t.clientY;
    }, { passive: false });

    lookZone.addEventListener('touchmove', e => {
      e.preventDefault();
      e.stopPropagation();
      for (const t of e.changedTouches) {
        if (t.identifier !== lookId) continue;
        // Higher sensitivity so camera actually turns on phones
        const sens = 0.014;
        lookD.x += (t.clientX - lastX) * sens;
        lookD.y += (t.clientY - lastY) * sens;
        lastX = t.clientX;
        lastY = t.clientY;
      }
    }, { passive: false });

    lookZone.addEventListener('touchend', e => {
      for (const t of e.changedTouches) {
        if (t.identifier === lookId) lookId = null;
      }
    });
    lookZone.addEventListener('touchcancel', () => { lookId = null; });
  }

  // Global move for joystick only
  window.addEventListener('touchmove', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId && base) {
        e.preventDefault();
        const r = base.getBoundingClientRect();
        const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
        let dx = t.clientX - cx, dy = t.clientY - cy;
        const max = r.width / 2 - 8;
        const len = Math.hypot(dx, dy) || 1;
        if (len > max) { dx = dx / len * max; dy = dy / len * max; }
        if (stick) stick.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
        joy.x = dx / max;
        joy.y = -dy / max;
      }
    }
  }, { passive: false });

  window.addEventListener('touchend', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        joyId = null;
        if (stick) stick.style.transform = 'translate(-50%, -50%)';
        joy.x = 0; joy.y = 0;
      }
      if (t.identifier === lookId) lookId = null;
    }
  });

  if (interactBtn) {
    const doI = (e) => { e.preventDefault(); e.stopPropagation(); tryInteract(); };
    interactBtn.addEventListener('touchstart', doI, { passive: false });
    interactBtn.addEventListener('click', doI);
  }
  if (stunBtn) {
    const doS = (e) => { e.preventDefault(); e.stopPropagation(); tryStun(); };
    stunBtn.addEventListener('touchstart', doS, { passive: false });
    stunBtn.addEventListener('click', doS);
  }
}

/* -------------------- INTERACTION + ELEVATOR -------------------- */
function tryInteract() {
  if (gameOver) return;
  if (elevatorOpen && elevatorUI && !elevatorUI.classList.contains('hidden')) return;

  const mover = camera.position;

  // 1) Near elevator ends? Open floor menu immediately (most reliable)
  const halfL = CONFIG.corridorLength / 2;
  if (currentFloor !== 'Roof' && Math.abs(Math.abs(mover.x) - halfL) < 5.5 && Math.abs(mover.z) < 3.5) {
    openElevatorUI();
    return;
  }

  const origin = camera.getWorldPosition(new THREE.Vector3());
  const dir = camera.getWorldDirection(new THREE.Vector3());
  raycaster.set(origin, dir);
  raycaster.far = 5.0;

  const hits = raycaster.intersectObjects(interactables, true);
  let obj = null;
  if (hits.length) {
    obj = hits[0].object;
    while (obj && !obj.userData.type) obj = obj.parent;
  }

  if (!obj || (obj.userData.type !== 'elevator' && obj.userData.type !== 'elevator-btn' && obj.userData.type !== 'floor-btn')) {
    const near = interactables.find(o => {
      if (!o.userData || !o.userData.type) return false;
      const wp = new THREE.Vector3();
      o.getWorldPosition(wp);
      return wp.distanceTo(mover) < 5.0 && Math.abs(wp.y - mover.y) < 3.5;
    });
    if (near) obj = near;
  }

  if (!obj) return;
  const d = obj.userData;

  if (d.type === 'part' && !d.collected) {
    d.collected = true;
    partsCollected++;
    partsEl.textContent = `Parts: ${partsCollected} / ${TOTAL_PARTS}`;
    obj.visible = false;
    showMsg(`Part ${d.id} collected!`);
    if (partsCollected >= TOTAL_PARTS) {
      document.getElementById('objective').textContent = 'All parts found! Go to the roof and fix the helicopter.';
    }
  }
  else if (d.type === 'floor-btn') {
    startElevatorRide(d.targetFloor);
  }
  else if (d.type === 'elevator' || d.type === 'elevator-btn') {
    openElevatorUI(); // floor menu
  }
  else if (d.type === 'item') {
    holdingItem = d.item;
    obj.visible = false;
    showMsg(`Picked up ${d.item}`);
  }
  else if (d.type === 'box' && holdingItem === 'toy') {
    holdingItem = null;
    showMsg('Toy placed in the box. Toy Girl is calm and shows the part.');
  }
  else if (d.type === 'monster') {
    handleMonsterInteract(obj);
  }
}



function openElevatorUI() {
  // Minimal panel only as backup — prefer 3D buttons inside cabin
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (!ui) return;
  elevatorOpen = true;
  const box = document.getElementById('elevator-buttons');
  if (box) {
    [...box.querySelectorAll('button')].forEach(b => {
      b.classList.remove('current');
      if (String(currentFloor) === b.textContent || (currentFloor === 'Roof' && b.textContent === 'ROOF')) {
        b.classList.add('current');
      }
    });
  }
  const label = document.getElementById('elevator-current');
  if (label) label.textContent = currentFloor === 'Roof' ? 'Now: Roof' : `Now: Floor ${currentFloor}`;
  ui.classList.remove('hidden');
}

function startElevatorRide(target) {
  if (ridingElevator || gameOver) return;
  if (target !== 'roof' && Number(target) === Number(currentFloor)) {
    showMsg('Already here');
    return;
  }
  // close HTML panel if open
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (ui) ui.classList.add('hidden');
  elevatorOpen = false;

  ridingElevator = true;
  rideTarget = target;
  ridePhase = 'moving';
  let dist = 2;
  if (target === 'roof') dist = currentFloor === 'Roof' ? 1 : (11 - Number(currentFloor || 1));
  else if (currentFloor === 'Roof') dist = Number(target);
  else dist = Math.abs(Number(target) - Number(currentFloor)) || 1;
  rideTimer = 1.0 + dist * 0.65;
  showMsg(target === 'roof' ? 'Going to Roof…' : `Going to Floor ${target}…`);
  // pull into elevator opening
  const halfL = CONFIG.corridorLength / 2;
  const side = camera.position.x >= 0 ? 1 : -1;
  camera.position.x = side * (halfL - 1.5);
  camera.position.z = 0;
}

function goToFloor(f) {
  startElevatorRide(f);
}

function updateElevatorRide(dt) {
  if (!ridingElevator) return;
  rideTimer -= dt;
  if (rideTimer > 0) return;

  if (ridePhase === 'closing') {
    ridePhase = 'moving';
    // travel time depends on distance
    let dist = 3;
    if (rideTarget === 'roof') {
      dist = currentFloor === 'Roof' ? 1 : (11 - Number(currentFloor || 1));
    } else if (currentFloor === 'Roof') {
      dist = Number(rideTarget);
    } else {
      dist = Math.abs(Number(rideTarget) - Number(currentFloor)) || 1;
    }
    rideTimer = 1.2 + dist * 0.7; // slower = more realistic
    showMsg(rideTarget === 'roof' ? 'Going to Roof…' : `Going to Floor ${rideTarget}…`);
  } else if (ridePhase === 'moving') {
    // arrive
    const mover = camera;
    if (rideTarget === 'roof') {
      mover.position.set(0, CONFIG.floors * CONFIG.floorHeight + CONFIG.playerHeight, 0);
      currentFloor = 'Roof';
      if (floorInd) floorInd.textContent = 'Roof';
      showMsg('Roof');
      ridingElevator = false;
      ridePhase = null;
      if (partsCollected >= TOTAL_PARTS) {
        setTimeout(() => {
          if (winScreen) winScreen.classList.remove('hidden');
          gameOver = true;
        }, 600);
      } else {
        showMsg('Need all 10 parts for the helicopter');
      }
    } else {
      const floorNum = Number(rideTarget);
      const y = (floorNum - 1) * CONFIG.floorHeight + CONFIG.playerHeight;
      const side = camera.position.x >= 0 ? 1 : -1;
      const halfL = CONFIG.corridorLength / 2;
      mover.position.set(side * (halfL - 1.2), y, 0);
      currentFloor = floorNum;
      if (floorInd) floorInd.textContent = `Floor ${floorNum}`;
      // open doors on arrival floor
      ridingElevator = false;
      ridePhase = null;
      showMsg(`Floor ${floorNum}`);
    }
  } else if (ridePhase === 'opening') {
    ridingElevator = false;
    ridePhase = null;
    showMsg('Doors open');
  }
}

function handleMonsterInteract(m) {
  const k = m.userData.kind;
  if (k === 'hungry' && holdingItem === 'meat') {
    holdingItem = null;
    m.userData.alive = false;
    m.visible = false;
    showMsg('Hungry Zombie is satisfied. He leaves.');
  } else if (k === 'whisper') {
    showMsg('Whisper silenced… for now.');
    m.userData.state = 'calm';
  } else {
    showMsg(m.userData.desc);
  }
}

/* -------------------- MONSTER AI -------------------- */
function updateMonsters(dt) {
  if (gameOver) return;
  const playerPos = (isMobile || !controls) ? camera.position : controls.getObject().position;

  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor !== currentFloor && currentFloor !== 'Roof') return;

    // Stunned monsters do nothing
    if (m.userData.stunned) return;

    const kind = m.userData.kind;
    const toPlayer = new THREE.Vector3().subVectors(playerPos, m.position);
    const dist = toPlayer.length();
    toPlayer.y = 0;
    toPlayer.normalize();

    // Is player looking at monster?
    const lookDir = camera.getWorldDirection(new THREE.Vector3());
    const toM = new THREE.Vector3().subVectors(m.position, camera.position).normalize();
    const lookingAt = lookDir.dot(toM) > 0.85 && dist < 12;

    if (kind === 'watcher') {
      if (lookingAt) {
        // freeze
      } else if (dist > 1.5) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      } else kill('The Watcher caught you');
    }
    else if (kind === 'gaze') {
      if (lookingAt) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 2.0) kill('You stared too long at the Gaze Beast');
      } else {
        m.userData.lookTimer = Math.max(0, m.userData.lookTimer - dt * 0.5);
      }
    }
    else if (kind === 'hungry') {
      if (dist > 1.8) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (holdingItem !== 'meat') kill('The Hungry Zombie reached you');
    }
    else if (kind === 'backtext') {
      // if player is looking roughly away from monster while close
      const away = lookDir.dot(toM) < -0.3;
      if (away && dist < 8) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.2) kill('You looked at your back…');
      } else m.userData.lookTimer = 0;
      if (dist > 2) m.position.addScaledVector(toPlayer, m.userData.speed * 0.6 * dt);
    }
    else if (kind === 'stalker') {
      // moves toward where player is going
      const predict = playerPos.clone().add(lookDir.clone().multiplyScalar(3));
      const toPred = new THREE.Vector3().subVectors(predict, m.position);
      toPred.y = 0; toPred.normalize();
      if (dist > 1.6) m.position.addScaledVector(toPred, m.userData.speed * dt);
      else kill('The Pale Girl caught you');
    }
    else if (kind === 'toy') {
      if (holdingItem === 'toy') {
        // follows calmly
        if (dist > 2.5) m.position.addScaledVector(toPlayer, 1.5 * dt);
      } else if (dist < 2.0) {
        // aggressive until toy is placed
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      }
    }
    else if (kind === 'crier') {
      if (lookingAt && Math.abs(joy.x) + Math.abs(joy.y) < 0.1 && !move.f && !move.b && !move.l && !move.r) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.5) {
          m.userData.alive = false;
          m.visible = false;
          showMsg('Blood Crier calmed down and vanished.');
        }
      } else {
        m.userData.lookTimer = 0;
        if (dist > 1.7) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
        else kill('The Blood Crier reached you');
      }
    }
    else if (kind === 'shadowstep') {
      const moving = Math.abs(joy.x) + Math.abs(joy.y) > 0.1 || move.f || move.b || move.l || move.r;
      if (moving && dist > 1.5) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (!moving) { /* frozen */ }
      else kill('Shadow Step touched you');
    }
    else if (kind === 'whisper') {
      if (m.userData.state !== 'calm' && dist < 4) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 4) kill('The Whisper Doll’s voice took you');
      }
    }
  });
}

function kill(reason) {
  if (gameOver) return;
  if (gameMode === 'peaceful') {
    showMsg('Peaceful mode — you survive');
    return;
  }
  gameOver = true;
  showMsg(reason, 5000);
  setTimeout(() => location.reload(), 3500);
}

function killPlayer(msg) {
  if (gameMode === 'peaceful') {
    showMsg('Peaceful — survived');
    return;
  }
  showMsg(msg || 'You died…');
  gameOver = true;
}

function tryStun() {
  if (gameOver || stunCooldown > 0 || stunActive > 0) return;
  // Stun every monster on the current floor
  let hit = 0;
  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor === currentFloor || currentFloor === 'Roof') {
      m.userData.stunned = true;
      hit++;
    }
  });
  if (hit > 0) {
    stunActive = 3;
    stunCooldown = 15;
    showMsg(`Monster stunned for 3 seconds! (${hit})`);
  } else {
    showMsg('No monster on this floor');
    stunCooldown = 2; // small anti-spam
  }
  updateStunUI();
}

function updateStunUI() {
  const desk = document.getElementById('stun-btn-desktop');
  const setState = (btn, text, disabled) => {
    if (!btn) return;
    btn.disabled = disabled;
    btn.textContent = text;
  };
  if (stunCooldown > 0) {
    const t = Math.ceil(stunCooldown) + 's';
    setState(stunBtn, t, true);
    setState(desk, t, true);
    if (stunCdEl) stunCdEl.textContent = 'Cooldown';
  } else if (stunActive > 0) {
    setState(stunBtn, 'STUNNED', true);
    setState(desk, 'STUNNED', true);
  } else {
    setState(stunBtn, 'STUN', false);
    setState(desk, 'STUN (Q)', false);
    if (stunCdEl) stunCdEl.textContent = 'Ready';
  }
}

/* -------------------- ANIMATION -------------------- */
// Cap at ~45 FPS for stable mobile performance
const FPS_LIMIT = 30;
const FRAME_TIME = 1 / FPS_LIMIT;
let fpsAccum = 0;

function animate() {
  requestAnimationFrame(animate);
  const rawDt = clock.getDelta();
  fpsAccum += rawDt;
  if (fpsAccum < FRAME_TIME) return;
  const dt = Math.min(fpsAccum, 0.05);
  fpsAccum = 0;

  if (gameOver) {
    renderer.render(scene, camera);
    return;
  }

  // Stun timers
  if (stunActive > 0) {
    stunActive -= dt;
    if (stunActive <= 0) {
      stunActive = 0;
      monsters.forEach(m => { m.userData.stunned = false; });
    }
  }
  if (stunCooldown > 0) {
    stunCooldown -= dt;
    if (stunCooldown < 0) stunCooldown = 0;
  }
  updateStunUI();

  const speed = ridingElevator ? 0 : CONFIG.playerSpeed * dt;
  const forward = new THREE.Vector3();
  const right = new THREE.Vector3();
  const mover = isMobile || !controls ? camera : controls.getObject();

  if (isMobile) {
    camera.rotation.order = 'YXZ';
    camera.rotation.y -= lookD.x;
    camera.rotation.x -= lookD.y;
    camera.rotation.x = Math.max(-1.2, Math.min(1.2, camera.rotation.x));
    lookD.x = 0; lookD.y = 0;

    camera.getWorldDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    mover.position.addScaledVector(forward, joy.y * speed);
    mover.position.addScaledVector(right, joy.x * speed);
  } else if (controls && controls.isLocked) {
    controls.getDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    if (move.f) mover.position.addScaledVector(forward, speed);
    if (move.b) mover.position.addScaledVector(forward, -speed);
    if (move.l) mover.position.addScaledVector(right, -speed);
    if (move.r) mover.position.addScaledVector(right, speed);
  }

  // Bounds
  const halfL = CONFIG.corridorLength/2 - 1;
  const halfW = CONFIG.corridorWidth/2 - 0.7;
  mover.position.x = Math.max(-halfL, Math.min(halfL, mover.position.x));
  mover.position.z = Math.max(-halfW, Math.min(halfW, mover.position.z));

  // Floor height lock
  if (currentFloor !== 'Roof') {
    const targetY = (currentFloor - 1) * CONFIG.floorHeight + CONFIG.playerHeight;
    mover.position.y += (targetY - mover.position.y) * 0.3;
  }

  // PERF: only show current floor group (+ roof if needed)
  if (scene.userData.floorGroups) {
    const cf = currentFloor === 'Roof' ? CONFIG.floors : Number(currentFloor);
    scene.userData.floorGroups.forEach((g, i) => {
      const floorNum = i + 1;
      g.visible = (floorNum === cf || floorNum === cf - 1 || floorNum === cf + 1);
    });
  }

    updateElevatorRide(dt);

  // Hint when near elevator (no auto app panel)
  {
    const pos = camera.position;
    let inElev = false;
    if (currentFloor !== 'Roof') {
      for (const el of elevators) {
        if (el.floor !== currentFloor) continue;
        const wp = new THREE.Vector3();
        el.group.getWorldPosition(wp);
        // Standing at the wall elevator opening
        if (Math.abs(pos.x - wp.x) < 2.5 && Math.abs(pos.z - wp.z) < 2.2) {
          inElev = true;
          break;
        }
      }
      // Also detect by corridor ends
      const halfL = CONFIG.corridorLength / 2;
      if (Math.abs(Math.abs(pos.x) - halfL) < 2.8 && Math.abs(pos.z) < 2.5) {
        inElev = true;
      }
    }
    insideElevator = inElev;
    if (inElev && !elevPromptShown && !gameOver && !ridingElevator) {
      elevPromptShown = true;
      showMsg('INTERACT to open floor menu', 2000);
    }
    if (!inElev) elevPromptShown = false;
  }

  // No door animation — elevators always open


  updateMonsters(dt);
  multiplayerTick(dt);

  // Part spin only every other frame feel — cheap
  parts.forEach(p => {
    if (!p.userData.collected) p.rotation.y += dt * 0.8;
  });

  renderer.render(scene, camera);
}

function setupUI() {
  // Elevator buttons – large, mobile-friendly
  const box = document.getElementById('elevator-buttons');
  if (box) box.innerHTML = '';
  for (let i = 1; i <= 10; i++) {
    const b = document.createElement('button');
    b.textContent = i;
    b.type = 'button';
    const go = (e) => { e.preventDefault(); goToFloor(i); };
    b.addEventListener('click', go);
    b.addEventListener('touchend', go, { passive: false });
    box.appendChild(b);
  }
  const roofBtn = document.createElement('button');
  roofBtn.textContent = 'ROOF';
  roofBtn.className = 'roof';
  roofBtn.type = 'button';
  const goRoof = (e) => { e.preventDefault(); goToFloor('roof'); };
  roofBtn.addEventListener('click', goRoof);
  roofBtn.addEventListener('touchend', goRoof, { passive: false });
  box.appendChild(roofBtn);

  document.getElementById('elevator-close').onclick = () => {
    elevatorUI.classList.add('hidden');
    elevatorOpen = false;
  };

  // FLOORS HUD button removed — use elevator in the hall

  document.getElementById('dialogue-close').onclick = () => dialogue.classList.add('hidden');
  document.getElementById('restart-btn').onclick = () => location.reload();

  if (stunBtn) {
    stunBtn.addEventListener('click', tryStun);
    stunBtn.addEventListener('touchstart', e => { e.preventDefault(); tryStun(); }, { passive: false });
  }
  const stunDesk = document.getElementById('stun-btn-desktop');
  if (stunDesk) {
    stunDesk.addEventListener('click', tryStun);
  }

  let p = 0;
  const iv = setInterval(() => {
    p += 15;
    progressEl.style.width = Math.min(p, 95) + '%';
    if (p >= 95) clearInterval(iv);
  }, 60);
}

init().catch(console.error);

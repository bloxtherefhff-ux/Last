import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

const CONFIG = {
  playerHeight: 1.7,
  playerSpeed: 7,
  roomWidth: 4,
  roomDepth: 5,
  hallwayWidth: 2
};

let scene, camera, renderer, controls;
let currentFloor = 1;
let currentRoom = null; // 'hallway', 'room1', 'room2'
let partsCollected = 0;
const TOTAL_PARTS = 10;
let gameMode = 'normal';
let isMobile = false;
let move = { f: false, b: false, l: false, r: false };
let joy = { x: 0, y: 0 };
let lookD = { x: 0, y: 0 };
let monsters = [];
let interactables = [];
let clock = new THREE.Clock();
let gameOver = false;
let holdingItem = null;

const msgEl = document.getElementById('msg');
const partsEl = document.getElementById('parts');
const floorEl = document.getElementById('floor-indicator');

function showMsg(text, time = 3000) {
  if (!msgEl) return;
  msgEl.textContent = text;
  msgEl.classList.remove('hidden');
  setTimeout(() => msgEl.classList.add('hidden'), time);
}

function setupStartMenu() {
  const btnPlay = document.getElementById('btn-play');
  const btnN = document.getElementById('btn-normal');
  const btnP = document.getElementById('btn-peaceful');

  if (btnN) {
    btnN.addEventListener('click', (e) => {
      e.preventDefault();
      gameMode = 'normal';
      btnN.classList.add('active');
      btnP.classList.remove('active');
    });
  }

  if (btnP) {
    btnP.addEventListener('click', (e) => {
      e.preventDefault();
      gameMode = 'peaceful';
      btnP.classList.add('active');
      btnN.classList.remove('active');
    });
  }

  if (btnPlay) {
    btnPlay.addEventListener('click', (e) => {
      e.preventDefault();
      beginGame();
    });
  }
}

async function init() {
  setupStartMenu();
}

function beginGame() {
  const menu = document.getElementById('start-menu');
  const loading = document.getElementById('loading');
  const hud = document.getElementById('hud');

  if (menu) menu.classList.add('hidden');
  if (loading) loading.classList.remove('hidden');
  
  isMobile = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0f0f1e);
  scene.fog = null;

  camera = new THREE.PerspectiveCamera(75, innerWidth / innerHeight, 0.1, 100);
  camera.position.set(0, CONFIG.playerHeight, 0);
  camera.rotation.order = 'YXZ';

  renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
  renderer.setSize(innerWidth, innerHeight);
  renderer.setPixelRatio(1);
  renderer.shadowMap.enabled = false;
  renderer.domElement.style.position = 'fixed';
  renderer.domElement.style.inset = '0';
  renderer.domElement.style.zIndex = '1';
  document.body.appendChild(renderer.domElement);

  // Lighting
  scene.add(new THREE.AmbientLight(0xffffff, 0.8));
  const light1 = new THREE.PointLight(0xffffff, 2, 50);
  light1.position.set(0, 2, 0);
  scene.add(light1);

  if (!isMobile) {
    controls = new PointerLockControls(camera, renderer.domElement);
    renderer.domElement.addEventListener('click', () => {
      if (!controls.isLocked) controls.lock();
    });
  }

  loadFloor(1);
  setupMobile();
  setupKeys();

  setTimeout(() => {
    if (loading) loading.classList.add('hidden');
    if (hud) hud.classList.remove('hidden');
  }, 500);

  animate();
}

function loadFloor(floor) {
  // Clear scene
  while (scene.children.length > 2) {
    scene.remove(scene.children[2]);
  }
  monsters = [];
  interactables = [];

  currentFloor = floor;
  currentRoom = 'hallway';

  if (floorEl) floorEl.textContent = `Floor ${floor}`;

  // HALLWAY (center) - connects to 2 rooms
  createHallway();

  // LEFT ROOM
  createRoom('left', floor);

  // RIGHT ROOM
  createRoom('right', floor);

  camera.position.set(0, CONFIG.playerHeight, 0);
  camera.rotation.set(0, 0, 0);

  // Spawn one monster in hallway
  spawnMonster(floor, 0, 0);

  showMsg(`Floor ${floor} - Explore rooms to find parts`);
}

function createHallway() {
  // Floor
  const floor_mesh = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.hallwayWidth * 3, 0.2, CONFIG.roomDepth * 2),
    new THREE.MeshLambertMaterial({ color: 0x2a2a3a })
  );
  floor_mesh.position.y = -0.1;
  scene.add(floor_mesh);

  // Ceiling
  const ceil = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.hallwayWidth * 3, 0.2, CONFIG.roomDepth * 2),
    new THREE.MeshLambertMaterial({ color: 0x1a1a2a })
  );
  ceil.position.y = 3;
  scene.add(ceil);

  // Walls (left/right of hallway)
  for (const side of [-1, 1]) {
    const wall = new THREE.Mesh(
      new THREE.BoxGeometry(0.2, 3, CONFIG.roomDepth * 2),
      new THREE.MeshLambertMaterial({ color: 0x3a3a4a })
    );
    wall.position.x = side * (CONFIG.hallwayWidth / 2);
    wall.position.y = 1.5;
    scene.add(wall);
  }
}

function createRoom(side, floor) {
  const x = side === 'left' ? -(CONFIG.hallwayWidth + CONFIG.roomWidth / 2) : (CONFIG.hallwayWidth + CONFIG.roomWidth / 2);
  const z = 0;

  // Floor
  const floor_mesh = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.roomWidth, 0.2, CONFIG.roomDepth),
    new THREE.MeshLambertMaterial({ color: side === 'left' ? 0x5a3a3a : 0x3a3a5a })
  );
  floor_mesh.position.set(x, -0.1, z);
  scene.add(floor_mesh);

  // Ceiling
  const ceil = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.roomWidth, 0.2, CONFIG.roomDepth),
    new THREE.MeshLambertMaterial({ color: 0x1a1a2a })
  );
  ceil.position.set(x, 3, z);
  scene.add(ceil);

  // Walls
  // Back wall
  const backWall = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.roomWidth, 3, 0.2),
    new THREE.MeshLambertMaterial({ color: side === 'left' ? 0x6a4a4a : 0x4a4a6a })
  );
  backWall.position.set(x, 1.5, z - CONFIG.roomDepth / 2);
  scene.add(backWall);

  // Left/Right walls
  for (const wallSide of [-1, 1]) {
    const sideWall = new THREE.Mesh(
      new THREE.BoxGeometry(0.2, 3, CONFIG.roomDepth),
      new THREE.MeshLambertMaterial({ color: 0x3a3a4a })
    );
    sideWall.position.set(x + wallSide * (CONFIG.roomWidth / 2), 1.5, z);
    scene.add(sideWall);
  }

  // Front opening (no wall - connects to hallway)

  // Door frame
  const doorFrame = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.roomWidth, 0.3, 0.2),
    new THREE.MeshLambertMaterial({ color: 0x2a2a2a })
  );
  doorFrame.position.set(x, 2.8, z + CONFIG.roomDepth / 2);
  scene.add(doorFrame);

  // FURNITURE - create hiding spots for parts
  const furniture = [
    // Bed
    {
      geom: new THREE.BoxGeometry(2, 0.8, 1.5),
      pos: [x - 0.5, 0.4, z - 1.5],
      color: side === 'left' ? 0x8a5a4a : 0x5a5a8a,
      partPos: [x - 0.5, 0.2, z - 1.5] // PART hidden under bed
    },
    // Desk
    {
      geom: new THREE.BoxGeometry(1.5, 0.9, 0.8),
      pos: [x + 0.8, 0.45, z + 1],
      color: 0x6a4a3a,
      partPos: [x + 0.8, 0.95, z + 1] // PART on desk
    },
    // Couch
    {
      geom: new THREE.BoxGeometry(2.5, 0.8, 0.8),
      pos: [x - 0.2, 0.4, z + 0.5],
      color: side === 'left' ? 0x7a5a4a : 0x5a5a7a,
      partPos: [x - 0.2, 0.85, z + 0.5] // PART on couch back
    }
  ];

  furniture.forEach((f, i) => {
    const mesh = new THREE.Mesh(f.geom, new THREE.MeshLambertMaterial({ color: f.color }));
    mesh.position.set(f.pos[0], f.pos[1], f.pos[2]);
    scene.add(mesh);

    // Add part hidden in/on this furniture
    const part = createPart(currentFloor * 10 + i);
    part.position.set(f.partPos[0], f.partPos[1], f.partPos[2]);
    part.visible = true;
    scene.add(part);
    interactables.push(part);
  });
}

function createPart(id) {
  const g = new THREE.Group();
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.35, 0.35, 0.35),
    new THREE.MeshLambertMaterial({ color: 0xd4a84b, emissive: 0x8a6a1a, emissiveIntensity: 0.5 })
  );
  g.add(mesh);
  g.userData = { type: 'part', id, collected: false, floor: currentFloor };
  return g;
}

function spawnMonster(floor, x, z) {
  const kinds = ['watcher', 'gaze', 'hungry', 'backtext', 'stalker'];
  const kind = kinds[floor % kinds.length];

  const g = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.35, 1.4, 4, 8),
    new THREE.MeshLambertMaterial({ color: 0x1a1a1a })
  );
  g.position.set(x, 0.9, z);
  g.userData = {
    type: 'monster',
    kind,
    alive: true,
    speed: 1.5 + (floor * 0.3),
    floor,
    lookTimer: 0
  };

  // Monster name label
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.fillStyle = '#ff3333';
  ctx.font = 'bold 28px Arial';
  ctx.textAlign = 'center';
  const names = ['Watcher', 'Gaze Beast', 'Zombie', 'Backwatcher', 'Pale Girl'];
  ctx.fillText(names[floor % names.length], 128, 45);

  const texture = new THREE.CanvasTexture(canvas);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture }));
  sprite.scale.set(2, 0.5, 1);
  sprite.position.y = 2.2;
  g.add(sprite);

  scene.add(g);
  monsters.push(g);
}

function setupKeys() {
  const on = (e, p) => {
    switch (e.code) {
      case 'KeyW': case 'ArrowUp': move.f = p; break;
      case 'KeyS': case 'ArrowDown': move.b = p; break;
      case 'KeyA': case 'ArrowLeft': move.l = p; break;
      case 'KeyD': case 'ArrowRight': move.r = p; break;
      case 'KeyE': case 'Space': if (p) tryInteract(); break;
    }
  };
  addEventListener('keydown', e => on(e, true));
  addEventListener('keyup', e => on(e, false));
}

function setupMobile() {
  const joyBase = document.getElementById('joystick-base');
  const joyStick = document.getElementById('joystick-stick');
  const interactBtn = document.getElementById('interact-btn');

  let joyTouchId = null;
  let joyBaseX = 0, joyBaseY = 0;
  let lastLookX = 0, lastLookY = 0;
  let lookTouchId = null;

  document.addEventListener('touchstart', (e) => {
    for (const t of e.changedTouches) {
      const w = window.innerWidth;
      const h = window.innerHeight;

      if (t.clientX < w * 0.4 && t.clientY > h * 0.7) {
        joyTouchId = t.identifier;
        joyBaseX = t.clientX;
        joyBaseY = t.clientY;
        if (joyBase) {
          joyBase.style.left = (t.clientX - 40) + 'px';
          joyBase.style.top = (t.clientY - 40) + 'px';
          joyBase.style.opacity = '0.6';
        }
        e.preventDefault();
      } else {
        lookTouchId = t.identifier;
        lastLookX = t.clientX;
        lastLookY = t.clientY;
        e.preventDefault();
      }
    }
  }, { passive: false });

  document.addEventListener('touchmove', (e) => {
    const sens = 0.0015;

    for (const t of e.changedTouches) {
      if (t.identifier === joyTouchId) {
        const dx = t.clientX - joyBaseX;
        const dy = t.clientY - joyBaseY;
        const max = 60;
        const len = Math.hypot(dx, dy);

        if (len > 0) {
          const ratio = Math.min(1, len / max);
          joy.x = (dx / len) * ratio;
          joy.y = -(dy / len) * ratio;

          if (joyStick) {
            const clampedDx = len > max ? (dx / len) * max : dx;
            const clampedDy = len > max ? (dy / len) * max : dy;
            joyStick.style.transform = `translate(calc(-50% + ${clampedDx}px), calc(-50% + ${clampedDy}px))`;
          }
        }
        e.preventDefault();
      } else if (t.identifier === lookTouchId) {
        lookD.x += (t.clientX - lastLookX) * sens;
        lookD.y += (t.clientY - lastLookY) * sens;
        lastLookX = t.clientX;
        lastLookY = t.clientY;
        e.preventDefault();
      }
    }
  }, { passive: false });

  const endTouch = (e) => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyTouchId) {
        joyTouchId = null;
        joy.x = 0;
        joy.y = 0;
        if (joyBase) joyBase.style.opacity = '0';
        if (joyStick) joyStick.style.transform = 'translate(-50%, -50%)';
      }
      if (t.identifier === lookTouchId) lookTouchId = null;
    }
  };

  document.addEventListener('touchend', endTouch, { passive: false });
  document.addEventListener('touchcancel', endTouch, { passive: false });

  if (interactBtn) {
    interactBtn.addEventListener('click', tryInteract);
    interactBtn.addEventListener('touchend', (e) => { e.preventDefault(); tryInteract(); }, { passive: false });
  }
}

function tryInteract() {
  const origin = camera.getWorldPosition(new THREE.Vector3());
  const dir = camera.getWorldDirection(new THREE.Vector3());
  const raycaster = new THREE.Raycaster();
  raycaster.set(origin, dir);
  raycaster.far = 5;

  const hits = raycaster.intersectObjects(scene.children, true);
  if (hits.length === 0) {
    showMsg('Nothing here');
    return;
  }

  const obj = hits[0].object;

  if (obj.userData?.type === 'part' && !obj.userData.collected) {
    obj.userData.collected = true;
    partsCollected++;
    obj.visible = false;

    if (partsEl) partsEl.textContent = `Parts: ${partsCollected}/${TOTAL_PARTS}`;

    if (partsCollected === TOTAL_PARTS - 1) {
      // 9 parts collected - next room is escape
      showMsg('9/10 PARTS! Go to next floor to ESCAPE!', 4000);
    } else if (partsCollected < TOTAL_PARTS - 1) {
      showMsg(`Part ${partsCollected}/${TOTAL_PARTS - 1} - ${TOTAL_PARTS - 1 - partsCollected} more to escape!`);
    }

    // Check if we should trigger next floor
    if (partsCollected === TOTAL_PARTS - 1 && currentFloor < 10) {
      // Wait then go to next floor
      setTimeout(() => {
        goToNextFloor();
      }, 2000);
    } else if (partsCollected === TOTAL_PARTS) {
      // All parts - WIN!
      winGame();
    }
    return;
  }

  showMsg('Nothing to interact with');
}

function goToNextFloor() {
  if (currentFloor >= 10) {
    winGame();
    return;
  }

  currentFloor++;
  loadFloor(currentFloor);
  partsCollected = 0;
  showMsg(`Floor ${currentFloor} loaded!`);
}

function winGame() {
  gameOver = true;
  
  // Create WIN screen
  const winDiv = document.createElement('div');
  winDiv.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,0.95);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#d4a84b;font-family:Arial;text-align:center';
  
  winDiv.innerHTML = `
    <h1 style="font-size:3rem;margin:0;text-shadow:0 0 20px #d4a84b;">YOU ESCAPED!</h1>
    <p style="font-size:1.5rem;margin-top:20px;">Helicopter fixed and ready for takeoff...</p>
    <p style="font-size:1.2rem;color:#888;margin-top:40px;">Parts collected: ${partsCollected}</p>
    <button onclick="location.reload()" style="margin-top:40px;padding:15px 40px;font-size:1.2rem;background:#d4a84b;color:#000;border:none;border-radius:8px;cursor:pointer;font-weight:bold;">PLAY AGAIN</button>
  `;
  
  document.body.appendChild(winDiv);
  
  // Stop rendering
  renderer.domElement.style.display = 'none';
}

function kill(reason) {
  if (gameOver) return;
  
  if (gameMode === 'peaceful') {
    showMsg('Scary but survived (peaceful mode)', 2000);
    return;
  }

  gameOver = true;

  // JUMP SCARE EFFECT
  const scareDiv = document.createElement('div');
  scareDiv.style.cssText = 'position:fixed;inset:0;z-index:9998;background:#ff0000;opacity:0.8;animation:jumpscare 0.3s ease-out';
  
  // Add scary image (red flash + distortion)
  const canvas = document.createElement('canvas');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  canvas.style.cssText = 'position:fixed;inset:0;z-index:9999';
  
  const ctx = canvas.getContext('2d');
  // Red bloody effect
  ctx.fillStyle = 'rgba(255, 0, 0, 0.6)';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  // Draw scary face (simple skull shape)
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.arc(canvas.width / 2, canvas.height / 2, 80, 0, Math.PI * 2);
  ctx.fill();
  
  // Eyes
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.arc(canvas.width / 2 - 40, canvas.height / 2 - 30, 25, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(canvas.width / 2 + 40, canvas.height / 2 - 30, 25, 0, Math.PI * 2);
  ctx.fill();
  
  // Pupils (red)
  ctx.fillStyle = '#ff0000';
  ctx.beginPath();
  ctx.arc(canvas.width / 2 - 40, canvas.height / 2 - 30, 12, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(canvas.width / 2 + 40, canvas.height / 2 - 30, 12, 0, Math.PI * 2);
  ctx.fill();
  
  // Mouth
  ctx.strokeStyle = '#fff';
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.arc(canvas.width / 2, canvas.height / 2 + 20, 40, 0, Math.PI);
  ctx.stroke();
  
  document.body.appendChild(canvas);

  // Death message
  const deathDiv = document.createElement('div');
  deathDiv.style.cssText = 'position:fixed;inset:0;z-index:10000;display:flex;align-items:center;justify-content:center;color:#ff0000;font-family:Arial;font-size:2rem;font-weight:bold;text-shadow:0 0 30px #ff0000,0 0 60px #ff0000';
  deathDiv.textContent = reason;
  document.body.appendChild(deathDiv);

  // Sound effect (loud screech)
  playDeathSound();

  // Shake screen
  for (let i = 0; i < 5; i++) {
    setTimeout(() => {
      canvas.style.transform = `translate(${(Math.random() - 0.5) * 20}px, ${(Math.random() - 0.5) * 20}px)`;
    }, i * 50);
  }

  // Hide game
  renderer.domElement.style.opacity = '0.3';
  renderer.domElement.style.filter = 'blur(5px)';

  // Restart button
  setTimeout(() => {
    const restartBtn = document.createElement('button');
    restartBtn.textContent = 'RESTART';
    restartBtn.style.cssText = 'position:fixed;bottom:40px;left:50%;transform:translateX(-50%);z-index:10001;padding:15px 40px;font-size:1.2rem;background:#ff0000;color:#fff;border:none;border-radius:8px;cursor:pointer;font-weight:bold';
    restartBtn.onclick = () => location.reload();
    document.body.appendChild(restartBtn);
  }, 1500);
}

function playDeathSound() {
  // Create scary sound effect using Web Audio API
  try {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();
    
    oscillator.connect(gain);
    gain.connect(audioContext.destination);
    
    // Scary frequency sweep
    oscillator.frequency.setValueAtTime(100, audioContext.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.currentTime + 0.1);
    oscillator.frequency.exponentialRampToValueAtTime(50, audioContext.currentTime + 0.2);
    
    gain.gain.setValueAtTime(0.3, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.3);
  } catch (e) {
    // Audio not available
  }
}

function updateMonsters(dt) {
  const playerPos = camera.position;
  const playerDir = camera.getWorldDirection(new THREE.Vector3());

  monsters.forEach(m => {
    if (!m.userData.alive) return;

    const toPlayer = new THREE.Vector3().subVectors(playerPos, m.position);
    const dist = toPlayer.length();
    toPlayer.normalize();

    const lookingAt = playerDir.dot(toPlayer) > 0.8 && dist < 10;
    const kind = m.userData.kind;

    // Simple monster AI
    if (kind === 'watcher') {
      if (!lookingAt && dist > 1.2) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      }
      if (dist < 0.7) kill('The Watcher got you...');
    } else if (kind === 'gaze') {
      if (lookingAt) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 2) kill('You stared too long...');
      } else {
        m.userData.lookTimer = Math.max(0, m.userData.lookTimer - dt * 0.5);
      }
      if (dist > 1.5 && !lookingAt) {
        m.position.addScaledVector(toPlayer, m.userData.speed * 0.8 * dt);
      }
    } else {
      // Basic chase for other types
      if (dist > 1.5) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      }
      if (dist < 0.7) kill(`${m.userData.kind} caught you...`);
    }
  });
}

const FPS_LIMIT = 40;
const FRAME_TIME = 1 / FPS_LIMIT;
let fpsAccum = 0;

function applyLook() {
  if (!camera) return;
  camera.rotation.y -= lookD.x;
  camera.rotation.x -= lookD.y;
  camera.rotation.x = Math.max(-1.5, Math.min(1.5, camera.rotation.x));
  lookD.x = 0;
  lookD.y = 0;
}

function animate() {
  requestAnimationFrame(animate);
  const rawDt = clock.getDelta();

  applyLook();

  fpsAccum += rawDt;
  if (fpsAccum < FRAME_TIME) {
    renderer.render(scene, camera);
    return;
  }
  const dt = Math.min(fpsAccum, 0.05);
  fpsAccum = 0;

  if (gameOver) {
    renderer.render(scene, camera);
    return;
  }

  const speed = CONFIG.playerSpeed * dt;
  const forward = new THREE.Vector3();
  const right = new THREE.Vector3();
  const mover = camera;

  if (isMobile) {
    camera.getWorldDirection(forward);
    forward.y = 0;
    forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();
    mover.position.addScaledVector(forward, joy.y * speed);
    mover.position.addScaledVector(right, joy.x * speed);
  } else if (controls?.isLocked) {
    controls.getDirection(forward);
    forward.y = 0;
    forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();
    if (move.f) mover.position.addScaledVector(forward, speed);
    if (move.b) mover.position.addScaledVector(forward, -speed);
    if (move.l) mover.position.addScaledVector(right, -speed);
    if (move.r) mover.position.addScaledVector(right, speed);
  }

  mover.position.y = CONFIG.playerHeight;

  // Bounds
  mover.position.x = Math.max(-8, Math.min(8, mover.position.x));
  mover.position.z = Math.max(-5, Math.min(5, mover.position.z));

  updateMonsters(dt);

  renderer.render(scene, camera);
}

init().catch(console.error);

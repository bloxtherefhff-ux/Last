import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

/* ============================================================
   SKYLINE HOTEL – 10 FLOORS
   Brighter atmosphere + monsters with counters
   ============================================================ */

const CONFIG = {
  floors: 10,
  floorHeight: 4.5,
  corridorWidth: 8,
  corridorLength: 36,
  playerHeight: 1.7,
  playerSpeed: 6.2,
  roomDepth: 9
};
let roomDoors = [];
let playerInRoom = false;


let scene, camera, renderer, controls;
let currentFloor = 1;
let partsCollected = 0;
const TOTAL_PARTS = 10;
let gameMode = 'normal'; // normal | peaceful
let multiplayer = false;
let isHost = false;
let peer = null;
let myPeerId = null;
let roomCode = null;
const peerConns = []; // DataConnections
const remotePlayers = {}; // id -> { mesh, last }
const MAX_PLAYERS = 3;
const PLAYER_COLORS = [0x4488ff, 0x44cc66, 0xff8844];


let move = { f: false, b: false, l: false, r: false };
let isMobile = false;
let joy = { x: 0, y: 0 };
let lookD = { x: 0, y: 0 };
let interactables = [];
let monsters = [];
let elevators = []; // {floor, side, doorL, doorR, group, zone}
let insideElevator = false;
let elevPromptShown = false;
let ridingElevator = false;
let rideTimer = 0;
let ridePhase = null; // closing | moving | opening
let rideTarget = null;
let parts = [];
const collectedParts = new Set(); // part ids 1-10
let clock = new THREE.Clock();
let raycaster = new THREE.Raycaster();
let elevatorOpen = false;
let gameOver = false;
let holdingItem = null; // for toy / meat
let stunCooldown = 0;   // seconds remaining before stun can be used again
let stunActive = 0;     // seconds remaining of current stun

// DOM
const loadingEl = document.getElementById('loading');
const progressEl = document.getElementById('progress');
const hud = document.getElementById('hud');
const floorInd = document.getElementById('floor-indicator');
const partsEl = document.getElementById('parts');
const mobileControls = document.getElementById('mobile-controls');
const dialogue = document.getElementById('dialogue');
const npcNameEl = document.getElementById('npc-name');
const npcTextEl = document.getElementById('npc-text');
const winScreen = document.getElementById('win-screen');
const elevatorUI = document.getElementById('elevator-ui');
const msgEl = document.getElementById('msg');
const stunBtn = document.getElementById('stun-btn');
const stunCdEl = document.getElementById('stun-cd');

function showMsg(text, time = 3000) {
  msgEl.textContent = text;
  msgEl.classList.remove('hidden');
  setTimeout(() => msgEl.classList.add('hidden'), time);
}



function setupStartMenu() {
  const btnN = document.getElementById('btn-normal');
  const btnP = document.getElementById('btn-peaceful');
  const btnPlay = document.getElementById('btn-play');
  const btnHost = document.getElementById('btn-host');
  const btnJoin = document.getElementById('btn-join');
  const status = document.getElementById('mp-status');

  btnN.onclick = () => {
    gameMode = 'normal';
    btnN.classList.add('active');
    btnP.classList.remove('active');
  };
  btnP.onclick = () => {
    gameMode = 'peaceful';
    btnP.classList.add('active');
    btnN.classList.remove('active');
  };
  btnPlay.onclick = () => {
    multiplayer = false;
    beginGame();
  };

  btnHost.onclick = () => {
    if (typeof Peer === 'undefined') {
      status.textContent = 'PeerJS failed to load — check internet and retry';
      return;
    }
    status.textContent = 'Creating room…';
    multiplayer = true;
    isHost = true;
    // Short readable code as peer id prefix
    const code = Math.random().toString(36).slice(2, 6).toUpperCase();
    roomCode = code;
    const id = 'sky' + code.toLowerCase();
    peer = new Peer(id, { debug: 1 });
    peer.on('open', (pid) => {
      myPeerId = pid;
      status.textContent = 'ROOM CODE: ' + code + ' — tell your friends. Waiting (you + 2)...';
      // Host can start once ready — auto start after short wait so host can play
      setTimeout(() => {
        if (!document.getElementById('start-menu').classList.contains('hidden')) {
          status.textContent = 'ROOM: ' + code + ' — game starting. Friends join with this code.';
          beginGame();
        }
      }, 1500);
    });
    peer.on('connection', (conn) => {
      setupConn(conn);
    });
    peer.on('error', (err) => {
      status.textContent = 'Host error: ' + (err.type || err.message || err);
    });
  };

  btnJoin.onclick = () => {
    if (typeof Peer === 'undefined') {
      status.textContent = 'PeerJS failed to load — check internet and retry';
      return;
    }
    const code = (document.getElementById('join-code').value || '').trim().toUpperCase();
    if (code.length < 3) {
      status.textContent = 'Enter the host room code';
      return;
    }
    status.textContent = 'Connecting to ' + code + '…';
    multiplayer = true;
    isHost = false;
    roomCode = code;
    peer = new Peer({ debug: 1 });
    peer.on('open', () => {
      myPeerId = peer.id;
      const hostId = 'sky' + code.toLowerCase();
      const conn = peer.connect(hostId, { reliable: true });
      setupConn(conn);
      conn.on('open', () => {
        status.textContent = 'Connected! Starting…';
        beginGame();
      });
      conn.on('error', (e) => {
        status.textContent = 'Join failed — is host online? Code correct?';
      });
    });
    peer.on('error', (err) => {
      status.textContent = 'Join error: ' + (err.type || err.message || err);
    });
  };
}

function setupConn(conn) {
  conn.on('open', () => {
    if (peerConns.length >= MAX_PLAYERS - 1) {
      conn.send({ type: 'full' });
      conn.close();
      return;
    }
    peerConns.push(conn);
    // Introduce ourselves
    conn.send({
      type: 'hello',
      id: myPeerId,
      mode: gameMode,
      name: isHost ? 'Host' : 'Player'
    });
  });
  conn.on('data', (data) => {
    if (!data || !data.type) return;
    if (data.type === 'full') {
      const status = document.getElementById('mp-status');
      if (status) status.textContent = 'Room full (max 3)';
      return;
    }
    if (data.type === 'hello') {
      ensureRemotePlayer(data.id, data.name);
      // reply with our state
      conn.send({ type: 'hello', id: myPeerId, name: isHost ? 'Host' : 'Player' });
    }
    if (data.type === 'pos') {
      updateRemotePlayer(data);
    }
    if (data.type === 'part' && isHost) {
      // optional: host tracks — skip for simplicity
    }
  });
  conn.on('close', () => {
    const i = peerConns.indexOf(conn);
    if (i >= 0) peerConns.splice(i, 1);
  });
}

function ensureRemotePlayer(id, name) {
  if (!id || id === myPeerId) return;
  if (remotePlayers[id]) return;
  if (!scene) return;
  const color = PLAYER_COLORS[Object.keys(remotePlayers).length % PLAYER_COLORS.length];
  const g = new THREE.Group();
  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.28, 0.9, 4, 8),
    new THREE.MeshLambertMaterial({ color })
  );
  body.position.y = 1.0;
  g.add(body);
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.22, 8, 6),
    new THREE.MeshLambertMaterial({ color: 0xffddbb })
  );
  head.position.y = 1.75;
  g.add(head);
  // name sprite
  const c = document.createElement('canvas');
  c.width = 128; c.height = 32;
  const ctx = c.getContext('2d');
  ctx.fillStyle = 'rgba(0,0,0,0.7)';
  ctx.fillRect(0, 0, 128, 32);
  ctx.fillStyle = '#fff';
  ctx.font = '14px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText((name || 'Player').slice(0, 12), 64, 22);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true }));
  spr.scale.set(1.2, 0.3, 1);
  spr.position.y = 2.2;
  g.add(spr);
  scene.add(g);
  remotePlayers[id] = { mesh: g, last: performance.now() };
}

function updateRemotePlayer(data) {
  if (!data.id || data.id === myPeerId) return;
  ensureRemotePlayer(data.id, data.name);
  const rp = remotePlayers[data.id];
  if (!rp || !rp.mesh) return;
  rp.mesh.position.set(data.x, data.y, data.z);
  if (typeof data.ry === 'number') rp.mesh.rotation.y = data.ry;
  rp.last = performance.now();
}

let _mpSendAcc = 0;
function multiplayerTick(dt) {
  if (!multiplayer || !peerConns.length) return;
  _mpSendAcc += dt;
  if (_mpSendAcc < 0.08) return; // ~12 Hz
  _mpSendAcc = 0;
  const payload = {
    type: 'pos',
    id: myPeerId,
    x: camera.position.x,
    y: camera.position.y,
    z: camera.position.z,
    ry: camera.rotation.y,
    floor: currentFloor,
    parts: partsCollected
  };
  peerConns.forEach(c => {
    if (c.open) c.send(payload);
  });
}

async function init() {
  // Wait for start menu
  setupStartMenu();
}

function beginGame() {
  document.getElementById('start-menu').classList.add('hidden');
  document.getElementById('loading').classList.remove('hidden');
  isMobile = true;

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x4a4a5e);
  scene.fog = null; // fog costs FPS on mobile

  camera = new THREE.PerspectiveCamera(72, innerWidth / innerHeight, 0.1, 90);
  camera.position.set(0, CONFIG.playerHeight, 0);
  camera.rotation.order = 'YXZ';
  camera.rotation.y = -Math.PI / 2; // face +X elevator in the end wall
  camera.rotation.order = 'YXZ';

  renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', alpha: false });
  renderer.setSize(innerWidth, innerHeight);
  // Critical for mid-range phones: never above 1
  renderer.setPixelRatio(1);
  renderer.shadowMap.enabled = false;
  document.body.appendChild(renderer.domElement);

  // Cheap lighting only (point lights kill mobile FPS)
  scene.add(new THREE.AmbientLight(0xffffff, 1.4));
  scene.add(new THREE.HemisphereLight(0xffffff, 0x888899, 0.9));

  buildRoofOnly();
  loadFloor(1);
  placePartsForFloor(1);
  placeMonstersForFloor(1);
  placeNPCs();

  setupMobile();
  setupKeys();
  setupUI();

  progressEl.style.width = '100%';
  setTimeout(() => {
    loadingEl.classList.add('hidden');
    hud.classList.remove('hidden');
    mobileControls.classList.remove('hidden');
  }, 700);

  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });

  animate();
}

/* -------------------- HOTEL -------------------- */

function disposeObject(obj) {
  obj.traverse(o => {
    if (o.geometry) o.geometry.dispose();
    if (o.material) {
      if (Array.isArray(o.material)) o.material.forEach(m => m.dispose && m.dispose());
      else if (o.material.dispose) o.material.dispose();
    }
  });
}

function unloadCurrentFloor() {
  const g = scene.userData.currentFloorGroup;
  if (g) {
    scene.remove(g);
    disposeObject(g);
    scene.userData.currentFloorGroup = null;
  }
  // Remove interactables that belonged to floor geometry (doors, elevators)
  interactables = interactables.filter(o => {
    const t = o.userData && o.userData.type;
    return t === 'part' || t === 'item' || t === 'box' || t === 'monster';
  });
  roomDoors = [];
  elevators = [];
  // Remove monsters on old floor
  monsters.forEach(m => {
    scene.remove(m);
    disposeObject(m);
  });
  monsters = [];
  // Hide old parts meshes (keep collected state)
  parts.forEach(p => {
    if (p.parent) p.parent.remove(p);
    scene.remove(p);
  });
  // keep parts array for collected flags — rebuild uncollected on load
}

function buildRoofOnly() {
  const roofY = CONFIG.floors * CONFIG.floorHeight;
  // Simple roof platform only (always available reference, light)
  const roof = new THREE.Group();
  roof.position.y = roofY;
  const pad = new THREE.Mesh(
    new THREE.BoxGeometry(20, 0.3, 16),
    new THREE.MeshLambertMaterial({ color: 0x5a5a62 })
  );
  roof.add(pad);
  createHelicopter();
  // helipad is created in createHelicopter on roof — adjust
  scene.userData.roofGroup = roof;
  scene.add(roof);
  roof.visible = false;
}

function loadFloor(f) {
  const wallMat = new THREE.MeshLambertMaterial({ color: 0x6a5e52 });
  const floorMat = new THREE.MeshLambertMaterial({ color: 0x5a4e42 });
  const ceilMat  = new THREE.MeshLambertMaterial({ color: 0x4a423a });
  const carpetMat = new THREE.MeshLambertMaterial({ color: 0x8a3a3a });
  const doorMat = new THREE.MeshLambertMaterial({ color: 0x5a4030 });
  const roomFloorMat = new THREE.MeshLambertMaterial({ color: 0x6a5a4a });
  const bedMat = new THREE.MeshLambertMaterial({ color: 0x4a3038 });
  const woodMat = new THREE.MeshLambertMaterial({ color: 0x6b4a30 });
  const sheetMat = new THREE.MeshLambertMaterial({ color: 0xd8d0c8 });

  // Always at y=0 for current floor (player stays near ground)
  const g = new THREE.Group();
  g.position.y = 0;
  g.userData.floorNum = f;

  const slab = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.corridorLength + 18, 0.3, CONFIG.corridorWidth + 10 + CONFIG.roomDepth * 2),
    floorMat
  );
  slab.position.y = -0.15;
  g.add(slab);

  const carpet = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.corridorLength - 1, 0.02, 2.4),
    carpetMat
  );
  carpet.position.y = 0.01;
  g.add(carpet);

  const h = CONFIG.floorHeight - 0.3;
  const ceil = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.corridorLength + 18, 0.2, CONFIG.corridorWidth + 10),
    ceilMat
  );
  ceil.position.y = CONFIG.floorHeight - 0.1;
  g.add(ceil);

  const long = new THREE.BoxGeometry(CONFIG.corridorLength + 2, h, 0.35);
  const n = new THREE.Mesh(long, wallMat); n.position.set(0, h/2, -CONFIG.corridorWidth/2); g.add(n);
  const s = new THREE.Mesh(long, wallMat); s.position.set(0, h/2,  CONFIG.corridorWidth/2); g.add(s);

  const endSideH = (CONFIG.corridorWidth + 1 - 2.6) / 2;
  for (const sx of [1, -1]) {
    const baseX = sx * (CONFIG.corridorLength/2 + 0.2);
    for (const zSign of [-1, 1]) {
      const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.4, h, endSideH), wallMat);
      pillar.position.set(baseX, h/2, zSign * (CONFIG.corridorWidth/2 + 0.5 - endSideH/2));
      g.add(pillar);
    }
    const lintel = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 2.8), wallMat);
    lintel.position.set(baseX, h - 0.25, 0);
    g.add(lintel);
  }

  // Rooms (slightly fewer for mobile)
  const slots = [-4, 0, 4];
  for (const side of [-1, 1]) {
    for (const i of slots) {
      const door = new THREE.Mesh(new THREE.BoxGeometry(1.5, 2.5, 0.12), doorMat);
      door.position.set(i * 2.5, 1.25, side * (CONFIG.corridorWidth/2 - 0.05));
      door.userData = { type: 'room-door', open: false, side, floor: f };
      g.add(door);
      interactables.push(door);
      roomDoors.push(door);

      const roomW = 4.0;
      const roomD = CONFIG.roomDepth;
      const roomFloor = new THREE.Mesh(new THREE.BoxGeometry(roomW, 0.08, roomD), roomFloorMat);
      roomFloor.position.set(i * 2.5, 0.02, side * (CONFIG.corridorWidth/2 + roomD/2));
      g.add(roomFloor);

      const rw = new THREE.Mesh(new THREE.BoxGeometry(0.2, 3.2, roomD), wallMat);
      rw.position.set(i * 2.5 - roomW/2, 1.6, side * (CONFIG.corridorWidth/2 + roomD/2));
      g.add(rw);
      const rw2 = rw.clone();
      rw2.position.x = i * 2.5 + roomW/2;
      g.add(rw2);
      const back = new THREE.Mesh(new THREE.BoxGeometry(roomW, 3.2, 0.2), wallMat);
      back.position.set(i * 2.5, 1.6, side * (CONFIG.corridorWidth/2 + roomD));
      g.add(back);

      const bed = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.4, 2.4), bedMat);
      bed.position.set(i * 2.5 - 0.8, 0.35, side * (CONFIG.corridorWidth/2 + roomD * 0.65));
      g.add(bed);
      const desk = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.7, 0.55), woodMat);
      desk.position.set(i * 2.5 + 1.1, 0.45, side * (CONFIG.corridorWidth/2 + roomD * 0.35));
      g.add(desk);
      const closet = new THREE.Mesh(new THREE.BoxGeometry(1.0, 2.2, 0.6), woodMat);
      closet.position.set(i * 2.5 - 1.4, 1.15, side * (CONFIG.corridorWidth/2 + roomD * 0.3));
      g.add(closet);
    }
  }

  createElevator(g,  CONFIG.corridorLength/2 - 0.5, f);
  createElevator(g, -CONFIG.corridorLength/2 + 0.5, f);

  // Floor number label
  const canvas = document.createElement('canvas');
  canvas.width = 128; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#222'; ctx.fillRect(0,0,128,64);
  ctx.fillStyle = '#d4a84b'; ctx.font = 'bold 28px system-ui';
  ctx.textAlign = 'center'; ctx.fillText('F' + f, 64, 42);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(canvas) }));
  spr.scale.set(1.5, 0.75, 1);
  spr.position.set(0, 2.4, -CONFIG.corridorWidth/2 + 0.3);
  g.add(spr);

  scene.add(g);
  scene.userData.currentFloorGroup = g;
  currentFloor = f;
  if (floorInd) floorInd.textContent = 'Floor ' + f;
}

function showFloorLoading(text) {
  let el = document.getElementById('floor-loading');
  if (!el) {
    el = document.createElement('div');
    el.id = 'floor-loading';
    el.style.cssText = 'position:fixed;inset:0;z-index:500;background:rgba(5,5,12,0.92);display:flex;align-items:center;justify-content:center;flex-direction:column;color:#d4a84b;font-family:system-ui;';
    el.innerHTML = '<div style="font-size:1.4rem;font-weight:700;margin-bottom:12px;">LOADING FLOOR</div><div id="floor-loading-text"></div>';
    document.body.appendChild(el);
  }
  const t = document.getElementById('floor-loading-text');
  if (t) t.textContent = text || '';
  el.style.display = 'flex';
  el.classList.remove('hidden');
}

function hideFloorLoading() {
  const el = document.getElementById('floor-loading');
  if (el) el.style.display = 'none';
}

function createElevator(parent, x, floorNum) {
  // Big always-open gold portal in the CENTER of the end wall
  const side = x > 0 ? 1 : -1;
  const group = new THREE.Group();
  group.position.set(x, 0, 0);

  const gold = new THREE.MeshLambertMaterial({ color: 0xe8b84a });
  const dark = new THREE.MeshLambertMaterial({ color: 0x111118 });
  const green = new THREE.MeshLambertMaterial({ color: 0x44ff66 });

  // Wide gold arch (centered on z=0 = middle of hallway)
  const top = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.45, 3.2), gold);
  top.position.set(0, 2.9, 0); group.add(top);
  const bot = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.25, 3.2), gold);
  bot.position.set(0, 0.12, 0); group.add(bot);
  const L = new THREE.Mesh(new THREE.BoxGeometry(0.5, 3.0, 0.45), gold);
  L.position.set(0, 1.5, -1.6); group.add(L);
  const R = new THREE.Mesh(new THREE.BoxGeometry(0.5, 3.0, 0.45), gold);
  R.position.set(0, 1.5, 1.6); group.add(R);

  // Open hole (no doors ever)
  const hole = new THREE.Mesh(new THREE.BoxGeometry(0.6, 2.7, 2.6), dark);
  hole.position.set(-side * 0.35, 1.45, 0); group.add(hole);
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.2, 2.6, 2.5),
    new THREE.MeshLambertMaterial({ color: 0x333340 }));
  back.position.set(-side * 1.5, 1.4, 0); group.add(back);

  // Green light bar
  const lite = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.25, 2.4), green);
  lite.position.set(0.05 * side, 3.25, 0); group.add(lite);

  // Giant hitbox
  const hit = new THREE.Mesh(
    new THREE.BoxGeometry(4, 3.5, 4),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hit.position.set(-side * 0.5, 1.5, 0);
  hit.userData = { type: 'elevator', floor: floorNum };
  group.add(hit);
  interactables.push(hit);

  parent.add(group);
  elevators.push({ floor: floorNum, side, doorL: null, doorR: null, group, openAmount: 1, targetOpen: 1, closedZL: 0, closedZR: 0 });
}

function createHelicopter() {
  const g = new THREE.Group();
  const bodyMat = new THREE.MeshLambertMaterial({ color: 0x2a2a2a });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(1, 2.4, 4, 10), bodyMat);
  body.rotation.z = Math.PI/2;
  g.add(body);
  const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.28, 3.2, 8), bodyMat);
  tail.rotation.z = Math.PI/2;
  tail.position.set(-2.8, 0.25, 0);
  g.add(tail);
  const rotor = new THREE.Mesh(new THREE.BoxGeometry(7.5, 0.1, 0.4), new THREE.MeshLambertMaterial({ color: 0x111 }));
  rotor.position.y = 1.25;
  g.add(rotor);
  g.position.set(0, 1.5, 0);
  if (scene.userData.roofGroup) scene.userData.roofGroup.add(g);
  else scene.add(g);
  return g;
}

/* -------------------- PARTS (1 per floor) -------------------- */
function placePartsForFloor(f) {
  // Clear old part meshes from list (collected tracked in Set)
  parts = parts.filter(p => {
    if (p.userData && p.userData.floor !== f) return false;
    return true;
  });
  if (collectedParts.has(f)) return; // already got this floor's part
  const part = createPart(f);
  const side = (f % 2 === 0) ? 1 : -1;
  part.position.set((Math.random() * 8 - 4), 0.5, side * 1.8);
  part.userData = { type: 'part', id: f, collected: false, floor: f };
  scene.add(part);
  parts.push(part);
  interactables.push(part);
}

function createPart(id) {
  const g = new THREE.Group();
  const mat = new THREE.MeshLambertMaterial({
    color: 0xd4a84b, emissive: 0x3a2a10, emissiveIntensity: 0.35
  });
  let mesh;
  if (id % 3 === 0) mesh = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.4, 0.55), mat);
  else if (id % 3 === 1) mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.65, 10), mat);
  else mesh = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.12, 8, 16), mat);
  g.add(mesh);
  // no point light (mobile perf)
  return g;
}

/* -------------------- MONSTERS -------------------- */


const MONSTER_DEFS = [
  { name: 'Whisper Doll', floor: 1, pos: [0, 0, -2], type: 'whisper', speed: 1.1, desc: 'Interact to silence her whisper.' },
  { name: 'The Watcher', floor: 2, pos: [6, 0, 0], type: 'watcher', speed: 2.6, desc: 'Keep looking at him or he comes.' },
  { name: 'Gaze Beast', floor: 3, pos: [-7, 0, 0], type: 'gaze', speed: 1.4, desc: 'Do not stare more than 2 seconds.' },
  { name: 'Hungry Zombie', floor: 4, pos: [6, 0, 1.6], type: 'hungry', speed: 3.0, desc: 'Find meat and give it to him.' },
  { name: 'Backwatcher', floor: 5, pos: [-7, 0, -1.3], type: 'backtext', speed: 2.0, desc: 'Never look behind near him.' },
  { name: 'Pale Woman', floor: 6, pos: [4, 0, 1.7], type: 'stalker', speed: 2.3, desc: 'She cuts you off. Keep changing path.' },
  { name: 'Toy Doll', floor: 7, pos: [-5, 0, -1.6], type: 'toy', speed: 1.7, desc: 'Put the toy in the box to calm her.' },
  { name: 'Blood Crier', floor: 8, pos: [9, 0, 1.2], type: 'crier', speed: 2.5, desc: 'Stand still and look at his face.' },
  { name: 'Shadow Step', floor: 9, pos: [-8, 0, 1.4], type: 'shadowstep', speed: 3.8, desc: 'Only moves when you move. Stand still.' }
];

function placeMonstersForFloor(f) {
  MONSTER_DEFS.filter(d => d.floor === f).forEach(d => addMonster(d));
}

function placeMonsters() {
  // legacy no-op — use placeMonstersForFloor
}

function addMonster(data) {
  const m = createMonsterMesh(data.color || 0x333, data.name, data.type);
  m.position.set(data.pos[0], 0, data.pos[2]);
  m.userData = {
    type: 'monster',
    kind: data.type,
    name: data.name,
    speed: data.speed,
    floor: data.floor,
    alive: true,
    lookTimer: 0,
    state: 'idle',
    desc: data.desc,
    stunned: false
  };
  scene.add(m);
  monsters.push(m);
  interactables.push(m);
}






function createMonsterMesh(color, name, kind) {
  let g;
  switch (kind) {
    case 'watcher': g = createWatcherMesh(); break;
    case 'gaze': g = createGazeBeastMesh(); break;
    case 'hungry': g = createHungryZombieMesh(); break;
    case 'backtext': g = createBackwatcherMesh(); break;
    case 'stalker': g = createPaleGirlMesh(); break;
    case 'toy': g = createToyGirlMesh(); break;
    case 'crier': g = createBloodCrierMesh(); break;
    case 'shadowstep': g = createShadowStepMesh(); break;
    case 'whisper': g = createWhisperDollMesh(); break;
    default: g = createWatcherMesh(); break;
  }

  // Slightly larger so readable on phone
  g.scale.set(1.15, 1.15, 1.15);

  // Name plate above head
  const canvas = document.createElement('canvas');
  canvas.width = 256; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(10,0,0,0.88)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.strokeStyle = '#cc2222';
  ctx.lineWidth = 2;
  ctx.strokeRect(2, 2, 252, 60);
  ctx.fillStyle = '#ff6666';
  ctx.font = 'bold 18px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText(name, 128, 40);
  const tex = new THREE.CanvasTexture(canvas);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  spr.scale.set(1.9, 0.48, 1);
  spr.position.y = 2.55;
  g.add(spr);
  return g;
}



function createWatcherMesh() {
  const g = new THREE.Group();

  const suit = new THREE.MeshLambertMaterial({ color: 0x3b2922 });
  const suitDark = new THREE.MeshLambertMaterial({ color: 0x211818 });
  const shirt = new THREE.MeshLambertMaterial({ color: 0xaaa093 });
  const skin = new THREE.MeshLambertMaterial({ color: 0x9a8981 });
  const skinDark = new THREE.MeshLambertMaterial({ color: 0x5b4e4a });
  const eyeWhite = new THREE.MeshLambertMaterial({ color: 0xe9e2d8 });
  const pupil = new THREE.MeshLambertMaterial({ color: 0x060607 });
  const tieMat = new THREE.MeshLambertMaterial({ color: 0x171217 });
  const shoeMat = new THREE.MeshLambertMaterial({ color: 0x141214 });

  // long legs / narrow stance
  const legL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.075, 0.60, 4, 7),
    suitDark
  );
  legL.position.set(-0.105, 0.43, 0);
  g.add(legL);

  const legR = legL.clone();
  legR.position.x = 0.105;
  g.add(legR);

  const shoeL = new THREE.Mesh(
    new THREE.BoxGeometry(0.14, 0.075, 0.34),
    shoeMat
  );
  shoeL.position.set(-0.105, 0.055, -0.04);
  g.add(shoeL);

  const shoeR = shoeL.clone();
  shoeR.position.x = 0.105;
  g.add(shoeR);

  // long coat silhouette
  const coatLower = new THREE.Mesh(
    new THREE.ConeGeometry(0.27, 0.48, 8),
    suit
  );
  coatLower.scale.z = 0.64;
  coatLower.position.y = 0.82;
  g.add(coatLower);

  const coatUpper = new THREE.Mesh(
    new THREE.BoxGeometry(0.43, 0.48, 0.25),
    suit
  );
  coatUpper.position.y = 1.20;
  g.add(coatUpper);

  // vest
  const vest = new THREE.Mesh(
    new THREE.BoxGeometry(0.22, 0.50, 0.045),
    suitDark
  );
  vest.position.set(0, 1.22, -0.15);
  g.add(vest);

  // dirty shirt
  const shirtFront = new THREE.Mesh(
    new THREE.BoxGeometry(0.12, 0.45, 0.045),
    shirt
  );
  shirtFront.position.set(0, 1.24, -0.18);
  g.add(shirtFront);

  // tie
  const tie = new THREE.Mesh(
    new THREE.ConeGeometry(0.045, 0.31, 6),
    tieMat
  );
  tie.position.set(0, 1.24, -0.21);
  g.add(tie);

  // shoulders
  const shoulderL = new THREE.Mesh(
    new THREE.SphereGeometry(0.15, 8, 6),
    suit
  );
  shoulderL.scale.set(1.45, 0.75, 0.95);
  shoulderL.position.set(-0.22, 1.40, 0);
  g.add(shoulderL);

  const shoulderR = shoulderL.clone();
  shoulderR.position.x = 0.22;
  g.add(shoulderR);

  // long thin arms
  const armL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.06, 0.52, 4, 7),
    suit
  );
  armL.position.set(-0.30, 1.08, 0);
  g.add(armL);

  const armR = armL.clone();
  armR.position.x = 0.30;
  g.add(armR);

  const handL = new THREE.Mesh(
    new THREE.SphereGeometry(0.067, 7, 5),
    skin
  );
  handL.scale.y = 1.22;
  handL.position.set(-0.30, 0.73, -0.01);
  g.add(handL);

  const handR = handL.clone();
  handR.position.x = 0.30;
  g.add(handR);

  // neck
  const neck = new THREE.Mesh(
    new THREE.CylinderGeometry(0.07, 0.085, 0.18, 7),
    skin
  );
  neck.position.y = 1.68;
  g.add(neck);

  // large gaunt head
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.225, 10, 8),
    skin
  );
  head.scale.set(0.90, 1.16, 0.86);
  head.position.set(0, 1.84, -0.01);
  g.add(head);

  // side hollows / sunken cheeks
  const cheekL = new THREE.Mesh(
    new THREE.SphereGeometry(0.075, 7, 5),
    skinDark
  );
  cheekL.scale.set(1.15, 0.58, 0.28);
  cheekL.position.set(-0.105, 1.76, -0.19);
  g.add(cheekL);

  const cheekR = cheekL.clone();
  cheekR.position.x = 0.105;
  g.add(cheekR);

  // brow ridge
  const brow = new THREE.Mesh(
    new THREE.BoxGeometry(0.29, 0.045, 0.035),
    skinDark
  );
  brow.position.set(0, 1.90, -0.20);
  brow.rotation.z = 0.02;
  g.add(brow);

  // wide staring whites
  const eyeL = new THREE.Mesh(
    new THREE.SphereGeometry(0.065, 8, 6),
    eyeWhite
  );
  eyeL.scale.z = 0.38;
  eyeL.position.set(-0.082, 1.875, -0.205);
  g.add(eyeL);

  const eyeR = eyeL.clone();
  eyeR.position.x = 0.082;
  g.add(eyeR);

  const pupilL = new THREE.Mesh(
    new THREE.SphereGeometry(0.026, 6, 5),
    pupil
  );
  pupilL.position.set(-0.082, 1.875, -0.232);
  g.add(pupilL);

  const pupilR = pupilL.clone();
  pupilR.position.x = 0.082;
  g.add(pupilR);

  // nose
  const nose = new THREE.Mesh(
    new THREE.ConeGeometry(0.045, 0.12, 6),
    skin
  );
  nose.rotation.x = -Math.PI / 2;
  nose.position.set(0, 1.80, -0.23);
  g.add(nose);

  // thin grim mouth
  const mouth = new THREE.Mesh(
    new THREE.BoxGeometry(0.12, 0.018, 0.018),
    skinDark
  );
  mouth.position.set(0, 1.70, -0.215);
  g.add(mouth);

  return g;
}


function createGazeBeastMesh() {
  const g = new THREE.Group();

  const fur = new THREE.MeshLambertMaterial({ color: 0x2c2522 });
  const furDark = new THREE.MeshLambertMaterial({ color: 0x171315 });
  const muzzle = new THREE.MeshLambertMaterial({ color: 0x66534d });
  const eyes = new THREE.MeshLambertMaterial({ color: 0x030303 });
  const claw = new THREE.MeshLambertMaterial({ color: 0x4c403a });

  // rear haunch
  const hip = new THREE.Mesh(
    new THREE.SphereGeometry(0.34, 8, 6),
    furDark
  );
  hip.scale.set(1.15, 0.92, 1.00);
  hip.position.set(0, 0.60, 0.20);
  g.add(hip);

  // hunched torso leaning forward
  const torso = new THREE.Mesh(
    new THREE.SphereGeometry(0.38, 9, 7),
    fur
  );
  torso.scale.set(1.05, 1.20, 0.78);
  torso.rotation.x = -0.48;
  torso.position.set(0, 0.92, -0.02);
  g.add(torso);

  // heavy shoulder mass
  const shoulders = new THREE.Mesh(
    new THREE.SphereGeometry(0.38, 8, 6),
    fur
  );
  shoulders.scale.set(1.25, 0.78, 0.72);
  shoulders.position.set(0, 1.23, -0.16);
  g.add(shoulders);

  // neck angled forward
  const neck = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.12, 0.24, 4, 6),
    fur
  );
  neck.rotation.x = -0.60;
  neck.position.set(0, 1.38, -0.25);
  g.add(neck);

  // head
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.30, 9, 7),
    fur
  );
  head.scale.set(1.0, 0.95, 0.88);
  head.position.set(0, 1.53, -0.34);
  g.add(head);

  // long narrow snout
  const snout = new THREE.Mesh(
    new THREE.ConeGeometry(0.15, 0.52, 8),
    muzzle
  );
  snout.rotation.x = Math.PI / 2;
  snout.position.set(0, 1.47, -0.62);
  g.add(snout);

  const nose = new THREE.Mesh(
    new THREE.SphereGeometry(0.085, 7, 5),
    furDark
  );
  nose.scale.z = 0.48;
  nose.position.set(0, 1.47, -0.86);
  g.add(nose);

  // 8 eyes for a very readable silhouette
  const eyePositions = [
    [-0.15, 1.61, -0.55],
    [ 0.15, 1.61, -0.55],
    [-0.10, 1.54, -0.60],
    [ 0.10, 1.54, -0.60],
    [-0.18, 1.50, -0.54],
    [ 0.18, 1.50, -0.54],
    [-0.07, 1.66, -0.52],
    [ 0.07, 1.66, -0.52]
  ];

  eyePositions.forEach((p) => {
    const e = new THREE.Mesh(
      new THREE.SphereGeometry(0.035, 6, 5),
      eyes
    );
    e.position.set(p[0], p[1], p[2]);
    g.add(e);
  });

  // long dangling arms
  const upperArmL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.09, 0.43, 4, 7),
    fur
  );
  upperArmL.position.set(-0.40, 1.00, -0.18);
  upperArmL.rotation.z = -0.35;
  upperArmL.rotation.x = -0.25;
  g.add(upperArmL);

  const forearmL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.075, 0.46, 4, 7),
    fur
  );
  forearmL.position.set(-0.50, 0.59, -0.30);
  forearmL.rotation.z = -0.12;
  forearmL.rotation.x = -0.18;
  g.add(forearmL);

  const upperArmR = upperArmL.clone();
  upperArmR.position.x = 0.40;
  upperArmR.rotation.z = 0.35;
  g.add(upperArmR);

  const forearmR = forearmL.clone();
  forearmR.position.x = 0.50;
  forearmR.rotation.z = 0.12;
  g.add(forearmR);

  const handL = new THREE.Mesh(
    new THREE.SphereGeometry(0.095, 7, 5),
    claw
  );
  handL.scale.y = 1.25;
  handL.position.set(-0.51, 0.31, -0.34);
  g.add(handL);

  const handR = handL.clone();
  handR.position.x = 0.51;
  g.add(handR);

  // hanging fingers
  for (let i = 0; i < 4; i++) {
    const fL = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.016, 0.13, 3, 5),
      claw
    );
    fL.position.set(-0.55 + i * 0.035, 0.20, -0.38);
    fL.rotation.z = -0.14;
    g.add(fL);

    const fR = fL.clone();
    fR.position.x = 0.55 - i * 0.035;
    fR.rotation.z = 0.14;
    g.add(fR);
  }

  // animal rear legs
  const thighL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.13, 0.34, 4, 7),
    furDark
  );
  thighL.position.set(-0.22, 0.48, 0.18);
  thighL.rotation.z = -0.24;
  g.add(thighL);

  const thighR = thighL.clone();
  thighR.position.x = 0.22;
  thighR.rotation.z = 0.24;
  g.add(thighR);

  const shinL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.085, 0.34, 4, 7),
    furDark
  );
  shinL.position.set(-0.30, 0.19, 0.02);
  shinL.rotation.z = 0.20;
  g.add(shinL);

  const shinR = shinL.clone();
  shinR.position.x = 0.30;
  shinR.rotation.z = -0.20;
  g.add(shinR);

  const footL = new THREE.Mesh(
    new THREE.SphereGeometry(0.13, 7, 5),
    furDark
  );
  footL.scale.set(0.72, 0.42, 1.50);
  footL.position.set(-0.33, 0.07, -0.12);
  g.add(footL);

  const footR = footL.clone();
  footR.position.x = 0.33;
  g.add(footR);

  return g;
}


function createHungryZombieMesh() {
  const g = new THREE.Group();

  const skin = new THREE.MeshLambertMaterial({ color: 0x66715d });
  const skinDark = new THREE.MeshLambertMaterial({ color: 0x3a4539 });
  const shirt = new THREE.MeshLambertMaterial({ color: 0x6f7069 });
  const pants = new THREE.MeshLambertMaterial({ color: 0x26272a });
  const blood = new THREE.MeshLambertMaterial({ color: 0x4c1515 });
  const mouthMat = new THREE.MeshLambertMaterial({ color: 0x12090a });
  const teeth = new THREE.MeshLambertMaterial({ color: 0xb4aa8b });

  // legs
  const legL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.10, 0.52, 4, 7),
    pants
  );
  legL.position.set(-0.135, 0.44, 0);
  legL.rotation.z = -0.03;
  g.add(legL);

  const legR = legL.clone();
  legR.position.x = 0.135;
  g.add(legR);

  const shoeL = new THREE.Mesh(
    new THREE.BoxGeometry(0.18, 0.08, 0.34),
    pants
  );
  shoeL.position.set(-0.135, 0.055, -0.05);
  g.add(shoeL);

  const shoeR = shoeL.clone();
  shoeR.position.x = 0.135;
  g.add(shoeR);

  // torn torso
  const torso = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.25, 0.56, 5, 7),
    shirt
  );
  torso.scale.set(1.0, 1.02, 0.63);
  torso.position.y = 1.20;
  torso.rotation.z = -0.05;
  g.add(torso);

  // hanging shirt flap
  const shirtFlapL = new THREE.Mesh(
    new THREE.BoxGeometry(0.17, 0.32, 0.06),
    shirt
  );
  shirtFlapL.position.set(-0.17, 1.03, -0.19);
  shirtFlapL.rotation.z = -0.15;
  g.add(shirtFlapL);

  const shirtFlapR = shirtFlapL.clone();
  shirtFlapR.position.x = 0.17;
  shirtFlapR.rotation.z = 0.15;
  g.add(shirtFlapR);

  // large open chest wound
  const wound = new THREE.Mesh(
    new THREE.SphereGeometry(0.18, 8, 6),
    blood
  );
  wound.scale.set(1.05, 1.40, 0.32);
  wound.position.set(-0.03, 1.25, -0.215);
  g.add(wound);

  const woundInner = new THREE.Mesh(
    new THREE.SphereGeometry(0.10, 7, 5),
    skinDark
  );
  woundInner.scale.set(0.90, 1.20, 0.30);
  woundInner.position.set(-0.03, 1.25, -0.24);
  g.add(woundInner);

  // neck + head
  const neck = new THREE.Mesh(
    new THREE.CylinderGeometry(0.08, 0.10, 0.18, 7),
    skin
  );
  neck.position.y = 1.67;
  g.add(neck);

  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.245, 9, 7),
    skin
  );
  head.scale.set(0.91, 1.14, 0.84);
  head.position.set(0.01, 1.84, -0.01);
  g.add(head);

  // jaw / open mouth
  const jaw = new THREE.Mesh(
    new THREE.SphereGeometry(0.14, 8, 6),
    skinDark
  );
  jaw.scale.set(1.0, 0.62, 0.62);
  jaw.position.set(0, 1.70, -0.16);
  g.add(jaw);

  const mouth = new THREE.Mesh(
    new THREE.SphereGeometry(0.10, 8, 6),
    mouthMat
  );
  mouth.scale.set(1.15, 1.60, 0.45);
  mouth.position.set(0, 1.74, -0.225);
  g.add(mouth);

  const toothTop = new THREE.Mesh(
    new THREE.BoxGeometry(0.14, 0.025, 0.025),
    teeth
  );
  toothTop.position.set(0, 1.81, -0.26);
  g.add(toothTop);

  const toothBottom = toothTop.clone();
  toothBottom.position.y = 1.66;
  g.add(toothBottom);

  // rotten eyes
  const eyeL = new THREE.Mesh(
    new THREE.SphereGeometry(0.042, 6, 5),
    skinDark
  );
  eyeL.position.set(-0.09, 1.88, -0.22);
  g.add(eyeL);

  const eyeR = eyeL.clone();
  eyeR.position.x = 0.09;
  g.add(eyeR);

  // reaching arm shoulder
  const upperReach = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.085, 0.42, 4, 7),
    shirt
  );
  upperReach.position.set(0.34, 1.24, -0.12);
  upperReach.rotation.z = -0.52;
  upperReach.rotation.x = -0.35;
  g.add(upperReach);

  // long forearm toward camera
  const foreReach = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.075, 0.48, 4, 7),
    skin
  );
  foreReach.position.set(0.63, 1.00, -0.48);
  foreReach.rotation.z = -0.28;
  foreReach.rotation.x = -0.90;
  g.add(foreReach);

  // reaching hand
  const reachHand = new THREE.Mesh(
    new THREE.SphereGeometry(0.10, 7, 5),
    skin
  );
  reachHand.scale.y = 0.88;
  reachHand.position.set(0.73, 0.83, -0.70);
  g.add(reachHand);

  // reaching fingers
  for (let i = 0; i < 4; i++) {
    const finger = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.018, 0.14, 3, 5),
      skin
    );
    finger.position.set(
      0.66 + i * 0.045,
      0.81 - i * 0.005,
      -0.78
    );
    finger.rotation.x = -0.72;
    finger.rotation.z = -0.18 + i * 0.10;
    g.add(finger);
  }

  // hanging opposite arm
  const armL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.08, 0.54, 4, 7),
    shirt
  );
  armL.position.set(-0.32, 1.04, 0);
  armL.rotation.z = 0.08;
  g.add(armL);

  const handL = new THREE.Mesh(
    new THREE.SphereGeometry(0.085, 7, 5),
    skin
  );
  handL.position.set(-0.34, 0.67, -0.01);
  g.add(handL);

  return g;
}


function createBackwatcherMesh() {
  const g = new THREE.Group();

  const body = new THREE.MeshLambertMaterial({ color: 0x211e1d });
  const bodyDark = new THREE.MeshLambertMaterial({ color: 0x0e0d0e });
  const skin = new THREE.MeshLambertMaterial({ color: 0x746863 });
  const eyeMat = new THREE.MeshLambertMaterial({ color: 0x070607 });

  // thin waist / torso
  const torso = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.22, 0.62, 5, 7),
    body
  );
  torso.scale.set(0.78, 1.05, 0.60);
  torso.position.y = 1.19;
  g.add(torso);

  // elongated shoulders
  const shoulders = new THREE.Mesh(
    new THREE.SphereGeometry(0.27, 8, 6),
    body
  );
  shoulders.scale.set(1.18, 0.60, 0.62);
  shoulders.position.y = 1.47;
  g.add(shoulders);

  // arms hanging almost to knees
  const armL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.06, 0.54, 4, 7),
    body
  );
  armL.position.set(-0.30, 1.02, 0);
  armL.rotation.z = 0.06;
  g.add(armL);

  const armR = armL.clone();
  armR.position.x = 0.30;
  armR.rotation.z = -0.06;
  g.add(armR);

  // neck offset to emphasize twisted anatomy
  const neck = new THREE.Mesh(
    new THREE.CylinderGeometry(0.065, 0.085, 0.24, 7),
    skin
  );
  neck.position.set(0.07, 1.67, 0.02);
  neck.rotation.z = -0.30;
  neck.rotation.y = Math.PI * 0.50;
  g.add(neck);

  // head physically rotated around to the back
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.225, 9, 7),
    skin
  );
  head.scale.set(0.88, 1.08, 0.82);
  head.position.set(0.10, 1.82, 0.10);
  head.rotation.y = Math.PI;
  head.rotation.z = -0.42;
  g.add(head);

  // backward-facing face protrusion
  const face = new THREE.Mesh(
    new THREE.SphereGeometry(0.145, 8, 6),
    skin
  );
  face.scale.set(0.88, 1.08, 0.48);
  face.position.set(0.07, 1.80, 0.32);
  face.rotation.y = Math.PI;
  g.add(face);

  const eyeL = new THREE.Mesh(
    new THREE.SphereGeometry(0.033, 6, 5),
    eyeMat
  );
  eyeL.position.set(-0.01, 1.84, 0.40);
  g.add(eyeL);

  const eyeR = eyeL.clone();
  eyeR.position.x = 0.12;
  g.add(eyeR);

  // digitigrade thighs
  const thighL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.12, 0.35, 4, 7),
    bodyDark
  );
  thighL.position.set(-0.18, 0.55, -0.01);
  thighL.rotation.z = -0.18;
  g.add(thighL);

  const thighR = thighL.clone();
  thighR.position.x = 0.18;
  thighR.rotation.z = 0.18;
  g.add(thighR);

  // knees pushed forward
  const shinL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.085, 0.36, 4, 7),
    bodyDark
  );
  shinL.position.set(-0.24, 0.24, -0.13);
  shinL.rotation.z = 0.18;
  g.add(shinL);

  const shinR = shinL.clone();
  shinR.position.x = 0.24;
  shinR.rotation.z = -0.18;
  g.add(shinR);

  // animal feet
  const footL = new THREE.Mesh(
    new THREE.SphereGeometry(0.14, 7, 5),
    bodyDark
  );
  footL.scale.set(0.72, 0.42, 1.50);
  footL.position.set(-0.27, 0.07, -0.23);
  g.add(footL);

  const footR = footL.clone();
  footR.position.x = 0.27;
  g.add(footR);

  return g;
}


function createPaleGirlMesh() {
  const g = new THREE.Group();

  const jacket = new THREE.MeshLambertMaterial({ color: 0x101014 });
  const skirtMat = new THREE.MeshLambertMaterial({ color: 0x17151a });
  const hair = new THREE.MeshLambertMaterial({ color: 0x030304 });
  const skin = new THREE.MeshLambertMaterial({ color: 0xd1c6be });
  const eyeWhite = new THREE.MeshLambertMaterial({ color: 0xece6dd });
  const pupil = new THREE.MeshLambertMaterial({ color: 0x080709 });
  const shoe = new THREE.MeshLambertMaterial({ color: 0x080809 });

  // narrow skirt
  const skirt = new THREE.Mesh(
    new THREE.ConeGeometry(0.34, 0.60, 10),
    skirtMat
  );
  skirt.scale.z = 0.74;
  skirt.position.y = 0.82;
  g.add(skirt);

  // fitted jacket
  const torso = new THREE.Mesh(
    new THREE.BoxGeometry(0.39, 0.55, 0.24),
    jacket
  );
  torso.position.y = 1.28;
  g.add(torso);

  // lower jacket flare
  const jacketLower = new THREE.Mesh(
    new THREE.BoxGeometry(0.43, 0.20, 0.25),
    jacket
  );
  jacketLower.position.y = 1.08;
  g.add(jacketLower);

  // lapels
  const lapelL = new THREE.Mesh(
    new THREE.BoxGeometry(0.065, 0.34, 0.035),
    skirtMat
  );
  lapelL.position.set(-0.10, 1.37, -0.145);
  lapelL.rotation.z = -0.11;
  g.add(lapelL);

  const lapelR = lapelL.clone();
  lapelR.position.x = 0.10;
  lapelR.rotation.z = 0.11;
  g.add(lapelR);

  // neck
  const neck = new THREE.Mesh(
    new THREE.CylinderGeometry(0.065, 0.08, 0.15, 7),
    skin
  );
  neck.position.y = 1.65;
  g.add(neck);

  // face behind curtain
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.215, 9, 7),
    skin
  );
  head.scale.set(0.88, 1.10, 0.84);
  head.position.y = 1.81;
  g.add(head);

  // huge back hair mass
  const hairBack = new THREE.Mesh(
    new THREE.CylinderGeometry(0.23, 0.29, 0.83, 10),
    hair
  );
  hairBack.scale.z = 0.72;
  hairBack.position.set(0, 1.62, 0.02);
  g.add(hairBack);

  // front curtain covers nearly entire face
  const hairCurtain = new THREE.Mesh(
    new THREE.BoxGeometry(0.43, 0.60, 0.12),
    hair
  );
  hairCurtain.position.set(-0.01, 1.77, -0.205);
  g.add(hairCurtain);

  // one visible eye
  const visibleEye = new THREE.Mesh(
    new THREE.SphereGeometry(0.047, 7, 5),
    eyeWhite
  );
  visibleEye.scale.z = 0.32;
  visibleEye.position.set(0.105, 1.83, -0.274);
  g.add(visibleEye);

  const visiblePupil = new THREE.Mesh(
    new THREE.SphereGeometry(0.021, 6, 5),
    pupil
  );
  visiblePupil.position.set(0.105, 1.83, -0.292);
  g.add(visiblePupil);

  // straight thin arms
  const armL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.06, 0.50, 4, 7),
    jacket
  );
  armL.position.set(-0.27, 1.22, 0);
  g.add(armL);

  const armR = armL.clone();
  armR.position.x = 0.27;
  g.add(armR);

  const handL = new THREE.Mesh(
    new THREE.SphereGeometry(0.066, 7, 5),
    skin
  );
  handL.position.set(-0.27, 0.84, 0);
  g.add(handL);

  const handR = handL.clone();
  handR.position.x = 0.27;
  g.add(handR);

  // visible pale lower legs
  const legL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.06, 0.35, 4, 6),
    skin
  );
  legL.position.set(-0.10, 0.25, 0);
  g.add(legL);

  const legR = legL.clone();
  legR.position.x = 0.10;
  g.add(legR);

  const shoeL = new THREE.Mesh(
    new THREE.BoxGeometry(0.13, 0.07, 0.27),
    shoe
  );
  shoeL.position.set(-0.10, 0.045, -0.035);
  g.add(shoeL);

  const shoeR = shoeL.clone();
  shoeR.position.x = 0.10;
  g.add(shoeR);

  return g;
}


function createToyGirlMesh() {
  const g = new THREE.Group();

  const dress = new THREE.MeshLambertMaterial({ color: 0x282126 });
  const dressDark = new THREE.MeshLambertMaterial({ color: 0x161317 });
  const porcelain = new THREE.MeshLambertMaterial({ color: 0xc9c1b7 });
  const crack = new THREE.MeshLambertMaterial({ color: 0x3a3031 });
  const eyeMat = new THREE.MeshLambertMaterial({ color: 0x111012 });
  const teddy = new THREE.MeshLambertMaterial({ color: 0x5b473d });
  const teddyDark = new THREE.MeshLambertMaterial({ color: 0x332822 });

  // bell-shaped dark dress
  const dressBody = new THREE.Mesh(
    new THREE.ConeGeometry(0.28, 0.50, 9),
    dress
  );
  dressBody.position.y = 0.57;
  g.add(dressBody);

  // sleeves
  const sleeveL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.047, 0.27, 4, 6),
    dress
  );
  sleeveL.position.set(-0.23, 0.68, 0);
  sleeveL.rotation.z = 0.20;
  g.add(sleeveL);

  const sleeveR = sleeveL.clone();
  sleeveR.position.x = 0.23;
  sleeveR.rotation.z = -0.20;
  g.add(sleeveR);

  // neck
  const neck = new THREE.Mesh(
    new THREE.CylinderGeometry(0.055, 0.065, 0.10, 7),
    porcelain
  );
  neck.position.y = 0.87;
  g.add(neck);

  // oversized doll head
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.205, 9, 7),
    porcelain
  );
  head.scale.set(0.96, 1.06, 0.88);
  head.position.y = 1.04;
  g.add(head);

  // hair cap + side locks
  const hairCap = new THREE.Mesh(
    new THREE.SphereGeometry(0.215, 8, 6),
    dressDark
  );
  hairCap.scale.set(1.06, 0.72, 0.88);
  hairCap.position.set(0, 1.14, 0.015);
  g.add(hairCap);

  const lockL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.045, 0.28, 4, 6),
    dressDark
  );
  lockL.position.set(-0.19, 1.00, 0.02);
  lockL.rotation.z = -0.25;
  g.add(lockL);

  const lockR = lockL.clone();
  lockR.position.x = 0.19;
  lockR.rotation.z = 0.25;
  g.add(lockR);

  // eyes
  const eyeL = new THREE.Mesh(
    new THREE.SphereGeometry(0.033, 6, 5),
    eyeMat
  );
  eyeL.position.set(-0.075, 1.06, -0.182);
  g.add(eyeL);

  const eyeR = eyeL.clone();
  eyeR.position.x = 0.075;
  g.add(eyeR);

  // empty painted smile
  const smile = new THREE.Mesh(
    new THREE.TorusGeometry(0.055, 0.011, 4, 8, Math.PI),
    crack
  );
  smile.rotation.x = Math.PI;
  smile.position.set(0, 0.98, -0.184);
  g.add(smile);

  // face cracks
  const crack1 = new THREE.Mesh(
    new THREE.BoxGeometry(0.011, 0.13, 0.008),
    crack
  );
  crack1.position.set(0.035, 1.12, -0.184);
  crack1.rotation.z = 0.28;
  g.add(crack1);

  const crack2 = new THREE.Mesh(
    new THREE.BoxGeometry(0.010, 0.09, 0.008),
    crack
  );
  crack2.position.set(-0.08, 1.00, -0.184);
  crack2.rotation.z = -0.30;
  g.add(crack2);

  // hands
  const handL = new THREE.Mesh(
    new THREE.SphereGeometry(0.052, 6, 5),
    porcelain
  );
  handL.position.set(-0.27, 0.47, 0);
  g.add(handL);

  // teddy held in the right hand
  const teddyBody = new THREE.Mesh(
    new THREE.SphereGeometry(0.085, 7, 5),
    teddy
  );
  teddyBody.scale.y = 1.22;
  teddyBody.position.set(0.28, 0.50, -0.15);
  g.add(teddyBody);

  const teddyHead = new THREE.Mesh(
    new THREE.SphereGeometry(0.065, 7, 5),
    teddy
  );
  teddyHead.position.set(0.28, 0.63, -0.16);
  g.add(teddyHead);

  const earL = new THREE.Mesh(
    new THREE.SphereGeometry(0.028, 6, 5),
    teddy
  );
  earL.position.set(0.235, 0.68, -0.15);
  g.add(earL);

  const earR = earL.clone();
  earR.position.x = 0.325;
  g.add(earR);

  const teddyEyeL = new THREE.Mesh(
    new THREE.SphereGeometry(0.009, 5, 4),
    teddyDark
  );
  teddyEyeL.position.set(0.26, 0.64, -0.215);
  g.add(teddyEyeL);

  const teddyEyeR = teddyEyeL.clone();
  teddyEyeR.position.x = 0.30;
  g.add(teddyEyeR);

  const handR = new THREE.Mesh(
    new THREE.SphereGeometry(0.052, 6, 5),
    porcelain
  );
  handR.position.set(0.25, 0.54, -0.11);
  g.add(handR);

  // legs
  const legL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.052, 0.24, 4, 6),
    porcelain
  );
  legL.position.set(-0.09, 0.23, 0);
  g.add(legL);

  const legR = legL.clone();
  legR.position.x = 0.09;
  g.add(legR);

  const shoeL = new THREE.Mesh(
    new THREE.BoxGeometry(0.10, 0.06, 0.18),
    dressDark
  );
  shoeL.position.set(-0.09, 0.035, -0.025);
  g.add(shoeL);

  const shoeR = shoeL.clone();
  shoeR.position.x = 0.09;
  g.add(shoeR);

  return g;
}


function createBloodCrierMesh() {
  const g = new THREE.Group();

  const skin = new THREE.MeshLambertMaterial({ color: 0xb8a8a0 });
  const shirt = new THREE.MeshLambertMaterial({ color: 0xd2cec5 });
  const pants = new THREE.MeshLambertMaterial({ color: 0x29272a });
  const blood = new THREE.MeshLambertMaterial({ color: 0x581416 });
  const mouthMat = new THREE.MeshLambertMaterial({ color: 0x11080a });
  const teeth = new THREE.MeshLambertMaterial({ color: 0xb7ae93 });

  // legs
  const legL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.10, 0.48, 4, 7),
    pants
  );
  legL.position.set(-0.13, 0.43, 0);
  g.add(legL);

  const legR = legL.clone();
  legR.position.x = 0.13;
  g.add(legR);

  const shoeL = new THREE.Mesh(
    new THREE.BoxGeometry(0.17, 0.08, 0.33),
    pants
  );
  shoeL.position.set(-0.13, 0.055, -0.035);
  g.add(shoeL);

  const shoeR = shoeL.clone();
  shoeR.position.x = 0.13;
  g.add(shoeR);

  // torso
  const torso = new THREE.Mesh(
    new THREE.BoxGeometry(0.49, 0.72, 0.28),
    shirt
  );
  torso.position.y = 1.20;
  g.add(torso);

  // blood soaked shirt front
  const bloodFront = new THREE.Mesh(
    new THREE.SphereGeometry(0.22, 8, 6),
    blood
  );
  bloodFront.scale.set(0.96, 1.58, 0.28);
  bloodFront.position.set(0, 1.22, -0.19);
  g.add(bloodFront);

  // vertical blood streaks
  for (let i = 0; i < 5; i++) {
    const streak = new THREE.Mesh(
      new THREE.CylinderGeometry(0.014, 0.024, 0.24 + (i % 2) * 0.10, 6),
      blood
    );
    streak.position.set(
      -0.17 + i * 0.085,
      0.99 + (i % 2) * 0.03,
      -0.22
    );
    g.add(streak);
  }

  // neck
  const neck = new THREE.Mesh(
    new THREE.CylinderGeometry(0.08, 0.095, 0.17, 7),
    skin
  );
  neck.position.y = 1.67;
  g.add(neck);

  // head
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.24, 9, 7),
    skin
  );
  head.scale.set(0.91, 1.13, 0.85);
  head.position.y = 1.82;
  g.add(head);

  // screaming mouth
  const mouth = new THREE.Mesh(
    new THREE.SphereGeometry(0.115, 8, 6),
    mouthMat
  );
  mouth.scale.set(1.25, 1.72, 0.42);
  mouth.position.set(0, 1.71, -0.225);
  g.add(mouth);

  const upperTeeth = new THREE.Mesh(
    new THREE.BoxGeometry(0.16, 0.028, 0.025),
    teeth
  );
  upperTeeth.position.set(0, 1.80, -0.27);
  g.add(upperTeeth);

  const lowerTeeth = upperTeeth.clone();
  lowerTeeth.position.y = 1.63;
  g.add(lowerTeeth);

  // eyes + blood tears
  const eyeL = new THREE.Mesh(
    new THREE.SphereGeometry(0.042, 6, 5),
    blood
  );
  eyeL.position.set(-0.09, 1.87, -0.22);
  g.add(eyeL);

  const eyeR = eyeL.clone();
  eyeR.position.x = 0.09;
  g.add(eyeR);

  const tearL = new THREE.Mesh(
    new THREE.CylinderGeometry(0.014, 0.022, 0.16, 5),
    blood
  );
  tearL.position.set(-0.09, 1.75, -0.225);
  g.add(tearL);

  const tearR = tearL.clone();
  tearR.position.x = 0.09;
  g.add(tearR);

  // arms raised near face
  const armL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.08, 0.46, 4, 7),
    shirt
  );
  armL.position.set(-0.33, 1.30, -0.04);
  armL.rotation.z = -0.62;
  armL.rotation.x = -0.16;
  g.add(armL);

  const armR = armL.clone();
  armR.position.x = 0.33;
  armR.rotation.z = 0.62;
  g.add(armR);

  const handL = new THREE.Mesh(
    new THREE.SphereGeometry(0.09, 7, 5),
    skin
  );
  handL.position.set(-0.53, 1.49, -0.16);
  g.add(handL);

  const handR = handL.clone();
  handR.position.x = 0.53;
  g.add(handR);

  // fingers spread beside the face
  for (let i = 0; i < 4; i++) {
    const fL = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.016, 0.12, 3, 5),
      skin
    );
    fL.position.set(
      -0.58 + i * 0.035,
      1.54 + Math.abs(i - 1.5) * 0.025,
      -0.19
    );
    fL.rotation.z = -0.38;
    g.add(fL);

    const fR = fL.clone();
    fR.position.x = 0.58 - i * 0.035;
    fR.rotation.z = 0.38;
    g.add(fR);
  }

  return g;
}


function createShadowStepMesh() {
  const g = new THREE.Group();

  const shadow = new THREE.MeshLambertMaterial({ color: 0x030305 });
  const red = new THREE.MeshLambertMaterial({ color: 0x5a0000 });

  // tall tapered body
  const torso = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.20, 0.74, 4, 7),
    shadow
  );
  torso.scale.set(0.70, 1.18, 0.50);
  torso.position.y = 1.25;
  g.add(torso);

  // narrow shoulders
  const shoulders = new THREE.Mesh(
    new THREE.SphereGeometry(0.265, 7, 5),
    shadow
  );
  shoulders.scale.set(1.03, 0.50, 0.52);
  shoulders.position.y = 1.56;
  g.add(shoulders);

  // tiny head, featureless except red eyes
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.205, 8, 6),
    shadow
  );
  head.scale.set(0.78, 1.10, 0.70);
  head.position.y = 1.91;
  g.add(head);

  const eyeL = new THREE.Mesh(
    new THREE.SphereGeometry(0.022, 6, 5),
    red
  );
  eyeL.position.set(-0.068, 1.93, -0.18);
  g.add(eyeL);

  const eyeR = eyeL.clone();
  eyeR.position.x = 0.068;
  g.add(eyeR);

  // extremely long arms
  const armL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.052, 0.76, 4, 7),
    shadow
  );
  armL.position.set(-0.30, 1.05, 0);
  armL.rotation.z = 0.025;
  g.add(armL);

  const armR = armL.clone();
  armR.position.x = 0.30;
  armR.rotation.z = -0.025;
  g.add(armR);

  const handL = new THREE.Mesh(
    new THREE.SphereGeometry(0.055, 6, 5),
    shadow
  );
  handL.position.set(-0.31, 0.50, 0);
  g.add(handL);

  const handR = handL.clone();
  handR.position.x = 0.31;
  g.add(handR);

  // extremely thin legs
  const legL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.07, 0.68, 4, 7),
    shadow
  );
  legL.position.set(-0.11, 0.43, 0);
  g.add(legL);

  const legR = legL.clone();
  legR.position.x = 0.11;
  g.add(legR);

  const footL = new THREE.Mesh(
    new THREE.BoxGeometry(0.12, 0.06, 0.28),
    shadow
  );
  footL.position.set(-0.11, 0.04, -0.035);
  g.add(footL);

  const footR = footL.clone();
  footR.position.x = 0.11;
  g.add(footR);

  return g;
}


function createWhisperDollMesh() {
  const g = new THREE.Group();

  const dress = new THREE.MeshLambertMaterial({ color: 0x49403d });
  const dressDark = new THREE.MeshLambertMaterial({ color: 0x211c1e });
  const skin = new THREE.MeshLambertMaterial({ color: 0xa89d94 });
  const crack = new THREE.MeshLambertMaterial({ color: 0x292225 });
  const mouthMat = new THREE.MeshLambertMaterial({ color: 0x0e090a });

  // ragged bell dress
  const body = new THREE.Mesh(
    new THREE.ConeGeometry(0.25, 0.45, 8),
    dress
  );
  body.position.y = 0.49;
  g.add(body);

  // frayed skirt pieces
  for (let i = 0; i < 5; i++) {
    const fray = new THREE.Mesh(
      new THREE.ConeGeometry(0.065, 0.16, 5),
      dressDark
    );
    fray.position.set(
      -0.18 + i * 0.09,
      0.28 + (i % 2) * 0.035,
      0
    );
    fray.rotation.z = (i - 2) * 0.08;
    g.add(fray);
  }

  // narrow sleeves
  const armL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.043, 0.27, 4, 6),
    dress
  );
  armL.position.set(-0.22, 0.57, 0);
  armL.rotation.z = 0.13;
  g.add(armL);

  const armR = armL.clone();
  armR.position.x = 0.22;
  armR.rotation.z = -0.13;
  g.add(armR);

  const handL = new THREE.Mesh(
    new THREE.SphereGeometry(0.045, 6, 5),
    skin
  );
  handL.position.set(-0.24, 0.36, 0);
  g.add(handL);

  const handR = handL.clone();
  handR.position.x = 0.24;
  g.add(handR);

  // neck and oversized doll head
  const neck = new THREE.Mesh(
    new THREE.CylinderGeometry(0.05, 0.06, 0.09, 6),
    skin
  );
  neck.position.y = 0.78;
  g.add(neck);

  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.18, 8, 7),
    skin
  );
  head.scale.set(0.95, 1.10, 0.84);
  head.position.y = 0.94;
  g.add(head);

  // messy hair
  const hair = new THREE.Mesh(
    new THREE.SphereGeometry(0.19, 8, 6),
    dressDark
  );
  hair.scale.set(1.07, 0.80, 0.88);
  hair.position.set(0, 1.00, 0.015);
  g.add(hair);

  const sideHairL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.035, 0.22, 4, 6),
    dressDark
  );
  sideHairL.position.set(-0.17, 0.89, 0.01);
  g.add(sideHairL);

  const sideHairR = sideHairL.clone();
  sideHairR.position.x = 0.17;
  g.add(sideHairR);

  // dark eyes
  const eyeL = new THREE.Mesh(
    new THREE.SphereGeometry(0.028, 6, 5),
    crack
  );
  eyeL.position.set(-0.06, 0.96, -0.16);
  g.add(eyeL);

  const eyeR = eyeL.clone();
  eyeR.position.x = 0.06;
  g.add(eyeR);

  // open O mouth
  const mouth = new THREE.Mesh(
    new THREE.TorusGeometry(0.046, 0.014, 5, 8),
    mouthMat
  );
  mouth.position.set(0, 0.88, -0.17);
  g.add(mouth);

  // broken face
  const crack1 = new THREE.Mesh(
    new THREE.BoxGeometry(0.010, 0.13, 0.008),
    crack
  );
  crack1.position.set(-0.035, 1.03, -0.17);
  crack1.rotation.z = -0.30;
  g.add(crack1);

  const crack2 = new THREE.Mesh(
    new THREE.BoxGeometry(0.008, 0.09, 0.008),
    crack
  );
  crack2.position.set(0.075, 0.94, -0.17);
  crack2.rotation.z = 0.28;
  g.add(crack2);

  // skinny legs
  const legL = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.047, 0.25, 4, 6),
    skin
  );
  legL.position.set(-0.08, 0.18, 0);
  g.add(legL);

  const legR = legL.clone();
  legR.position.x = 0.08;
  g.add(legR);

  const shoeL = new THREE.Mesh(
    new THREE.BoxGeometry(0.095, 0.055, 0.17),
    dressDark
  );
  shoeL.position.set(-0.08, 0.032, -0.025);
  g.add(shoeL);

  const shoeR = shoeL.clone();
  shoeR.position.x = 0.08;
  g.add(shoeR);

  return g;
}

/* -------------------- ITEMS for counters -------------------- */
function placeNPCs() {
  // Meat on floor 4
  const meat = createItem(0x8b0000, 'meat');
  meat.position.set(-4, 0.4, 1.5);
  meat.userData = { type: 'item', item: 'meat' };
  scene.add(meat);
  interactables.push(meat);

  // Toy on floor 7
  const toy = createItem(0xff69b4, 'toy');
  toy.position.set(7, 0.4, -1.6);
  toy.userData = { type: 'item', item: 'toy' };
  scene.add(toy);
  interactables.push(toy);

  // Box on floor 7
  const box = new THREE.Mesh(
    new THREE.BoxGeometry(0.8, 0.5, 0.8),
    new THREE.MeshStandardMaterial({ color: 0x5a3a1a })
  );
  box.position.set(-2, 0.3, 1.7);
  box.userData = { type: 'box' };
  scene.add(box);
  interactables.push(box);
}

function createItem(color, name) {
  const g = new THREE.Group();
  const m = new THREE.Mesh(
    new THREE.SphereGeometry(0.25, 10, 8),
    new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.3 })
  );
  g.add(m);
  // no point light
  return g;
}

/* -------------------- CONTROLS -------------------- */
function setupKeys() {
  const on = (e, p) => {
    switch (e.code) {
      case 'KeyW': case 'ArrowUp':    move.f = p; break;
      case 'KeyS': case 'ArrowDown':  move.b = p; break;
      case 'KeyA': case 'ArrowLeft':  move.l = p; break;
      case 'KeyD': case 'ArrowRight': move.r = p; break;
      case 'KeyE': case 'Space': if (p) tryInteract(); break;
      case 'KeyQ': case 'KeyF': if (p) tryStun(); break;
    }
  };
  addEventListener('keydown', e => on(e, true));
  addEventListener('keyup',   e => on(e, false));
}


function setupMobile() {
  const base = document.getElementById('joystick-base');
  const stick = document.getElementById('joystick-stick');
  const lookZone = document.getElementById('look-zone');
  const interactBtn = document.getElementById('interact-btn');
  const stunBtn = document.getElementById('stun-btn');

  let joyId = null, lookId = null;
  let lastX = 0, lastY = 0;

  // --- JOYSTICK (left) ---
  if (base) {
    base.addEventListener('touchstart', e => {
      e.preventDefault();
      e.stopPropagation();
      const t = e.changedTouches[0];
      joyId = t.identifier;
    }, { passive: false });
  }

  // --- LOOK (right half of screen) ---
  if (lookZone) {
    lookZone.addEventListener('touchstart', e => {
      e.preventDefault();
      e.stopPropagation();
      const t = e.changedTouches[0];
      lookId = t.identifier;
      lastX = t.clientX;
      lastY = t.clientY;
    }, { passive: false });

    lookZone.addEventListener('touchmove', e => {
      e.preventDefault();
      e.stopPropagation();
      for (const t of e.changedTouches) {
        if (t.identifier !== lookId) continue;
        // Higher sensitivity so camera actually turns on phones
        const sens = 0.014;
        lookD.x += (t.clientX - lastX) * sens;
        lookD.y += (t.clientY - lastY) * sens;
        lastX = t.clientX;
        lastY = t.clientY;
      }
    }, { passive: false });

    lookZone.addEventListener('touchend', e => {
      for (const t of e.changedTouches) {
        if (t.identifier === lookId) lookId = null;
      }
    });
    lookZone.addEventListener('touchcancel', () => { lookId = null; });
  }

  // Global move for joystick only
  window.addEventListener('touchmove', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId && base) {
        e.preventDefault();
        const r = base.getBoundingClientRect();
        const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
        let dx = t.clientX - cx, dy = t.clientY - cy;
        const max = r.width / 2 - 8;
        const len = Math.hypot(dx, dy) || 1;
        if (len > max) { dx = dx / len * max; dy = dy / len * max; }
        if (stick) stick.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
        joy.x = dx / max;
        joy.y = -dy / max;
      }
    }
  }, { passive: false });

  window.addEventListener('touchend', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        joyId = null;
        if (stick) stick.style.transform = 'translate(-50%, -50%)';
        joy.x = 0; joy.y = 0;
      }
      if (t.identifier === lookId) lookId = null;
    }
  });

  if (interactBtn) {
    const doI = (e) => { e.preventDefault(); e.stopPropagation(); tryInteract(); };
    interactBtn.addEventListener('touchstart', doI, { passive: false });
    interactBtn.addEventListener('click', doI);
  }
  if (stunBtn) {
    const doS = (e) => { e.preventDefault(); e.stopPropagation(); tryStun(); };
    stunBtn.addEventListener('touchstart', doS, { passive: false });
    stunBtn.addEventListener('click', doS);
  }
}

/* -------------------- INTERACTION + ELEVATOR -------------------- */
function tryInteract() {
  if (gameOver) return;
  if (elevatorOpen && elevatorUI && !elevatorUI.classList.contains('hidden')) return;

  const mover = camera.position;

  // 1) Near elevator ends? Open floor menu immediately (most reliable)
  const halfL = CONFIG.corridorLength / 2;
  if (currentFloor !== 'Roof' && Math.abs(Math.abs(mover.x) - halfL) < 5.5 && Math.abs(mover.z) < 3.5) {
    openElevatorUI();
    return;
  }

  const origin = camera.getWorldPosition(new THREE.Vector3());
  const dir = camera.getWorldDirection(new THREE.Vector3());
  raycaster.set(origin, dir);
  raycaster.far = 5.0;

  const hits = raycaster.intersectObjects(interactables, true);
  let obj = null;
  if (hits.length) {
    obj = hits[0].object;
    while (obj && !obj.userData.type) obj = obj.parent;
  }

  if (!obj || (obj.userData.type !== 'elevator' && obj.userData.type !== 'elevator-btn' && obj.userData.type !== 'floor-btn')) {
    const near = interactables.find(o => {
      if (!o.userData || !o.userData.type) return false;
      const wp = new THREE.Vector3();
      o.getWorldPosition(wp);
      return wp.distanceTo(mover) < 5.0 && Math.abs(wp.y - mover.y) < 3.5;
    });
    if (near) obj = near;
  }

  if (!obj) return;
  const d = obj.userData;

  if (d.type === 'part' && !d.collected) {
    d.collected = true;
    collectedParts.add(d.id);
    partsCollected = collectedParts.size;
    partsEl.textContent = `Parts: ${partsCollected} / ${TOTAL_PARTS}`;
    obj.visible = false;
    showMsg(`Part ${d.id} collected!`);
    if (partsCollected >= TOTAL_PARTS) {
      document.getElementById('objective').textContent = 'All parts found! Go to the roof and fix the helicopter.';
    }
  }
  else if (d.type === 'floor-btn') {
    startElevatorRide(d.targetFloor);
  }
  else if (d.type === 'elevator' || d.type === 'elevator-btn') {
    openElevatorUI(); // floor menu
  }
  else if (d.type === 'item') {
    holdingItem = d.item;
    obj.visible = false;
    showMsg(`Picked up ${d.item}`);
  }
  else if (d.type === 'box' && holdingItem === 'toy') {
    holdingItem = null;
    showMsg('Toy placed in the box. Toy Girl is calm and shows the part.');
  }
  else if (d.type === 'room-door') {
    // Slide door open/closed
    if (!d.open) {
      d.open = true;
      if (d.closedX === undefined) d.closedX = obj.position.x;
      obj.position.x = d.closedX + 1.4;
      showMsg('Door opened — enter the room');
    } else {
      d.open = false;
      obj.position.x = d.closedX;
      showMsg('Door closed');
    }
  }
  else if (d.type === 'monster') {
    handleMonsterInteract(obj);
  }
}



function openElevatorUI() {
  // Minimal panel only as backup — prefer 3D buttons inside cabin
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (!ui) return;
  elevatorOpen = true;
  const box = document.getElementById('elevator-buttons');
  if (box) {
    [...box.querySelectorAll('button')].forEach(b => {
      b.classList.remove('current');
      if (String(currentFloor) === b.textContent || (currentFloor === 'Roof' && b.textContent === 'ROOF')) {
        b.classList.add('current');
      }
    });
  }
  const label = document.getElementById('elevator-current');
  if (label) label.textContent = currentFloor === 'Roof' ? 'Now: Roof' : `Now: Floor ${currentFloor}`;
  ui.classList.remove('hidden');
}

function startElevatorRide(target) {
  if (ridingElevator || gameOver) return;
  if (target !== 'roof' && Number(target) === Number(currentFloor)) {
    showMsg('Already here');
    return;
  }
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (ui) ui.classList.add('hidden');
  elevatorOpen = false;

  ridingElevator = true;
  rideTarget = target;
  ridePhase = 'loading';
  rideTimer = 2.0; // fixed 2 second floor load
  const label = target === 'roof' ? 'Roof' : ('Floor ' + target);
  showFloorLoading('Unloading floor… loading ' + label);
  showMsg('Traveling to ' + label + '…');
}

function goToFloor(f) {
  startElevatorRide(f);
}

function updateElevatorRide(dt) {
  if (!ridingElevator) return;
  rideTimer -= dt;
  if (rideTimer > 0) return;

  if (ridePhase === 'loading') {
    // Unload old floor, load new
    if (scene.userData.roofGroup) scene.userData.roofGroup.visible = false;
    unloadCurrentFloor();

    const mover = camera;
    if (rideTarget === 'roof') {
      if (scene.userData.roofGroup) scene.userData.roofGroup.visible = true;
      mover.position.set(0, CONFIG.playerHeight, 0);
      // place player on roof visually - roof group at height but we keep camera at 0 and show roof
      // simpler: roof at y=0 when loaded
      currentFloor = 'Roof';
      if (floorInd) floorInd.textContent = 'Roof';
      showMsg('Roof');
      if (partsCollected >= TOTAL_PARTS) {
        setTimeout(() => {
          if (winScreen) winScreen.classList.remove('hidden');
          gameOver = true;
        }, 600);
      } else {
        showMsg('Need all 10 parts for the helicopter');
      }
    } else {
      const floorNum = Number(rideTarget);
      loadFloor(floorNum);
      placePartsForFloor(floorNum);
      placeMonstersForFloor(floorNum);
      const side = mover.position.x >= 0 ? 1 : -1;
      const halfL = CONFIG.corridorLength / 2;
      mover.position.set(side * (halfL - 1.5), CONFIG.playerHeight, 0);
      showMsg('Floor ' + floorNum);
    }
    hideFloorLoading();
    ridingElevator = false;
    ridePhase = null;
  }
}

function handleMonsterInteract(m) {
  const k = m.userData.kind;
  if (k === 'hungry' && holdingItem === 'meat') {
    holdingItem = null;
    m.userData.alive = false;
    m.visible = false;
    showMsg('Hungry Zombie is satisfied. He leaves.');
  } else if (k === 'whisper') {
    showMsg('Whisper silenced… for now.');
    m.userData.state = 'calm';
  } else {
    showMsg(m.userData.desc);
  }
}

/* -------------------- MONSTER AI -------------------- */
function updateMonsters(dt) {
  if (gameOver) return;
  const playerPos = (isMobile || !controls) ? camera.position : controls.getObject().position;
  // Monsters only "work" when player is in a room (away from corridor center)
  const halfW = CONFIG.corridorWidth / 2;
  playerInRoom = Math.abs(playerPos.z) > halfW - 0.3;

  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor !== currentFloor && currentFloor !== 'Roof') return;
    // Idle in hallway — only hunt inside rooms
    if (!playerInRoom && currentFloor !== 'Roof') {
      // slowly face player but don't chase/kill
      m.lookAt(playerPos.x, m.position.y, playerPos.z);
      return;
    }

    // Stunned monsters do nothing
    if (m.userData.stunned) return;

    const kind = m.userData.kind;
    const toPlayer = new THREE.Vector3().subVectors(playerPos, m.position);
    const dist = toPlayer.length();
    toPlayer.y = 0;
    toPlayer.normalize();

    // Is player looking at monster?
    const lookDir = camera.getWorldDirection(new THREE.Vector3());
    const toM = new THREE.Vector3().subVectors(m.position, camera.position).normalize();
    const lookingAt = lookDir.dot(toM) > 0.85 && dist < 12;

    if (kind === 'watcher') {
      if (lookingAt) {
        // freeze
      } else if (dist > 1.5) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      } else kill('The Watcher caught you');
    }
    else if (kind === 'gaze') {
      if (lookingAt) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 2.0) kill('You stared too long at the Gaze Beast');
      } else {
        m.userData.lookTimer = Math.max(0, m.userData.lookTimer - dt * 0.5);
      }
    }
    else if (kind === 'hungry') {
      if (dist > 1.8) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (holdingItem !== 'meat') kill('The Hungry Zombie reached you');
    }
    else if (kind === 'backtext') {
      // if player is looking roughly away from monster while close
      const away = lookDir.dot(toM) < -0.3;
      if (away && dist < 8) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.2) kill('You looked at your back…');
      } else m.userData.lookTimer = 0;
      if (dist > 2) m.position.addScaledVector(toPlayer, m.userData.speed * 0.6 * dt);
    }
    else if (kind === 'stalker') {
      // moves toward where player is going
      const predict = playerPos.clone().add(lookDir.clone().multiplyScalar(3));
      const toPred = new THREE.Vector3().subVectors(predict, m.position);
      toPred.y = 0; toPred.normalize();
      if (dist > 1.6) m.position.addScaledVector(toPred, m.userData.speed * dt);
      else kill('The Pale Girl caught you');
    }
    else if (kind === 'toy') {
      if (holdingItem === 'toy') {
        // follows calmly
        if (dist > 2.5) m.position.addScaledVector(toPlayer, 1.5 * dt);
      } else if (dist < 2.0) {
        // aggressive until toy is placed
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      }
    }
    else if (kind === 'crier') {
      if (lookingAt && Math.abs(joy.x) + Math.abs(joy.y) < 0.1 && !move.f && !move.b && !move.l && !move.r) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.5) {
          m.userData.alive = false;
          m.visible = false;
          showMsg('Blood Crier calmed down and vanished.');
        }
      } else {
        m.userData.lookTimer = 0;
        if (dist > 1.7) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
        else kill('The Blood Crier reached you');
      }
    }
    else if (kind === 'shadowstep') {
      const moving = Math.abs(joy.x) + Math.abs(joy.y) > 0.1 || move.f || move.b || move.l || move.r;
      if (moving && dist > 1.5) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (!moving) { /* frozen */ }
      else kill('Shadow Step touched you');
    }
    else if (kind === 'whisper') {
      if (m.userData.state !== 'calm' && dist < 4) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 4) kill('The Whisper Doll’s voice took you');
      }
    }
  });
}

function kill(reason) {
  if (gameOver) return;
  if (gameMode === 'peaceful') {
    showMsg('Peaceful mode — you survive');
    return;
  }
  gameOver = true;
  showMsg(reason, 5000);
  setTimeout(() => location.reload(), 3500);
}

function killPlayer(msg) {
  if (gameMode === 'peaceful') {
    showMsg('Peaceful — survived');
    return;
  }
  showMsg(msg || 'You died…');
  gameOver = true;
}

function tryStun() {
  if (gameOver || stunCooldown > 0 || stunActive > 0) return;
  // Stun every monster on the current floor
  let hit = 0;
  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor === currentFloor || currentFloor === 'Roof') {
      m.userData.stunned = true;
      hit++;
    }
  });
  if (hit > 0) {
    stunActive = 3;
    stunCooldown = 15;
    showMsg(`Monster stunned for 3 seconds! (${hit})`);
  } else {
    showMsg('No monster on this floor');
    stunCooldown = 2; // small anti-spam
  }
  updateStunUI();
}

function updateStunUI() {
  const desk = document.getElementById('stun-btn-desktop');
  const setState = (btn, text, disabled) => {
    if (!btn) return;
    btn.disabled = disabled;
    btn.textContent = text;
  };
  if (stunCooldown > 0) {
    const t = Math.ceil(stunCooldown) + 's';
    setState(stunBtn, t, true);
    setState(desk, t, true);
    if (stunCdEl) stunCdEl.textContent = 'Cooldown';
  } else if (stunActive > 0) {
    setState(stunBtn, 'STUNNED', true);
    setState(desk, 'STUNNED', true);
  } else {
    setState(stunBtn, 'STUN', false);
    setState(desk, 'STUN (Q)', false);
    if (stunCdEl) stunCdEl.textContent = 'Ready';
  }
}

/* -------------------- ANIMATION -------------------- */
// Cap at ~45 FPS for stable mobile performance
const FPS_LIMIT = 45;
const FRAME_TIME = 1 / FPS_LIMIT;
let fpsAccum = 0;

function animate() {
  requestAnimationFrame(animate);
  const rawDt = clock.getDelta();
  fpsAccum += rawDt;
  if (fpsAccum < FRAME_TIME) return;
  const dt = Math.min(fpsAccum, 0.05);
  fpsAccum = 0;

  if (gameOver) {
    renderer.render(scene, camera);
    return;
  }

  // Stun timers
  if (stunActive > 0) {
    stunActive -= dt;
    if (stunActive <= 0) {
      stunActive = 0;
      monsters.forEach(m => { m.userData.stunned = false; });
    }
  }
  if (stunCooldown > 0) {
    stunCooldown -= dt;
    if (stunCooldown < 0) stunCooldown = 0;
  }
  updateStunUI();

  const speed = ridingElevator ? 0 : CONFIG.playerSpeed * dt;
  const forward = new THREE.Vector3();
  const right = new THREE.Vector3();
  const mover = isMobile || !controls ? camera : controls.getObject();

  if (isMobile) {
    camera.rotation.order = 'YXZ';
    camera.rotation.y -= lookD.x;
    camera.rotation.x -= lookD.y;
    camera.rotation.x = Math.max(-1.2, Math.min(1.2, camera.rotation.x));
    lookD.x = 0; lookD.y = 0;

    camera.getWorldDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    mover.position.addScaledVector(forward, joy.y * speed);
    mover.position.addScaledVector(right, joy.x * speed);
  } else if (controls && controls.isLocked) {
    controls.getDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    if (move.f) mover.position.addScaledVector(forward, speed);
    if (move.b) mover.position.addScaledVector(forward, -speed);
    if (move.l) mover.position.addScaledVector(right, -speed);
    if (move.r) mover.position.addScaledVector(right, speed);
  }

  // Bounds — allow walking into rooms
  const halfL = CONFIG.corridorLength/2 - 0.8;
  const maxZ = CONFIG.corridorWidth/2 + CONFIG.roomDepth - 0.8;
  mover.position.x = Math.max(-halfL, Math.min(halfL, mover.position.x));
  mover.position.z = Math.max(-maxZ, Math.min(maxZ, mover.position.z));

  // Streamed floors sit at y=0
  mover.position.y = CONFIG.playerHeight;

  updateElevatorRide(dt);

  // Hint when near elevator (no auto app panel)
  {
    const pos = camera.position;
    let inElev = false;
    if (currentFloor !== 'Roof') {
      for (const el of elevators) {
        if (el.floor !== currentFloor) continue;
        const wp = new THREE.Vector3();
        el.group.getWorldPosition(wp);
        // Standing at the wall elevator opening
        if (Math.abs(pos.x - wp.x) < 2.5 && Math.abs(pos.z - wp.z) < 2.2) {
          inElev = true;
          break;
        }
      }
      // Also detect by corridor ends
      const halfL = CONFIG.corridorLength / 2;
      if (Math.abs(Math.abs(pos.x) - halfL) < 2.8 && Math.abs(pos.z) < 2.5) {
        inElev = true;
      }
    }
    insideElevator = inElev;
    if (inElev && !elevPromptShown && !gameOver && !ridingElevator) {
      elevPromptShown = true;
      showMsg('INTERACT to open floor menu', 2000);
    }
    if (!inElev) elevPromptShown = false;
  }

  // No door animation — elevators always open


  updateMonsters(dt);
  multiplayerTick(dt);

  // Part spin only every other frame feel — cheap
  parts.forEach(p => {
    if (!p.userData.collected) p.rotation.y += dt * 0.8;
  });

  renderer.render(scene, camera);
}

function setupUI() {
  // Elevator buttons – large, mobile-friendly
  const box = document.getElementById('elevator-buttons');
  if (box) box.innerHTML = '';
  for (let i = 1; i <= 10; i++) {
    const b = document.createElement('button');
    b.textContent = i;
    b.type = 'button';
    const go = (e) => { e.preventDefault(); goToFloor(i); };
    b.addEventListener('click', go);
    b.addEventListener('touchend', go, { passive: false });
    box.appendChild(b);
  }
  const roofBtn = document.createElement('button');
  roofBtn.textContent = 'ROOF';
  roofBtn.className = 'roof';
  roofBtn.type = 'button';
  const goRoof = (e) => { e.preventDefault(); goToFloor('roof'); };
  roofBtn.addEventListener('click', goRoof);
  roofBtn.addEventListener('touchend', goRoof, { passive: false });
  box.appendChild(roofBtn);

  document.getElementById('elevator-close').onclick = () => {
    elevatorUI.classList.add('hidden');
    elevatorOpen = false;
  };

  // FLOORS HUD button removed — use elevator in the hall

  document.getElementById('dialogue-close').onclick = () => dialogue.classList.add('hidden');
  document.getElementById('restart-btn').onclick = () => location.reload();

  if (stunBtn) {
    stunBtn.addEventListener('click', tryStun);
    stunBtn.addEventListener('touchstart', e => { e.preventDefault(); tryStun(); }, { passive: false });
  }
  const stunDesk = document.getElementById('stun-btn-desktop');
  if (stunDesk) {
    stunDesk.addEventListener('click', tryStun);
  }

  let p = 0;
  const iv = setInterval(() => {
    p += 15;
    progressEl.style.width = Math.min(p, 95) + '%';
    if (p >= 95) clearInterval(iv);
  }, 60);
}

init().catch(console.error);

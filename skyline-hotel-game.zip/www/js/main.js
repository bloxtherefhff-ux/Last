import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

/* ============================================================
   SKYLINE HOTEL – 10 FLOORS
   Brighter atmosphere + monsters with counters
   ============================================================ */

const CONFIG = {
  floors: 10,
  floorHeight: 4.2,
  corridorWidth: 7,
  corridorLength: 28,
  playerHeight: 1.7,
  playerSpeed: 6.5,
  roomDepth: 9
};
let roomDoors = [];
let playerInRoom = false;


let scene, camera, renderer, controls;
let currentFloor = 1;
let partsCollected = 0;
const TOTAL_PARTS = 10;
let gameMode = 'normal'; // normal | peaceful
let multiplayer = false;
let isHost = false;
let peer = null;
let myPeerId = null;
let roomCode = null;
let monsterSeed = null;
let playerName = 'Player';
let playerAvatar = 0; // index into AVATAR_COLORS
const AVATAR_COLORS = [0x4488ff, 0x44cc66, 0xff8844, 0xcc44cc, 0xff4466, 0x44cccc, 0xffcc33, 0xaaaaaa];


const peerConns = []; // DataConnections
const remotePlayers = {}; // id -> { mesh, last }
const MAX_PLAYERS = 3;
const PLAYER_COLORS = [0x4488ff, 0x44cc66, 0xff8844];


let move = { f: false, b: false, l: false, r: false };
let isMobile = false;
let joy = { x: 0, y: 0 };
let lookD = { x: 0, y: 0 };
let interactables = [];
let monsters = [];
let elevators = []; // {floor, side, doorL, doorR, group, zone}
let insideElevator = false;
let elevPromptShown = false;
let ridingElevator = false;
let rideTimer = 0;
let ridePhase = null; // closing | moving | opening
let rideTarget = null;
let parts = [];
const collectedParts = new Set(); // part ids 1-10
let clock = new THREE.Clock();
let raycaster = new THREE.Raycaster();
let elevatorOpen = false;
let gameOver = false;
let holdingItem = null; // for toy / meat
let stunCooldown = 0;   // seconds remaining before stun can be used again
let stunActive = 0;     // seconds remaining of current stun

// DOM
const loadingEl = document.getElementById('loading');
const progressEl = document.getElementById('progress');
const hud = document.getElementById('hud');
const floorInd = document.getElementById('floor-indicator');
const partsEl = document.getElementById('parts');
const mobileControls = document.getElementById('mobile-controls');
const dialogue = document.getElementById('dialogue');
const npcNameEl = document.getElementById('npc-name');
const npcTextEl = document.getElementById('npc-text');
const winScreen = document.getElementById('win-screen');
const elevatorUI = document.getElementById('elevator-ui');
const msgEl = document.getElementById('msg');
const stunBtn = document.getElementById('stun-btn');
const stunCdEl = document.getElementById('stun-cd');

function showMsg(text, time = 3000) {
  msgEl.textContent = text;
  msgEl.classList.remove('hidden');
  setTimeout(() => msgEl.classList.add('hidden'), time);
}




function loadProfile() {
  try {
    const n = localStorage.getItem('sky_name');
    const a = localStorage.getItem('sky_avatar');
    if (n) playerName = n.slice(0, 12);
    if (a != null) playerAvatar = Math.max(0, Math.min(AVATAR_COLORS.length - 1, parseInt(a, 10) || 0));
  } catch (e) {}
}

function saveProfile() {
  try {
    localStorage.setItem('sky_name', playerName);
    localStorage.setItem('sky_avatar', String(playerAvatar));
  } catch (e) {}
}

function setupProfileUI() {
  loadProfile();
  const nameIn = document.getElementById('player-name');
  const row = document.getElementById('avatar-row');
  const prev = document.getElementById('avatar-preview');
  if (nameIn) {
    nameIn.value = playerName;
    nameIn.addEventListener('input', () => {
      playerName = (nameIn.value || 'Player').trim().slice(0, 12) || 'Player';
      saveProfile();
    });
  }
  if (row) {
    row.innerHTML = '';
    AVATAR_COLORS.forEach((col, i) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'avatar-opt' + (i === playerAvatar ? ' selected' : '');
      b.style.background = '#' + col.toString(16).padStart(6, '0');
      b.addEventListener('click', () => {
        playerAvatar = i;
        row.querySelectorAll('.avatar-opt').forEach((x, j) => {
          x.classList.toggle('selected', j === i);
        });
        if (prev) prev.style.background = b.style.background;
        saveProfile();
      });
      row.appendChild(b);
    });
  }
  if (prev) prev.style.background = '#' + AVATAR_COLORS[playerAvatar].toString(16).padStart(6, '0');
}

function setupStartMenu() {
  const btnN = document.getElementById('btn-normal');
  const btnP = document.getElementById('btn-peaceful');
  const btnPlay = document.getElementById('btn-play');
  const btnHost = document.getElementById('btn-host');
  const btnJoin = document.getElementById('btn-join');
  const status = document.getElementById('mp-status');

  btnN.onclick = () => {
    gameMode = 'normal';
    btnN.classList.add('active');
    btnP.classList.remove('active');
  };
  btnP.onclick = () => {
    gameMode = 'peaceful';
    btnP.classList.add('active');
    btnN.classList.remove('active');
  };
  btnPlay.onclick = () => {
    multiplayer = false;
    beginGame();
  };

  btnHost.onclick = () => {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      status.textContent = 'No internet. Hotspot with 0 data cannot matchmake. Turn on mobile data briefly OR use Wi‑Fi with internet.';
      return;
    }
    if (typeof Peer === 'undefined') {
      status.textContent = 'PeerJS failed to load — need internet once to download/connect';
      return;
    }
    status.textContent = 'Creating room…';
    multiplayer = true;
    isHost = true;
    monsterSeed = (Math.random() * 1e9) | 0;
    // Short readable code as peer id prefix
    const code = Math.random().toString(36).slice(2, 6).toUpperCase();
    roomCode = code;
    const id = 'sky' + code.toLowerCase();
    peer = new Peer(id, { debug: 1 });
    peer.on('open', (pid) => {
      myPeerId = pid;
      status.textContent = 'YOUR CODE: ' + code + ' — friends JOIN with this. Starting in 3s…';
      setTimeout(() => {
        if (!document.getElementById('start-menu').classList.contains('hidden')) {
          status.textContent = 'ROOM ' + code + ' live as ' + playerName;
          beginGame();
        }
      }, 3000);
    });
    peer.on('connection', (conn) => {
      setupConn(conn);
    });
    peer.on('error', (err) => {
      status.textContent = 'Host error: ' + (err.type || err.message || err) + ' — try another code';
    });
    peer.on('disconnected', () => {
      status.textContent = 'Disconnected from Peer server — check internet';
    });
  };

  btnJoin.onclick = () => {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      status.textContent = 'No internet. Offline hotspot (no balance) cannot join. Need data/internet for matchmaking.';
      return;
    }
    if (typeof Peer === 'undefined') {
      status.textContent = 'PeerJS failed to load — need internet';
      return;
    }
    const code = (document.getElementById('join-code').value || '').trim().toUpperCase();
    if (code.length < 3) {
      status.textContent = 'Enter the host room code';
      return;
    }
    status.textContent = 'Connecting to ' + code + '…';
    multiplayer = true;
    isHost = false;
    roomCode = code;
    peer = new Peer({ debug: 1 });
    peer.on('open', () => {
      myPeerId = peer.id;
      const hostId = 'sky' + code.toLowerCase();
      const conn = peer.connect(hostId, { reliable: true });
      setupConn(conn);
      conn.on('open', () => {
        status.textContent = 'Connected! Starting…';
        beginGame();
      });
      conn.on('error', (e) => {
        status.textContent = 'Join failed — is host online? Code correct?';
      });
    });
    peer.on('error', (err) => {
      status.textContent = 'Join error: ' + (err.type || err.message || err);
    });
  };
}

function setupConn(conn) {
  conn.on('open', () => {
    if (peerConns.length >= MAX_PLAYERS - 1) {
      conn.send({ type: 'full' });
      conn.close();
      return;
    }
    peerConns.push(conn);
    // Introduce ourselves
    conn.send({
      type: 'hello',
      id: myPeerId,
      mode: gameMode,
      name: playerName || (isHost ? 'Host' : 'Player'),
      avatar: playerAvatar,
      seed: monsterSeed,
      isHost: isHost
    });
  });
  conn.on('data', (data) => {
    if (!data || !data.type) return;
    if (data.type === 'full') {
      const status = document.getElementById('mp-status');
      if (status) status.textContent = 'Room full (max 3)';
      return;
    }
    if (data.type === 'hello') {
      ensureRemotePlayer(data.id, data.name, data.avatar);
      // Joiners take host seed so monsters match
      if (data.isHost && data.seed != null && !isHost) {
        monsterSeed = data.seed;
        if (typeof data.mode === 'string') gameMode = data.mode;
      }
      if (!conn.userData) conn.userData = {};
      if (!conn.userData.saidHello) {
        conn.userData.saidHello = true;
        try {
          conn.send({
            type: 'hello',
            id: myPeerId,
            name: playerName || (isHost ? 'Host' : 'Player'),
            avatar: playerAvatar,
            seed: monsterSeed,
            isHost: isHost,
            mode: gameMode
          });
        } catch (e) {}
      }
    }
    if (data.type === 'pos') {
      updateRemotePlayer(data);
      // HOST RELAY so player2 and player3 see each other
      if (isHost) {
        peerConns.forEach(c => {
          if (c !== conn && c.open) {
            try { c.send(data); } catch (e) {}
          }
        });
      }
    }
  });
  conn.on('close', () => {
    const i = peerConns.indexOf(conn);
    if (i >= 0) peerConns.splice(i, 1);
  });
}

function ensureRemotePlayer(id, name, avatarIdx) {
  if (!id || id === myPeerId) return;
  if (!scene) return;
  const color = AVATAR_COLORS[(avatarIdx != null ? avatarIdx : 0) % AVATAR_COLORS.length];
  if (remotePlayers[id]) {
    // update name plate if needed
    remotePlayers[id].name = name || remotePlayers[id].name;
    return;
  }
  const g = new THREE.Group();
  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.28, 0.9, 4, 8),
    new THREE.MeshLambertMaterial({ color })
  );
  body.position.y = 1.0;
  g.add(body);
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.22, 8, 6),
    new THREE.MeshLambertMaterial({ color: 0xffddbb })
  );
  head.position.y = 1.75;
  g.add(head);
  const c = document.createElement('canvas');
  c.width = 160; c.height = 40;
  const ctx = c.getContext('2d');
  ctx.fillStyle = 'rgba(0,0,0,0.75)';
  ctx.fillRect(0, 0, 160, 40);
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 16px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText((name || 'Player').slice(0, 12), 80, 26);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true }));
  spr.scale.set(1.4, 0.35, 1);
  spr.position.y = 2.2;
  g.add(spr);
  scene.add(g);
  remotePlayers[id] = { mesh: g, last: performance.now(), name: name || 'Player' };
}

function updateRemotePlayer(data) {
  if (!data.id || data.id === myPeerId) return;
  ensureRemotePlayer(data.id, data.name, data.avatar);
  const rp = remotePlayers[data.id];
  if (!rp || !rp.mesh) return;
  rp.mesh.position.set(data.x, data.y, data.z);
  if (typeof data.ry === 'number') rp.mesh.rotation.y = data.ry;
  // Hide if on different floor (streamed floors)
  const sameFloor = String(data.floor) === String(currentFloor);
  rp.mesh.visible = sameFloor;
  rp.last = performance.now();
  rp.floor = data.floor;
}

let _mpSendAcc = 0;
function multiplayerTick(dt) {
  if (!multiplayer || !peerConns.length) return;
  _mpSendAcc += dt;
  if (_mpSendAcc < 0.1) return; // ~10 Hz — lighter on mobile
  _mpSendAcc = 0;
  if (!myPeerId || !camera) return;
  const payload = {
    type: 'pos',
    id: myPeerId,
    x: camera.position.x,
    y: camera.position.y,
    z: camera.position.z,
    ry: camera.rotation.y,
    floor: currentFloor,
    parts: partsCollected
  };
  peerConns.forEach(c => {
    if (c && c.open) {
      try { c.send(payload); } catch (e) {}
    }
  });
  // Hide stale remotes (no update 4s)
  const now = performance.now();
  Object.keys(remotePlayers).forEach(id => {
    const rp = remotePlayers[id];
    if (rp && now - rp.last > 4000) rp.mesh.visible = false;
  });
}

async function init() {
  setupProfileUI();
  setupStartMenu();
}

function beginGame() {
  document.getElementById('start-menu').classList.add('hidden');
  document.getElementById('loading').classList.remove('hidden');
  isMobile = true;

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x4a4a5e);
  scene.fog = null; // fog costs FPS on mobile

  camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.15, 55);
  camera.position.set(0, CONFIG.playerHeight, 0);
  camera.rotation.order = 'YXZ';
  camera.rotation.y = -Math.PI / 2; // face +X elevator in the end wall
  camera.rotation.order = 'YXZ';

  renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', alpha: false });
  renderer.setSize(innerWidth, innerHeight);
  // Critical for mid-range phones: never above 1
  renderer.setPixelRatio(1);
  renderer.shadowMap.enabled = false;
  renderer.domElement.style.position = 'fixed';
  renderer.domElement.style.inset = '0';
  renderer.domElement.style.zIndex = '1';
  renderer.domElement.style.pointerEvents = 'none'; // CRITICAL: touches go to UI
  document.body.appendChild(renderer.domElement);

  // Cheap lighting only (point lights kill mobile FPS)
  scene.add(new THREE.AmbientLight(0xffffff, 1.55));

  if (monsterSeed == null) randomizeMonsters();
  else randomizeMonsters(monsterSeed);
  buildRoofOnly();
  loadFloor(1);
  placePartsForFloor(1);
  placeMonstersForFloor(1);
  placeNPCs();

  setupMobile();
  setupKeys();
  setupUI();

  progressEl.style.width = '100%';
  setTimeout(() => {
    loadingEl.classList.add('hidden');
    hud.classList.remove('hidden');
    mobileControls.classList.remove('hidden');
  }, 700);

  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });

  animate();
}

/* -------------------- HOTEL -------------------- */

function disposeObject(obj) {
  obj.traverse(o => {
    if (o.geometry) o.geometry.dispose();
    if (o.material) {
      if (Array.isArray(o.material)) o.material.forEach(m => m.dispose && m.dispose());
      else if (o.material.dispose) o.material.dispose();
    }
  });
}

function unloadCurrentFloor() {
  const g = scene.userData.currentFloorGroup;
  if (g) {
    scene.remove(g);
    disposeObject(g);
    scene.userData.currentFloorGroup = null;
  }
  // Remove interactables that belonged to floor geometry (doors, elevators)
  interactables = interactables.filter(o => {
    const t = o.userData && o.userData.type;
    // drop floor-local items/doors; keep nothing from old floor
    if (t === 'item' || t === 'box' || t === 'room-door' || t === 'elevator') return false;
    return t === 'part' || t === 'monster';
  });
  // remove leftover item meshes
  scene.children.slice().forEach(ch => {
    if (ch.userData && (ch.userData.type === 'item' || ch.userData.type === 'box')) {
      scene.remove(ch);
    }
  });
  roomDoors = [];
  elevators = [];
  // Remove monsters on old floor
  monsters.forEach(m => {
    scene.remove(m);
    disposeObject(m);
  });
  monsters = [];
  // Hide old parts meshes (keep collected state)
  parts.forEach(p => {
    if (p.parent) p.parent.remove(p);
    scene.remove(p);
  });
  // keep parts array for collected flags — rebuild uncollected on load
}

function buildRoofOnly() {
  const roofY = CONFIG.floors * CONFIG.floorHeight;
  // Simple roof platform only (always available reference, light)
  const roof = new THREE.Group();
  roof.position.y = roofY;
  const pad = new THREE.Mesh(
    new THREE.BoxGeometry(20, 0.3, 16),
    new THREE.MeshLambertMaterial({ color: 0x5a5a62 })
  );
  roof.add(pad);
  createHelicopter();
  // helipad is created in createHelicopter on roof — adjust
  scene.userData.roofGroup = roof;
  scene.add(roof);
  roof.visible = false;
}




function loadFloor(f) {
  /* Layout:
     [RED ROOM] — door — HALLWAY — door — [BLUE ROOM]   (rooms at EACH END)
     Side walls: GOLD ELEVATORS (where the side rooms used to be)
  */
  const M = {
    wall: new THREE.MeshLambertMaterial({ color: 0x6a5e52 }),
    floor: new THREE.MeshLambertMaterial({ color: 0x5a4e42 }),
    ceil: new THREE.MeshLambertMaterial({ color: 0x4a423a }),
    carpet: new THREE.MeshLambertMaterial({ color: 0x8a3a3a }),
    red: new THREE.MeshLambertMaterial({ color: 0x9a1a1a }),
    blue: new THREE.MeshLambertMaterial({ color: 0x1a3a9a }),
    gold: new THREE.MeshLambertMaterial({ color: 0xd4a84b }),
    frame: new THREE.MeshLambertMaterial({ color: 0x2a2218 }),
    bed: new THREE.MeshLambertMaterial({ color: 0x4a3038 }),
    wood: new THREE.MeshLambertMaterial({ color: 0x6b4a30 }),
    rugR: new THREE.MeshLambertMaterial({ color: 0x5a2028 }),
    rugB: new THREE.MeshLambertMaterial({ color: 0x203050 }),
    metal: new THREE.MeshLambertMaterial({ color: 0x777780 })
  };

  const halfL = CONFIG.corridorLength / 2;
  const halfW = CONFIG.corridorWidth / 2;
  const h = CONFIG.floorHeight - 0.25;
  const roomD = CONFIG.roomDepth; // depth past the end of the hall
  const doorW = 2.6;
  const doorH = 2.7;

  const g = new THREE.Group();
  g.userData.floorNum = f;

  // Floor: corridor + rooms past both ends
  const slab = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.corridorLength + roomD * 2 + 2, 0.2, CONFIG.corridorWidth + 2),
    M.floor
  );
  slab.position.y = -0.1;
  g.add(slab);

  const carpet = new THREE.Mesh(new THREE.BoxGeometry(CONFIG.corridorLength - 1, 0.02, 2.0), M.carpet);
  carpet.position.y = 0.02;
  g.add(carpet);

  const ceil = new THREE.Mesh(new THREE.BoxGeometry(CONFIG.corridorLength, 0.15, CONFIG.corridorWidth), M.ceil);
  ceil.position.y = CONFIG.floorHeight - 0.08;
  g.add(ceil);

  // Full side walls (no room doors on sides — elevators go here)
  for (const zs of [-1, 1]) {
    const wall = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength + 0.4, h, 0.35),
      M.wall
    );
    // leave mid gap for elevator opening
    // build two segments with elevator gap at x=0
    const elevW = 2.8;
    const segs = [
      [-halfL - 0.2, -elevW / 2],
      [elevW / 2, halfL + 0.2]
    ];
    segs.forEach(([a, b]) => {
      const w = b - a;
      if (w < 0.2) return;
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, 0.35), M.wall);
      m.position.set((a + b) / 2, h / 2, zs * halfW);
      g.add(m);
    });
    // lintel over elevator hole
    const lintel = new THREE.Mesh(new THREE.BoxGeometry(elevW + 0.2, 0.35, 0.4), M.wall);
    lintel.position.set(0, doorH + 0.15, zs * halfW);
    g.add(lintel);
  }

  // End walls of corridor with doorway into rooms
  function endWall(xSign) {
    const x = xSign * halfL;
    const gap = doorW;
    // left/right pillars of end wall (along Z)
    for (const zs of [-1, 1]) {
      const zw = (halfW - gap / 2);
      if (zw < 0.15) continue;
      const p = new THREE.Mesh(new THREE.BoxGeometry(0.4, h, zw), M.wall);
      p.position.set(x, h / 2, zs * (gap / 2 + zw / 2));
      g.add(p);
    }
    const top = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, gap + 0.2), M.wall);
    top.position.set(x, doorH + 0.15, 0);
    g.add(top);
  }
  endWall(-1);
  endWall(1);

  // Doors at corridor ENDS (red -X, blue +X)
  function makeEndDoor(xSign, mat, label) {
    const group = new THREE.Group();
    group.position.set(xSign * halfL, 0, 0);
    const panel = new THREE.Mesh(new THREE.BoxGeometry(0.14, doorH, doorW - 0.1), mat);
    panel.position.y = doorH / 2;
    group.add(panel);
    // frame
    for (const zs of [-1, 1]) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.28, doorH + 0.1, 0.16), M.frame);
      post.position.set(0, doorH / 2, zs * (doorW / 2));
      group.add(post);
    }
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.1), M.gold);
    handle.position.set(xSign * 0.1, 1.15, doorW * 0.25);
    group.add(handle);
    group.userData = {
      type: 'room-door',
      open: false,
      side: xSign,
      floor: f,
      label,
      closedZ: 0,
      endDoor: true
    };
    panel.userData = group.userData;
    g.add(group);
    interactables.push(group, panel);
    roomDoors.push(group);
  }
  makeEndDoor(-1, M.red, 'RED');
  makeEndDoor(1, M.blue, 'BLUE');

  // Rooms BEHIND each end
  function makeEndRoom(xSign, isRed) {
    const cx = xSign * (halfL + roomD / 2);
    const fl = new THREE.Mesh(
      new THREE.BoxGeometry(roomD, 0.06, CONFIG.corridorWidth + 1.5),
      isRed ? M.rugR : M.rugB
    );
    fl.position.set(cx, 0.02, 0);
    g.add(fl);
    // back wall
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.25, 3.0, CONFIG.corridorWidth + 1.5), M.wall);
    back.position.set(xSign * (halfL + roomD), 1.5, 0);
    g.add(back);
    // side walls of room
    for (const zs of [-1, 1]) {
      const sw = new THREE.Mesh(new THREE.BoxGeometry(roomD, 3.0, 0.25), M.wall);
      sw.position.set(cx, 1.5, zs * (halfW + 0.75));
      g.add(sw);
    }
    // furniture
    const bed = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.4, 2.4), M.bed);
    bed.position.set(cx + xSign * 1.2, 0.35, -1.2);
    g.add(bed);
    const desk = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.65, 1.2), M.wood);
    desk.position.set(cx + xSign * 0.5, 0.4, 1.5);
    g.add(desk);
    const ward = new THREE.Mesh(new THREE.BoxGeometry(0.55, 2.2, 1.1), M.wood);
    ward.position.set(cx - xSign * 2.0, 1.15, 1.3);
    g.add(ward);
  }
  makeEndRoom(-1, true);
  makeEndRoom(1, false);

  // Elevators on SIDE walls (middle) — where blue/red used to be
  createElevatorSide(g, -halfW, f);
  createElevatorSide(g, halfW, f);

  scene.add(g);
  scene.userData.currentFloorGroup = g;
  currentFloor = f;
  if (floorInd) floorInd.textContent = 'Floor ' + f;

  camera.position.set(0, CONFIG.playerHeight, 0);
  camera.rotation.order = 'YXZ';
  camera.rotation.y = 0; // look toward +Z / along hall center
  camera.rotation.x = 0;
}

function showFloorLoading(text) {
  let el = document.getElementById('floor-loading');
  if (!el) {
    el = document.createElement('div');
    el.id = 'floor-loading';
    el.style.cssText = 'position:fixed;inset:0;z-index:500;background:rgba(5,5,12,0.92);display:flex;align-items:center;justify-content:center;flex-direction:column;color:#d4a84b;font-family:system-ui;';
    el.innerHTML = '<div style="font-size:1.4rem;font-weight:700;margin-bottom:12px;">LOADING FLOOR</div><div id="floor-loading-text"></div>';
    document.body.appendChild(el);
  }
  const t = document.getElementById('floor-loading-text');
  if (t) t.textContent = text || '';
  el.style.display = 'flex';
  el.classList.remove('hidden');
}

function hideFloorLoading() {
  const el = document.getElementById('floor-loading');
  if (el) el.style.display = 'none';
}





function createElevator(parent, x, floorNum) {
  // legacy end elevators (unused) — side elevators preferred
  createElevatorSide(parent, 0, floorNum, x);
}

function createElevatorSide(parent, z, floorNum, xPos) {
  // Gold elevator on the SIDE of the hallway (into the side wall)
  const side = z >= 0 ? 1 : -1;
  const group = new THREE.Group();
  const x = (xPos != null && xPos !== 0) ? xPos : 0;
  group.position.set(x, 0, z);

  const gold = new THREE.MeshLambertMaterial({ color: 0xe8b84a });
  const dark = new THREE.MeshLambertMaterial({ color: 0x14141c });

  // Frame facing into corridor (along Z)
  const L = new THREE.Mesh(new THREE.BoxGeometry(0.35, 2.9, 0.35), gold);
  L.position.set(-1.35, 1.45, 0); group.add(L);
  const R = L.clone(); R.position.x = 1.35; group.add(R);
  const top = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.35, 0.35), gold);
  top.position.set(0, 2.95, 0); group.add(top);
  const hole = new THREE.Mesh(new THREE.BoxGeometry(2.5, 2.7, 0.4), dark);
  hole.position.set(0, 1.4, -side * 0.15); group.add(hole);

  const hit = new THREE.Mesh(
    new THREE.BoxGeometry(3.2, 3.2, 3.0),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hit.position.set(0, 1.5, 0);
  hit.userData = { type: 'elevator', floor: floorNum };
  group.add(hit);
  interactables.push(hit);
  parent.add(group);
  elevators.push({ floor: floorNum, side, group, hit, onSide: true });
}

function createHelicopter() {
  const g = new THREE.Group();
  const bodyMat = new THREE.MeshLambertMaterial({ color: 0x2a2a2a });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(1, 2.4, 4, 10), bodyMat);
  body.rotation.z = Math.PI/2;
  g.add(body);
  const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.28, 3.2, 8), bodyMat);
  tail.rotation.z = Math.PI/2;
  tail.position.set(-2.8, 0.25, 0);
  g.add(tail);
  const rotor = new THREE.Mesh(new THREE.BoxGeometry(7.5, 0.1, 0.4), new THREE.MeshLambertMaterial({ color: 0x111 }));
  rotor.position.y = 1.25;
  g.add(rotor);
  g.position.set(0, 1.5, 0);
  if (scene.userData.roofGroup) scene.userData.roofGroup.add(g);
  else scene.add(g);
  return g;
}

/* -------------------- PARTS (1 per floor) -------------------- */
function placePartsForFloor(f) {
  parts = parts.filter(p => p.userData && p.userData.floor === f);
  if (collectedParts.has(f)) return;
  const part = createPart(f);
  // Inside Suite A (red door, left) — deep in the room
  const halfL = CONFIG.corridorLength / 2;
  const roomD = CONFIG.roomDepth;
  part.position.set(-(halfL + roomD * 0.55), 0.55, 0);
  part.userData = { type: 'part', id: f, collected: false, floor: f };
  scene.add(part);
  parts.push(part);
  interactables.push(part);
}

function createPart(id) {
  const g = new THREE.Group();
  const mat = new THREE.MeshLambertMaterial({
    color: 0xd4a84b, emissive: 0x3a2a10, emissiveIntensity: 0.35
  });
  let mesh;
  if (id % 3 === 0) mesh = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.4, 0.55), mat);
  else if (id % 3 === 1) mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.65, 10), mat);
  else mesh = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.12, 8, 16), mat);
  g.add(mesh);
  // no point light (mobile perf)
  return g;
}

/* -------------------- MONSTERS -------------------- */




// Template pool — floor/room randomized each game
const MONSTER_POOL = [
  { name: 'Whisper Doll', type: 'whisper', speed: 0.9, desc: 'INTERACT to silence her whisper.', needs: null },
  { name: 'The Watcher', type: 'watcher', speed: 2.2, desc: 'Keep looking at him or he comes.', needs: null },
  { name: 'Gaze Beast', type: 'gaze', speed: 1.2, desc: 'Do not stare more than 2 seconds.', needs: null },
  { name: 'Hungry Zombie', type: 'hungry', speed: 1.35, desc: 'Find meat in the room and give it to him.', needs: 'meat' },
  { name: 'Backwatcher', type: 'backtext', speed: 1.8, desc: 'Never look behind near him.', needs: null },
  { name: 'Pale Woman', type: 'stalker', speed: 2.0, desc: 'She cuts you off. Keep moving.', needs: null },
  { name: 'Toy Doll', type: 'toy', speed: 1.4, desc: 'Put the toy in the box to calm her.', needs: 'toy' },
  { name: 'Blood Crier', type: 'crier', speed: 2.0, desc: 'Stand still and look at his face.', needs: null },
  { name: 'Shadow Step', type: 'shadowstep', speed: 2.8, desc: 'Stand still to freeze him.', needs: null }
];

let MONSTER_DEFS = []; // filled by randomizeMonsters()

function mulberry32(a) {
  return function() {
    let t = a += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function shuffleSeeded(arr, rand) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function randomizeMonsters(seed) {
  if (seed == null) seed = (Math.random() * 1e9) | 0;
  monsterSeed = seed;
  const rand = mulberry32(seed >>> 0);
  const pool = shuffleSeeded(MONSTER_POOL, rand);
  const floors = shuffleSeeded([1, 2, 3, 4, 5, 6, 7, 8, 9], rand);
  MONSTER_DEFS = pool.map((m, i) => {
    const floor = floors[i];
    const side = rand() < 0.5 ? -1 : 1;
    const halfL = CONFIG.corridorLength / 2;
    const roomD = CONFIG.roomDepth;
    const x = (side < 0 ? -1 : 1) * (halfL + roomD * 0.45);
    const z = (rand() - 0.5) * 3;
    return {
      name: m.name,
      type: m.type,
      speed: m.speed,
      desc: m.desc,
      needs: m.needs,
      floor,
      pos: [x, 0, z],
      room: side < 0 ? 'RED' : 'BLUE'
    };
  });
}

function placeMonstersForFloor(f) {
  MONSTER_DEFS.filter(d => d.floor === f).forEach(d => addMonster(d));
  placeFloorItems(f);
}

function placeFloorItems(f) {
  const def = MONSTER_DEFS.find(d => d.floor === f);
  if (!def) return;
  const x = def.pos[0];
  const z = def.pos[2];
  if (def.needs === 'meat' || def.type === 'hungry') {
    const meat = createItem(0x8b0000, 'meat');
    meat.position.set(x * 0.9, 0.45, z + 1.2);
    meat.userData = { type: 'item', item: 'meat' };
    scene.add(meat);
    interactables.push(meat);
  }
  if (def.needs === 'toy' || def.type === 'toy') {
    const toy = createItem(0xff69b4, 'toy');
    toy.position.set(x * 0.85, 0.45, z - 1.0);
    toy.userData = { type: 'item', item: 'toy' };
    scene.add(toy);
    interactables.push(toy);
    const box = new THREE.Mesh(
      new THREE.BoxGeometry(0.9, 0.55, 0.9),
      new THREE.MeshLambertMaterial({ color: 0x5a3a1a })
    );
    box.position.set(x * 0.9, 0.35, z + 1.5);
    box.userData = { type: 'box' };
    scene.add(box);
    interactables.push(box);
  }
}

function placeMonsters() {
  // legacy no-op
}

function addMonster(data) {
  const m = createMonsterMesh(data.color || 0x333, data.name, data.type);
  m.position.set(data.pos[0], 0, data.pos[2]);
  m.userData = {
    type: 'monster',
    kind: data.type,
    name: data.name,
    speed: data.speed,
    floor: data.floor,
    alive: true,
    lookTimer: 0,
    state: 'idle',
    desc: data.desc,
    stunned: false
  };
  scene.add(m);
  monsters.push(m);
  interactables.push(m);
}







function createMonsterMesh(color, name, kind) {
  let g;
  switch (kind) {
    case 'watcher': g = createWatcherMesh(); break;
    case 'gaze': g = createGazeBeastMesh(); break;
    case 'hungry': g = createHungryZombieMesh(); break;
    case 'backtext': g = createBackwatcherMesh(); break;
    case 'stalker': g = createPaleGirlMesh(); break;
    case 'toy': g = createToyGirlMesh(); break;
    case 'crier': g = createBloodCrierMesh(); break;
    case 'shadowstep': g = createShadowStepMesh(); break;
    case 'whisper': g = createWhisperDollMesh(); break;
    default: g = createWatcherMesh(); break;
  }
  g.scale.set(1.25, 1.25, 1.25);

  const canvas = document.createElement('canvas');
  canvas.width = 256; canvas.height = 48;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(0,0,0,0.85)';
  ctx.fillRect(0, 0, 256, 48);
  ctx.fillStyle = '#ff4444';
  ctx.font = 'bold 20px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText(name, 128, 32);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({
    map: new THREE.CanvasTexture(canvas), transparent: true, depthTest: false
  }));
  spr.scale.set(1.8, 0.35, 1);
  spr.position.y = 2.7;
  g.add(spr);
  return g;
}

function mat(c, e, ei) {
  return new THREE.MeshLambertMaterial({
    color: c,
    emissive: e || 0x000000,
    emissiveIntensity: ei || 0
  });
}

/* Tall gaunt man in dark coat — huge pale staring eyes */
function createWatcherMesh() {
  const g = new THREE.Group();
  const suit = mat(0x1a1210);
  const suitD = mat(0x0a0808);
  const skin = mat(0xc4b4a8);
  const skinD = mat(0x6a5850);
  const eyeW = mat(0xffffff, 0xaaaaaa, 0.5);
  const pupil = mat(0x050508, 0x111122, 0.2);
  const blood = mat(0x5a0000, 0x220000, 0.3);

  // long thin legs
  for (const x of [-0.12, 0.12]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.72, 3, 6), suitD);
    leg.position.set(x, 0.48, 0); g.add(leg);
    const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.08, 0.38), suitD);
    shoe.position.set(x, 0.05, -0.05); g.add(shoe);
  }
  // long coat
  const coat = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.42, 1.15, 8), suit);
  coat.position.y = 1.15; g.add(coat);
  const shoulders = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.22, 0.35), suit);
  shoulders.position.y = 1.72; g.add(shoulders);
  // arms hanging
  for (const x of [-0.38, 0.38]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.65, 3, 6), suit);
    arm.position.set(x, 1.15, 0.02); g.add(arm);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 5), skin);
    hand.position.set(x, 0.72, 0); g.add(hand);
  }
  // gaunt head
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 0.2, 6), skin);
  neck.position.y = 1.95; g.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.24, 10, 8), skin);
  head.scale.set(0.85, 1.25, 0.8);
  head.position.y = 2.22; g.add(head);
  // sunken cheeks
  for (const x of [-0.12, 0.12]) {
    const ch = new THREE.Mesh(new THREE.SphereGeometry(0.08, 6, 4), skinD);
    ch.scale.set(1, 0.5, 0.35);
    ch.position.set(x, 2.12, -0.16); g.add(ch);
  }
  // HUGE staring eyes
  for (const x of [-0.09, 0.09]) {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.085, 8, 6), eyeW);
    e.scale.z = 0.45;
    e.position.set(x, 2.28, -0.2); g.add(e);
    const p = new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 5), pupil);
    p.position.set(x, 2.28, -0.24); g.add(p);
  }
  // thin mouth + blood line
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.02, 0.03), skinD);
  mouth.position.set(0, 2.05, -0.22); g.add(mouth);
  const drip = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.12, 0.02), blood);
  drip.position.set(0.04, 1.98, -0.22); g.add(drip);
  return g;
}

/* Multi-eyed hunched beast */
function createGazeBeastMesh() {
  const g = new THREE.Group();
  const fur = mat(0x1c1512);
  const furD = mat(0x0c0a09);
  const muzzle = mat(0x5a4840);
  const eye = mat(0xff2200, 0xaa0000, 0.9);
  const claw = mat(0x3a3028);

  const hip = new THREE.Mesh(new THREE.SphereGeometry(0.38, 8, 6), furD);
  hip.scale.set(1.1, 0.9, 1); hip.position.set(0, 0.55, 0.15); g.add(hip);
  const torso = new THREE.Mesh(new THREE.SphereGeometry(0.4, 8, 6), fur);
  torso.scale.set(1.1, 1.15, 0.75); torso.rotation.x = -0.5;
  torso.position.set(0, 0.95, -0.05); g.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.32, 8, 6), fur);
  head.position.set(0, 1.55, -0.35); g.add(head);
  const snout = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.5, 7), muzzle);
  snout.rotation.x = Math.PI / 2; snout.position.set(0, 1.48, -0.65); g.add(snout);
  // many glowing eyes
  [[-0.16,1.62,-0.52],[0.16,1.62,-0.52],[-0.1,1.52,-0.58],[0.1,1.52,-0.58],
   [-0.2,1.48,-0.5],[0.2,1.48,-0.5],[-0.05,1.68,-0.48],[0.05,1.68,-0.48]].forEach(p => {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.04, 5, 4), eye);
    e.position.set(p[0], p[1], p[2]); g.add(e);
  });
  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.7, 3, 6), fur);
    arm.position.set(s * 0.45, 0.85, -0.15);
    arm.rotation.z = s * 0.35; g.add(arm);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.1, 5, 4), claw);
    hand.position.set(s * 0.55, 0.35, -0.25); g.add(hand);
  }
  for (const s of [-1, 1]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.11, 0.45, 3, 6), furD);
    leg.position.set(s * 0.25, 0.35, 0.15); g.add(leg);
  }
  return g;
}

/* Rotting hungry zombie — open chest, reaching arm */
function createHungryZombieMesh() {
  const g = new THREE.Group();
  const skin = mat(0x6a7a5a);
  const skinD = mat(0x3a4535);
  const shirt = mat(0x5a5a52);
  const pants = mat(0x222228);
  const blood = mat(0x6a1010, 0x330000, 0.4);
  const mouth = mat(0x100808);
  const teeth = mat(0xc8c0a0);

  for (const x of [-0.14, 0.14]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.55, 3, 6), pants);
    leg.position.set(x, 0.42, 0); g.add(leg);
  }
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 0.55, 4, 6), shirt);
  torso.scale.set(1, 1, 0.65); torso.position.y = 1.15; g.add(torso);
  const wound = new THREE.Mesh(new THREE.SphereGeometry(0.16, 7, 5), blood);
  wound.scale.set(1, 1.3, 0.35); wound.position.set(0, 1.2, -0.2); g.add(wound);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.24, 8, 6), skin);
  head.scale.set(0.9, 1.15, 0.85); head.position.y = 1.85; g.add(head);
  const jaw = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 5), mouth);
  jaw.scale.set(1.2, 1.5, 0.5); jaw.position.set(0, 1.72, -0.22); g.add(jaw);
  const t1 = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.03, 0.03), teeth);
  t1.position.set(0, 1.82, -0.26); g.add(t1);
  // reaching arm toward player
  const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.55, 3, 6), skin);
  arm.position.set(0.45, 1.15, -0.35);
  arm.rotation.z = -0.6; arm.rotation.x = -0.9; g.add(arm);
  const hand = new THREE.Mesh(new THREE.SphereGeometry(0.1, 6, 5), skin);
  hand.position.set(0.7, 0.85, -0.7); g.add(hand);
  for (let i = 0; i < 4; i++) {
    const f = new THREE.Mesh(new THREE.CapsuleGeometry(0.015, 0.14, 2, 4), skin);
    f.position.set(0.62 + i * 0.04, 0.82, -0.82);
    f.rotation.x = -0.7; g.add(f);
  }
  const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.5, 3, 6), shirt);
  armL.position.set(-0.35, 1.0, 0); g.add(armL);
  return g;
}

/* Dark figure that kills if you look back */
function createBackwatcherMesh() {
  const g = new THREE.Group();
  const body = mat(0x0e0c0c);
  const eye = mat(0xff0000, 0x880000, 1.0);
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.7, 3, 6), body);
  torso.scale.set(0.85, 1.1, 0.55); torso.position.y = 1.2; g.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 7, 6), body);
  head.scale.set(0.85, 1.1, 0.75); head.position.y = 1.95; g.add(head);
  for (const x of [-0.07, 0.07]) {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.03, 5, 4), eye);
    e.position.set(x, 1.98, -0.16); g.add(e);
  }
  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.7, 3, 5), body);
    arm.position.set(s * 0.32, 1.05, 0); g.add(arm);
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.6, 3, 5), body);
    leg.position.set(s * 0.12, 0.4, 0); g.add(leg);
  }
  return g;
}

/* Pale girl, hair over face, black suit */
function createPaleGirlMesh() {
  const g = new THREE.Group();
  const suit = mat(0x0a0a0c);
  const skin = mat(0xe8ddd4);
  const hair = mat(0x0c0a0a);
  const eye = mat(0x111111);

  const dress = new THREE.Mesh(new THREE.ConeGeometry(0.35, 1.1, 8), suit);
  dress.position.y = 0.75; g.add(dress);
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 0.22), suit);
  torso.position.y = 1.35; g.add(torso);
  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.045, 0.55, 3, 5), suit);
    arm.position.set(s * 0.28, 1.15, 0); g.add(arm);
  }
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.12, 6), skin);
  neck.position.y = 1.68; g.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 6), skin);
  head.position.y = 1.9; g.add(head);
  // hair covering face
  const hairCap = new THREE.Mesh(new THREE.SphereGeometry(0.22, 7, 5), hair);
  hairCap.scale.set(1.05, 0.9, 1.0); hairCap.position.set(0, 1.95, 0.02); g.add(hairCap);
  for (let i = 0; i < 5; i++) {
    const lock = new THREE.Mesh(new THREE.CapsuleGeometry(0.04, 0.35, 3, 4), hair);
    lock.position.set(-0.15 + i * 0.075, 1.75, -0.12);
    lock.rotation.x = 0.4; g.add(lock);
  }
  // one eye peeking
  const e = new THREE.Mesh(new THREE.SphereGeometry(0.035, 5, 4), eye);
  e.position.set(0.06, 1.9, -0.18); g.add(e);
  return g;
}

/* Cracked doll with teddy */
function createToyGirlMesh() {
  const g = new THREE.Group();
  const dress = mat(0x3a2828);
  const skin = mat(0xe0d8d0);
  const crack = mat(0x2a2020);
  const teddy = mat(0x6a4a38);
  const eye = mat(0x0a0a0a);

  const body = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.55, 8), dress);
  body.position.y = 0.55; g.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 6), skin);
  head.position.y = 1.05; g.add(head);
  for (const x of [-0.07, 0.07]) {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.035, 5, 4), eye);
    e.position.set(x, 1.08, -0.17); g.add(e);
  }
  // face cracks
  const c1 = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.14, 0.01), crack);
  c1.position.set(0.04, 1.12, -0.18); c1.rotation.z = 0.3; g.add(c1);
  const c2 = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.1, 0.01), crack);
  c2.position.set(-0.08, 1.0, -0.18); c2.rotation.z = -0.25; g.add(c2);
  // teddy
  const tb = new THREE.Mesh(new THREE.SphereGeometry(0.09, 6, 5), teddy);
  tb.position.set(0.28, 0.55, -0.1); g.add(tb);
  const th = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 5), teddy);
  th.position.set(0.28, 0.68, -0.12); g.add(th);
  for (const s of [-1, 1]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.25, 3, 4), skin);
    leg.position.set(s * 0.09, 0.2, 0); g.add(leg);
  }
  return g;
}

/* White bloody crier — screaming mouth, blood tears */
function createBloodCrierMesh() {
  const g = new THREE.Group();
  const skin = mat(0xd8d0c8);
  const shirt = mat(0xe8e4dc);
  const pants = mat(0x282828);
  const blood = mat(0x6a1010, 0x440000, 0.5);
  const mouth = mat(0x0a0505);
  const teeth = mat(0xc0b8a0);

  for (const x of [-0.13, 0.13]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.5, 3, 6), pants);
    leg.position.set(x, 0.4, 0); g.add(leg);
  }
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.75, 0.28), shirt);
  torso.position.y = 1.15; g.add(torso);
  const bloodF = new THREE.Mesh(new THREE.SphereGeometry(0.2, 7, 5), blood);
  bloodF.scale.set(1, 1.6, 0.3); bloodF.position.set(0, 1.15, -0.18); g.add(bloodF);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.25, 8, 6), skin);
  head.scale.set(0.9, 1.12, 0.85); head.position.y = 1.85; g.add(head);
  // huge scream mouth
  const m = new THREE.Mesh(new THREE.SphereGeometry(0.12, 7, 5), mouth);
  m.scale.set(1.3, 1.8, 0.45); m.position.set(0, 1.72, -0.22); g.add(m);
  const t1 = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.03, 0.03), teeth);
  t1.position.set(0, 1.82, -0.28); g.add(t1);
  // blood eyes + tears
  for (const x of [-0.09, 0.09]) {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.045, 5, 4), blood);
    e.position.set(x, 1.9, -0.2); g.add(e);
    const tear = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.025, 0.18, 5), blood);
    tear.position.set(x, 1.75, -0.22); g.add(tear);
  }
  // arms to face
  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.5, 3, 5), shirt);
    arm.position.set(s * 0.38, 1.35, -0.1);
    arm.rotation.z = -s * 0.7; g.add(arm);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.09, 5, 4), skin);
    hand.position.set(s * 0.55, 1.55, -0.15); g.add(hand);
  }
  return g;
}

/* Pure shadow tall figure, glowing red eyes */
function createShadowStepMesh() {
  const g = new THREE.Group();
  const sh = mat(0x020204, 0x050510, 0.15);
  const eye = mat(0xff0000, 0xff0000, 1.2);

  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.18, 0.85, 3, 6), sh);
  torso.scale.set(0.7, 1.15, 0.45); torso.position.y = 1.3; g.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 7, 5), sh);
  head.scale.set(0.75, 1.15, 0.65); head.position.y = 2.05; g.add(head);
  for (const x of [-0.06, 0.06]) {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.028, 5, 4), eye);
    e.position.set(x, 2.08, -0.14); g.add(e);
  }
  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.04, 0.9, 3, 5), sh);
    arm.position.set(s * 0.28, 1.0, 0); g.add(arm);
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.75, 3, 5), sh);
    leg.position.set(s * 0.1, 0.45, 0); g.add(leg);
  }
  return g;
}

/* Whisper doll — broken porcelain face */
function createWhisperDollMesh() {
  const g = new THREE.Group();
  const dress = mat(0x3a3530);
  const dressD = mat(0x1a1816);
  const skin = mat(0xd8d0c8);
  const crack = mat(0x1a1212);
  const mouth = mat(0x0a0808);

  const body = new THREE.Mesh(new THREE.ConeGeometry(0.26, 0.5, 7), dress);
  body.position.y = 0.5; g.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.19, 8, 6), skin);
  head.scale.set(0.95, 1.1, 0.85); head.position.y = 0.95; g.add(head);
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.2, 7, 5), dressD);
  hair.scale.set(1.05, 0.75, 0.9); hair.position.set(0, 1.05, 0.02); g.add(hair);
  for (const x of [-0.06, 0.06]) {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.03, 5, 4), crack);
    e.position.set(x, 0.97, -0.16); g.add(e);
  }
  const m = new THREE.Mesh(new THREE.TorusGeometry(0.04, 0.012, 4, 8), mouth);
  m.position.set(0, 0.88, -0.16); g.add(m);
  const c1 = new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.12, 0.008), crack);
  c1.position.set(-0.04, 1.05, -0.16); c1.rotation.z = -0.3; g.add(c1);
  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.04, 0.28, 3, 4), dress);
    arm.position.set(s * 0.22, 0.55, 0); g.add(arm);
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.045, 0.22, 3, 4), skin);
    leg.position.set(s * 0.08, 0.18, 0); g.add(leg);
  }
  return g;
}

/* -------------------- ITEMS for counters -------------------- */
function placeNPCs() {
  // Items spawn per-floor in placeFloorItems when that floor loads
}

function createItem(color, name) {
  const g = new THREE.Group();
  const m = new THREE.Mesh(
    new THREE.SphereGeometry(0.25, 10, 8),
    new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.3 })
  );
  g.add(m);
  // no point light
  return g;
}

/* -------------------- CONTROLS -------------------- */
function setupKeys() {
  const on = (e, p) => {
    switch (e.code) {
      case 'KeyW': case 'ArrowUp':    move.f = p; break;
      case 'KeyS': case 'ArrowDown':  move.b = p; break;
      case 'KeyA': case 'ArrowLeft':  move.l = p; break;
      case 'KeyD': case 'ArrowRight': move.r = p; break;
      case 'KeyE': case 'Space': if (p) tryInteract(); break;
      case 'KeyQ': case 'KeyF': if (p) tryStun(); break;
    }
  };
  addEventListener('keydown', e => on(e, true));
  addEventListener('keyup',   e => on(e, false));
}




function setupMobile() {
  const base = document.getElementById('joystick-base');
  const stick = document.getElementById('joystick-stick');
  const interactBtn = document.getElementById('interact-btn');
  const stunBtn = document.getElementById('stun-btn');

  let joyId = null;
  let lookId = null;
  let lastX = 0, lastY = 0;

  // Portrait-safe: joystick = bottom-left 32% width × 28% height of screen
  function inJoystick(clientX, clientY) {
    const w = window.innerWidth || 360;
    const h = window.innerHeight || 640;
    return clientX < w * 0.34 && clientY > h * 0.72;
  }

  function inButton(clientX, clientY) {
    const w = window.innerWidth || 360;
    const h = window.innerHeight || 640;
    // bottom-right buttons area
    return clientX > w * 0.62 && clientY > h * 0.72;
  }

  function lookSens() {
    // Same feel in portrait and landscape
    const short = Math.min(window.innerWidth || 360, window.innerHeight || 640);
    return 0.35 / short; // ~0.001 per px scaled → multiply below
  }

  document.addEventListener('touchstart', e => {
    for (const t of e.changedTouches) {
      if (inJoystick(t.clientX, t.clientY)) {
        joyId = t.identifier;
        e.preventDefault();
        continue;
      }
      if (inButton(t.clientX, t.clientY)) continue;
      lookId = t.identifier;
      lastX = t.clientX;
      lastY = t.clientY;
      e.preventDefault();
    }
  }, { passive: false, capture: true });

  document.addEventListener('touchmove', e => {
    let used = false;
    const sens = lookSens() * 18; // strong
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        used = true;
        const w = window.innerWidth || 360;
        const h = window.innerHeight || 640;
        const cx = w * 0.17;
        const cy = h * 0.86;
        const max = Math.min(w, h) * 0.12;
        let dx = t.clientX - cx, dy = t.clientY - cy;
        const len = Math.hypot(dx, dy) || 1;
        if (len > max) { dx = dx / len * max; dy = dy / len * max; }
        if (stick) stick.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
        joy.x = dx / max;
        joy.y = -dy / max;
      }
      if (t.identifier === lookId) {
        used = true;
        lookD.x += (t.clientX - lastX) * sens;
        lookD.y += (t.clientY - lastY) * sens;
        lastX = t.clientX;
        lastY = t.clientY;
      }
    }
    if (used) e.preventDefault();
  }, { passive: false, capture: true });

  const endTouch = e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        joyId = null;
        if (stick) stick.style.transform = 'translate(-50%, -50%)';
        joy.x = 0; joy.y = 0;
      }
      if (t.identifier === lookId) lookId = null;
    }
  };
  document.addEventListener('touchend', endTouch, { capture: true });
  document.addEventListener('touchcancel', endTouch, { capture: true });

  if (interactBtn) {
    const doI = (e) => { e.preventDefault(); e.stopPropagation(); tryInteract(); };
    interactBtn.addEventListener('touchend', doI, { passive: false });
    interactBtn.addEventListener('click', doI);
  }
  if (stunBtn) {
    const doS = (e) => { e.preventDefault(); e.stopPropagation(); tryStun(); };
    stunBtn.addEventListener('touchend', doS, { passive: false });
    stunBtn.addEventListener('click', doS);
  }

  // Portrait / landscape resize
  const onOrient = () => {
    if (!camera || !renderer) return;
    const w = window.innerWidth;
    const h = window.innerHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
    renderer.setPixelRatio(1);
  };
  window.addEventListener('orientationchange', () => setTimeout(onOrient, 150));
  window.addEventListener('resize', onOrient);
}

/* -------------------- INTERACTION + ELEVATOR -------------------- */

function tryInteract() {
  if (gameOver) return;
  const uiOpen = elevatorUI && !elevatorUI.classList.contains('hidden');
  if (elevatorOpen && uiOpen) return;

  const mover = camera.position;
  const origin = camera.getWorldPosition(new THREE.Vector3());
  const dir = camera.getWorldDirection(new THREE.Vector3());
  raycaster.set(origin, dir);
  raycaster.far = 4.5;

  const hits = raycaster.intersectObjects(interactables, true);
  let obj = null;
  if (hits.length) {
    obj = hits[0].object;
    while (obj && !(obj.userData && obj.userData.type)) obj = obj.parent;
  }

  // Prefer what you aim at; also nearest door within 3m
  if (!obj || obj.userData.type !== 'room-door') {
    let bestDoor = null, bestD = 3.2;
    for (const o of interactables) {
      if (!o.userData || o.userData.type !== 'room-door') continue;
      const wp = new THREE.Vector3();
      o.getWorldPosition(wp);
      const d = wp.distanceTo(mover);
      if (d < bestD) { bestD = d; bestDoor = o; }
    }
    // If aiming near a door or standing next to one, use door (NOT elevator)
    if (bestDoor && (!obj || obj.userData.type === 'elevator' || bestD < 2.5)) {
      obj = bestDoor;
    }
  }

  if (!obj) {
    // No door — then elevator by aim or proximity
    if (!obj) {
      const nearElev = interactables.find(o => {
        if (!o.userData || o.userData.type !== 'elevator') return false;
        const wp = new THREE.Vector3();
        o.getWorldPosition(wp);
        return wp.distanceTo(mover) < 3.5;
      });
      if (nearElev) obj = nearElev;
    }
  }

  if (!obj) {
    showMsg('Nothing to interact');
    return;
  }

  const d = obj.userData;

  if (d.type === 'room-door') {
    toggleRoomDoor(obj);
    return;
  }
  if (d.type === 'part' && !d.collected) {
    d.collected = true;
    collectedParts.add(d.id);
    partsCollected = collectedParts.size;
    if (partsEl) partsEl.textContent = `Parts: ${partsCollected} / ${TOTAL_PARTS}`;
    obj.visible = false;
    showMsg(`Part ${d.id} collected!`);
    if (partsCollected >= TOTAL_PARTS) {
      const ob = document.getElementById('objective');
      if (ob) ob.textContent = 'All parts found! Go to the roof and fix the helicopter.';
    }
    return;
  }
  if (d.type === 'floor-btn') {
    startElevatorRide(d.targetFloor);
    return;
  }
  if (d.type === 'elevator' || d.type === 'elevator-btn') {
    openElevatorUI();
    return;
  }
  if (d.type === 'item') {
    holdingItem = d.item;
    obj.visible = false;
    showMsg(`Picked up ${d.item}`);
    return;
  }
  if (d.type === 'box' && holdingItem === 'toy') {
    holdingItem = null;
    showMsg('Toy placed in the box. Toy Girl is calm and shows the part.');
    return;
  }
  if (d.type === 'monster') {
    handleMonsterInteract(obj);
  }
}

function toggleRoomDoor(obj) {
  let target = obj;
  if (obj.parent && obj.parent.userData && obj.parent.userData.type === 'room-door') {
    target = obj.parent;
  }
  const d = target.userData;
  if (d.endDoor) {
    // End doors slide sideways (along Z) to open
    if (d.closedZ === undefined) d.closedZ = target.position.z;
    if (!d.open) {
      d.open = true;
      if (obj.userData) obj.userData.open = true;
      target.position.z = d.closedZ + 2.7;
      showMsg((d.label || 'Door') + ' opened — walk into the room');
    } else {
      d.open = false;
      if (obj.userData) obj.userData.open = false;
      target.position.z = d.closedZ;
      showMsg((d.label || 'Door') + ' closed');
    }
    return;
  }
  if (d.closedX === undefined) d.closedX = target.position.x;
  if (!d.open) {
    d.open = true;
    if (obj.userData) obj.userData.open = true;
    target.position.x = d.closedX + 2.6;
    showMsg((d.label || 'Door') + ' opened — walk through');
  } else {
    d.open = false;
    if (obj.userData) obj.userData.open = false;
    target.position.x = d.closedX;
    showMsg((d.label || 'Door') + ' closed');
  }
}

function openElevatorUI() {
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (!ui) {
    showMsg('Elevator UI missing');
    return;
  }
  elevatorOpen = true;
  // Ensure buttons exist
  const box = document.getElementById('elevator-buttons');
  if (box && box.children.length === 0) {
    for (let i = 1; i <= 10; i++) {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = String(i);
      b.addEventListener('click', (e) => { e.preventDefault(); goToFloor(i); });
      b.addEventListener('touchend', (e) => { e.preventDefault(); goToFloor(i); }, { passive: false });
      box.appendChild(b);
    }
    const roofBtn = document.createElement('button');
    roofBtn.type = 'button';
    roofBtn.textContent = 'ROOF';
    roofBtn.addEventListener('click', (e) => { e.preventDefault(); goToFloor('roof'); });
    roofBtn.addEventListener('touchend', (e) => { e.preventDefault(); goToFloor('roof'); }, { passive: false });
    box.appendChild(roofBtn);
  }
  if (box) {
    [...box.querySelectorAll('button')].forEach(b => {
      b.classList.remove('current');
      if (String(currentFloor) === b.textContent || (currentFloor === 'Roof' && b.textContent === 'ROOF')) {
        b.classList.add('current');
      }
    });
  }
  const label = document.getElementById('elevator-current');
  if (label) label.textContent = currentFloor === 'Roof' ? 'Now: Roof' : `Now: Floor ${currentFloor}`;
  ui.classList.remove('hidden');
  showMsg('Choose a floor');
}

function startElevatorRide(target) {
  if (ridingElevator || gameOver) return;
  if (target !== 'roof' && Number(target) === Number(currentFloor)) {
    showMsg('Already here');
    return;
  }
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (ui) ui.classList.add('hidden');
  elevatorOpen = false;

  ridingElevator = true;
  rideTarget = target;
  ridePhase = 'loading';
  rideTimer = 2.0; // fixed 2 second floor load
  const label = target === 'roof' ? 'Roof' : ('Floor ' + target);
  showFloorLoading('Unloading floor… loading ' + label);
  showMsg('Traveling to ' + label + '…');
}

function goToFloor(f) {
  startElevatorRide(f);
}

function updateElevatorRide(dt) {
  if (!ridingElevator) return;
  rideTimer -= dt;
  if (rideTimer > 0) return;

  if (ridePhase === 'loading') {
    // Unload old floor, load new
    if (scene.userData.roofGroup) scene.userData.roofGroup.visible = false;
    unloadCurrentFloor();

    const mover = camera;
    if (rideTarget === 'roof') {
      if (scene.userData.roofGroup) scene.userData.roofGroup.visible = true;
      mover.position.set(0, CONFIG.playerHeight, 0);
      // place player on roof visually - roof group at height but we keep camera at 0 and show roof
      // simpler: roof at y=0 when loaded
      currentFloor = 'Roof';
      if (floorInd) floorInd.textContent = 'Roof';
      showMsg('Roof');
      if (partsCollected >= TOTAL_PARTS) {
        setTimeout(() => {
          if (winScreen) winScreen.classList.remove('hidden');
          gameOver = true;
        }, 600);
      } else {
        showMsg('Need all 10 parts for the helicopter');
      }
    } else {
      const floorNum = Number(rideTarget);
      loadFloor(floorNum);
      placePartsForFloor(floorNum);
      placeMonstersForFloor(floorNum);
      const side = mover.position.x >= 0 ? 1 : -1;
      const halfL = CONFIG.corridorLength / 2;
      mover.position.set(side * (halfL - 1.5), CONFIG.playerHeight, 0);
      showMsg('Floor ' + floorNum);
    }
    hideFloorLoading();
    ridingElevator = false;
    ridePhase = null;
  }
}

function handleMonsterInteract(m) {
  const k = m.userData.kind;
  if (k === 'hungry' && holdingItem === 'meat') {
    holdingItem = null;
    m.userData.alive = false;
    m.visible = false;
    showMsg('Fed the Hungry Zombie. He leaves peacefully.');
  } else if (k === 'whisper') {
    showMsg('Whisper silenced… for now.');
    m.userData.state = 'calm';
  } else {
    showMsg(m.userData.desc);
  }
}

/* -------------------- MONSTER AI -------------------- */
function updateMonsters(dt) {
  if (gameOver) return;
  const playerPos = (isMobile || !controls) ? camera.position : controls.getObject().position;
  // Monsters only "work" when player is in a room (away from corridor center)
  const halfL = CONFIG.corridorLength / 2;
  playerInRoom = Math.abs(playerPos.x) > halfL - 0.5;

  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor !== currentFloor && currentFloor !== 'Roof') return;
    // Idle in hallway — only hunt inside rooms
    if (!playerInRoom && currentFloor !== 'Roof') {
      // slowly face player but don't chase/kill
      m.lookAt(playerPos.x, m.position.y, playerPos.z);
      return;
    }

    // Stunned monsters do nothing
    if (m.userData.stunned) return;

    const kind = m.userData.kind;
    const toPlayer = new THREE.Vector3().subVectors(playerPos, m.position);
    const dist = toPlayer.length();
    toPlayer.y = 0;
    toPlayer.normalize();

    // Is player looking at monster?
    const lookDir = camera.getWorldDirection(new THREE.Vector3());
    const toM = new THREE.Vector3().subVectors(m.position, camera.position).normalize();
    const lookingAt = lookDir.dot(toM) > 0.85 && dist < 12;

    if (kind === 'watcher') {
      if (lookingAt) {
        // freeze
      } else if (dist > 1.5) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      } else kill('The Watcher caught you');
    }
    else if (kind === 'gaze') {
      if (lookingAt) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 2.0) kill('You stared too long at the Gaze Beast');
      } else {
        m.userData.lookTimer = Math.max(0, m.userData.lookTimer - dt * 0.5);
      }
    }
    else if (kind === 'hungry') {
      // NERFED: slow, only kills if very close, easy to feed
      if (holdingItem === 'meat') {
        // walks toward you slowly to take food
        if (dist > 2.2) m.position.addScaledVector(toPlayer, 0.7 * dt);
        else {
          // auto-feed when close with meat
          holdingItem = null;
          m.userData.alive = false;
          m.visible = false;
          showMsg('Hungry Zombie ate the meat and left. Easy.');
        }
      } else {
        if (dist > 2.4) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
        else if (dist < 1.1) kill('The Hungry Zombie reached you');
        // between 1.1 and 2.4: growls but does not kill (window to run / stun / get meat)
      }
    }
    else if (kind === 'backtext') {
      // if player is looking roughly away from monster while close
      const away = lookDir.dot(toM) < -0.3;
      if (away && dist < 8) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.2) kill('You looked at your back…');
      } else m.userData.lookTimer = 0;
      if (dist > 2) m.position.addScaledVector(toPlayer, m.userData.speed * 0.6 * dt);
    }
    else if (kind === 'stalker') {
      // moves toward where player is going
      const predict = playerPos.clone().add(lookDir.clone().multiplyScalar(3));
      const toPred = new THREE.Vector3().subVectors(predict, m.position);
      toPred.y = 0; toPred.normalize();
      if (dist > 1.6) m.position.addScaledVector(toPred, m.userData.speed * dt);
      else kill('The Pale Girl caught you');
    }
    else if (kind === 'toy') {
      if (holdingItem === 'toy') {
        // follows calmly
        if (dist > 2.5) m.position.addScaledVector(toPlayer, 1.5 * dt);
      } else if (dist < 2.0) {
        // aggressive until toy is placed
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      }
    }
    else if (kind === 'crier') {
      if (lookingAt && Math.abs(joy.x) + Math.abs(joy.y) < 0.1 && !move.f && !move.b && !move.l && !move.r) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.5) {
          m.userData.alive = false;
          m.visible = false;
          showMsg('Blood Crier calmed down and vanished.');
        }
      } else {
        m.userData.lookTimer = 0;
        if (dist > 1.7) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
        else kill('The Blood Crier reached you');
      }
    }
    else if (kind === 'shadowstep') {
      const moving = Math.abs(joy.x) + Math.abs(joy.y) > 0.1 || move.f || move.b || move.l || move.r;
      if (moving && dist > 1.5) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (!moving) { /* frozen */ }
      else kill('Shadow Step touched you');
    }
    else if (kind === 'whisper') {
      if (m.userData.state !== 'calm' && dist < 4) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 4) kill('The Whisper Doll’s voice took you');
      }
    }
  });
}

function kill(reason) {
  if (gameOver) return;
  if (gameMode === 'peaceful') {
    showMsg('Peaceful mode — you survive');
    return;
  }
  gameOver = true;
  showMsg(reason, 5000);
  setTimeout(() => location.reload(), 3500);
}

function killPlayer(msg) {
  if (gameMode === 'peaceful') {
    showMsg('Peaceful — survived');
    return;
  }
  showMsg(msg || 'You died…');
  gameOver = true;
}

function tryStun() {
  if (gameOver || stunCooldown > 0 || stunActive > 0) return;
  // Stun every monster on the current floor
  let hit = 0;
  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor === currentFloor || currentFloor === 'Roof') {
      m.userData.stunned = true;
      hit++;
    }
  });
  if (hit > 0) {
    stunActive = 3;
    stunCooldown = 15;
    showMsg(`Monster stunned for 3 seconds! (${hit})`);
  } else {
    showMsg('No monster on this floor');
    stunCooldown = 2; // small anti-spam
  }
  updateStunUI();
}

function updateStunUI() {
  const desk = document.getElementById('stun-btn-desktop');
  const setState = (btn, text, disabled) => {
    if (!btn) return;
    btn.disabled = disabled;
    btn.textContent = text;
  };
  if (stunCooldown > 0) {
    const t = Math.ceil(stunCooldown) + 's';
    setState(stunBtn, t, true);
    setState(desk, t, true);
    if (stunCdEl) stunCdEl.textContent = 'Cooldown';
  } else if (stunActive > 0) {
    setState(stunBtn, 'STUNNED', true);
    setState(desk, 'STUNNED', true);
  } else {
    setState(stunBtn, 'STUN', false);
    setState(desk, 'STUN (Q)', false);
    if (stunCdEl) stunCdEl.textContent = 'Ready';
  }
}

/* -------------------- ANIMATION -------------------- */
// Cap at ~45 FPS for stable mobile performance
const FPS_LIMIT = 40;
const FRAME_TIME = 1 / FPS_LIMIT;
let fpsAccum = 0;

function applyLook() {
  if (!camera) return;
  if (lookD.x === 0 && lookD.y === 0) return;
  camera.rotation.order = 'YXZ';
  camera.rotation.y -= lookD.x;
  camera.rotation.x -= lookD.y;
  camera.rotation.x = Math.max(-1.35, Math.min(1.35, camera.rotation.x));
  lookD.x = 0;
  lookD.y = 0;
}

function animate() {
  requestAnimationFrame(animate);
  const rawDt = clock.getDelta();

  // ALWAYS apply look every animation frame (even if we skip game update)
  applyLook();

  fpsAccum += rawDt;
  if (fpsAccum < FRAME_TIME) {
    if (renderer && scene && camera) renderer.render(scene, camera);
    return;
  }
  const dt = Math.min(fpsAccum, 0.05);
  fpsAccum = 0;

  if (gameOver) {
    renderer.render(scene, camera);
    return;
  }

  // Stun timers
  if (stunActive > 0) {
    stunActive -= dt;
    if (stunActive <= 0) {
      stunActive = 0;
      monsters.forEach(m => { m.userData.stunned = false; });
    }
  }
  if (stunCooldown > 0) {
    stunCooldown -= dt;
    if (stunCooldown < 0) stunCooldown = 0;
  }
  updateStunUI();

  const speed = ridingElevator ? 0 : CONFIG.playerSpeed * dt;
  const forward = new THREE.Vector3();
  const right = new THREE.Vector3();
  const mover = isMobile || !controls ? camera : controls.getObject();

  if (isMobile) {
    camera.getWorldDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    mover.position.addScaledVector(forward, joy.y * speed);
    mover.position.addScaledVector(right, joy.x * speed);
  } else if (controls && controls.isLocked) {
    controls.getDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    if (move.f) mover.position.addScaledVector(forward, speed);
    if (move.b) mover.position.addScaledVector(forward, -speed);
    if (move.l) mover.position.addScaledVector(right, -speed);
    if (move.r) mover.position.addScaledVector(right, speed);
  }

  // Bounds — allow walking into rooms
  const maxX = CONFIG.corridorLength/2 + CONFIG.roomDepth - 0.7;
  const maxZ = CONFIG.corridorWidth/2 - 0.5;
  mover.position.x = Math.max(-maxX, Math.min(maxX, mover.position.x));
  mover.position.z = Math.max(-maxZ, Math.min(maxZ, mover.position.z));

  // Streamed floors sit at y=0
  mover.position.y = CONFIG.playerHeight;

  updateElevatorRide(dt);

  // Hint when near elevator (no auto app panel)
  {
    const pos = camera.position;
    let inElev = false;
    if (currentFloor !== 'Roof') {
      for (const el of elevators) {
        if (el.floor !== currentFloor) continue;
        const wp = new THREE.Vector3();
        el.group.getWorldPosition(wp);
        // Standing at the wall elevator opening
        if (Math.abs(pos.x - wp.x) < 2.5 && Math.abs(pos.z - wp.z) < 2.2) {
          inElev = true;
          break;
        }
      }
      // Also detect by corridor ends
      const halfW = CONFIG.corridorWidth / 2;
      if (Math.abs(Math.abs(pos.z) - halfW) < 2.2 && Math.abs(pos.x) < 3.0) {
        inElev = true;
      }
    }
    insideElevator = inElev;
    if (inElev && !elevPromptShown && !gameOver && !ridingElevator) {
      elevPromptShown = true;
      showMsg('INTERACT to open floor menu', 2000);
    }
    if (!inElev) elevPromptShown = false;
  }

  // No door animation — elevators always open


  updateMonsters(dt);
  multiplayerTick(dt);

  // Part spin only every other frame feel — cheap
  parts.forEach(p => {
    if (!p.userData.collected) p.rotation.y += dt * 0.8;
  });

  renderer.render(scene, camera);
}

function setupUI() {
  // Elevator buttons – large, mobile-friendly
  const box = document.getElementById('elevator-buttons');
  if (box) box.innerHTML = '';
  for (let i = 1; i <= 10; i++) {
    const b = document.createElement('button');
    b.textContent = i;
    b.type = 'button';
    const go = (e) => { e.preventDefault(); goToFloor(i); };
    b.addEventListener('click', go);
    b.addEventListener('touchend', go, { passive: false });
    box.appendChild(b);
  }
  const roofBtn = document.createElement('button');
  roofBtn.textContent = 'ROOF';
  roofBtn.className = 'roof';
  roofBtn.type = 'button';
  const goRoof = (e) => { e.preventDefault(); goToFloor('roof'); };
  roofBtn.addEventListener('click', goRoof);
  roofBtn.addEventListener('touchend', goRoof, { passive: false });
  box.appendChild(roofBtn);

  document.getElementById('elevator-close').onclick = () => {
    elevatorUI.classList.add('hidden');
    elevatorOpen = false;
  };

  // FLOORS HUD button removed — use elevator in the hall

  document.getElementById('dialogue-close').onclick = () => dialogue.classList.add('hidden');
  document.getElementById('restart-btn').onclick = () => location.reload();

  if (stunBtn) {
    stunBtn.addEventListener('click', tryStun);
    stunBtn.addEventListener('touchstart', e => { e.preventDefault(); tryStun(); }, { passive: false });
  }
  const stunDesk = document.getElementById('stun-btn-desktop');
  if (stunDesk) {
    stunDesk.addEventListener('click', tryStun);
  }

  let p = 0;
  const iv = setInterval(() => {
    p += 15;
    progressEl.style.width = Math.min(p, 95) + '%';
    if (p >= 95) clearInterval(iv);
  }, 60);
}

init().catch(console.error);

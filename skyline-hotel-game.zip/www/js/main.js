/* Skyline Hotel - offline/APK safe (local three.min.js) */
(function () {
'use strict';
function showFatal(msg) {
  var d = document.createElement('div');
  d.style.cssText = 'position:fixed;inset:0;background:#0a0a15;color:#d4a84b;padding:28px;font-family:system-ui,sans-serif;z-index:99999;overflow:auto';
  d.innerHTML = '<h1 style="margin:0 0 12px">Skyline Hotel</h1><p style="line-height:1.5">' + msg + '</p>';
  document.body.appendChild(d);
}
if (typeof THREE === 'undefined') {
  showFatal('Graphics engine missing. Reinstall the APK (three.min.js not found).');
  return;
}
try {

const CONFIG = {
  playerHeight: 1.7,
  playerSpeed: 8,
  lobbyWidth: 4,
  lobbyDepth: 5,
  roomWidth: 3,
  roomDepth: 5,
  hallwayWidth: 2,
  hallwayDepth: 2.5,
  wallThickness: 0.35
};

let scene, camera, renderer;
let currentFloor = 1;
let partsCollected = 0;
const TOTAL_PARTS = 10;
let gameMode = 'normal';
let difficulty = 'medium';
let characterChoice = 'fat';
let move = { f: false, b: false, l: false, r: false };
let joy = { x: 0, y: 0 };
let lookD = { x: 0, y: 0 };
let monsters = [];
let interactables = [];
let parts = [];
let clock = new THREE.Clock();
let gameOver = false;
let score = 0;
let timeElapsed = 0;
let monstersKilled = 0;
let stunActive = 0;
let stunCooldown = 0;
let hasTotem = false;
let hasGum = 0;
let slowActive = 0;
let slowCooldown = 0;

const CHARACTERS = {
  fat: { 
    name: 'FAT', 
    cameraHeight: 1.7, 
    color: 0x5a4a3a, 
    desc: 'Heavy',
    speed: 8,
    ability: 'Free Totem + Respawn'
  },
  short: { 
    name: 'SHORT', 
    cameraHeight: 1.2, 
    color: 0x4a4a6a, 
    desc: 'Tiny',
    speed: 12,
    ability: '1.5x Speed'
  },
  skinny: { 
    name: 'SKINNY', 
    cameraHeight: 1.7, 
    color: 0x333333, 
    desc: 'Lean',
    speed: 8,
    ability: 'TIME SLOW (Tap F)'
  }
};

function createHUD() {
  const hud = document.getElementById('hud');
  if (!hud) return;

  hud.innerHTML = `
    <div id="hud-top-left" style="position:absolute;top:20px;left:20px;color:#ffd700;font-size:0.9rem;font-family:monospace;line-height:1.8;z-index:100;text-shadow:0 0 10px rgba(255,215,0,0.5)">
      <div id="floor-indicator" style="font-size:1.2rem;font-weight:bold">Floor 1</div>
      <div id="character-display" style="font-size:0.8rem;color:#4488ff;text-shadow:0 0 8px rgba(68,136,255,0.6)">Char: ${CHARACTERS[characterChoice].name}</div>
      <div id="parts" style="font-size:0.9rem;opacity:0.9;margin-top:5px">Parts: 0/10</div>
    </div>
    <div id="hud-top-right" style="position:absolute;top:20px;right:20px;color:#4488ff;font-size:0.9rem;font-family:monospace;line-height:1.8;text-align:right;z-index:100;text-shadow:0 0 10px rgba(68,136,255,0.5)">
      <div id="timer" style="font-size:1.2rem;font-weight:bold">0:00</div>
      <div id="score" style="font-size:0.9rem;opacity:0.9">Score: 0</div>
    </div>
    <div id="items-hud" style="position:absolute;bottom:20px;right:20px;color:#ff00ff;font-size:0.85rem;font-family:monospace;z-index:100;text-shadow:0 0 10px rgba(255,0,255,0.5)">
      <div id="gum" style="margin:3px 0">🎯 GUM: 0</div>
      <div id="totem" style="margin:3px 0;color:#ff8800">🔥 TOTEM: ✗</div>
      <div id="slow" style="margin:3px 0;color:#00ffff;display:none">⏱️ SLOW: READY</div>
    </div>
    <div id="crosshair" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);z-index:100">
      <svg width="35" height="35" style="filter:drop-shadow(0 0 8px rgba(68,136,255,0.6))">
        <circle cx="17.5" cy="17.5" r="6" fill="none" stroke="#4488ff" stroke-width="1.5" opacity="0.6"/>
        <line x1="17.5" y1="5" x2="17.5" y2="12" stroke="#4488ff" stroke-width="1.5" opacity="0.7"/>
        <line x1="17.5" y1="23" x2="17.5" y2="30" stroke="#4488ff" stroke-width="1.5" opacity="0.7"/>
        <line x1="5" y1="17.5" x2="12" y2="17.5" stroke="#4488ff" stroke-width="1.5" opacity="0.7"/>
        <line x1="23" y1="17.5" x2="30" y2="17.5" stroke="#4488ff" stroke-width="1.5" opacity="0.7"/>
      </svg>
    </div>
  `;
}

function updateHUD() {
  const timerEl = document.getElementById('timer');
  const scoreEl = document.getElementById('score');
  const partsEl = document.getElementById('parts');
  const gumEl = document.getElementById('gum');
  const totemEl = document.getElementById('totem');
  const slowEl = document.getElementById('slow');

  if (timerEl) {
    const mins = Math.floor(timeElapsed / 60);
    const secs = (timeElapsed % 60).toString().padStart(2, '0');
    timerEl.textContent = `${mins}:${secs}`;
  }
  if (scoreEl) scoreEl.textContent = `${score}`;
  if (partsEl) partsEl.textContent = `Parts: ${partsCollected}/10`;
  if (gumEl) gumEl.innerHTML = `🎯 GUM: ${hasGum}`;
  if (totemEl) {
    totemEl.innerHTML = hasTotem ? '🔥 TOTEM: ✓' : '🔥 TOTEM: ✗';
    totemEl.style.color = hasTotem ? '#00ff00' : '#ff8800';
  }
  if (slowEl && characterChoice === 'skinny') {
    slowEl.style.display = 'block';
    if (slowCooldown > 0) {
      slowEl.textContent = `⏱️ SLOW: ${slowCooldown.toFixed(1)}s`;
      slowEl.style.color = '#ff6600';
    } else if (slowActive > 0) {
      slowEl.textContent = `⏱️ SLOW: ${slowActive.toFixed(1)}s`;
      slowEl.style.color = '#00ffff';
    } else {
      slowEl.textContent = '⏱️ SLOW: TAP F';
      slowEl.style.color = '#00ff00';
    }
  }
}

function showMsg(text, time = 2500) {
  const msgEl = document.getElementById('msg');
  if (!msgEl) return;
  msgEl.textContent = text;
  msgEl.classList.remove('hidden');
  msgEl.style.opacity = '1';
  setTimeout(() => {
    msgEl.style.opacity = '0';
    setTimeout(() => msgEl.classList.add('hidden'), 300);
  }, time);
}

function setupStartMenu() {
  const menu = document.getElementById('start-menu');
  if (!menu) return;
  var boot = document.getElementById('boot');
  if (boot) boot.classList.add('hidden');
  menu.classList.remove('hidden');

  menu.innerHTML = `
    <div style="background:rgba(0,0,0,0.9);backdrop-filter:blur(10px);padding:40px;border-radius:12px;max-width:90vw;color:#ffd700;font-family:Arial,sans-serif;text-align:center;border:2px solid #4488ff;box-shadow:0 0 40px rgba(68,136,255,0.5)">
      <h1 style="font-size:2.5rem;margin:0 0 5px 0;color:#ffd700;text-shadow:0 0 20px rgba(255,215,0,0.8);font-weight:900">SKYLINE</h1>
      <h2 style="font-size:1.8rem;margin:0 0 15px 0;color:#4488ff;text-shadow:0 0 15px rgba(68,136,255,0.6)">HOTEL</h2>
      <p style="font-size:0.9rem;color:#aaa;margin:0 0 30px 0">Collect parts. Escape alive. 📱</p>
      
      <div style="background:rgba(100,100,150,0.3);padding:20px;border-radius:8px;margin-bottom:25px;border-left:3px solid #ffd700">
        <p style="margin:0 0 15px 0;font-size:0.85rem;color:#aaa;text-transform:uppercase;letter-spacing:2px">Character</p>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
          <button class="char-btn active" data-char="fat" style="padding:18px;background:linear-gradient(135deg, #5a4a3a, #8a6a4a);color:#ffd700;border:2px solid #ffd700;border-radius:6px;cursor:pointer;transition:all 0.2s;font-size:0.9rem;font-weight:bold">FAT<br><span style="font-size:0.75rem">Totem</span></button>
          <button class="char-btn" data-char="short" style="padding:18px;background:#4a4a6a;color:#fff;border:2px solid #666;border-radius:6px;cursor:pointer;transition:all 0.2s;font-size:0.9rem">SHORT<br><span style="font-size:0.75rem">1.5x</span></button>
          <button class="char-btn" data-char="skinny" style="padding:18px;background:#333333;color:#fff;border:2px solid #666;border-radius:6px;cursor:pointer;transition:all 0.2s;font-size:0.9rem">SKINNY<br><span style="font-size:0.75rem">Slow</span></button>
        </div>
      </div>
      
      <div style="background:rgba(100,100,150,0.3);padding:18px;border-radius:8px;margin-bottom:20px;border-left:3px solid #ffd700">
        <p style="margin:0 0 10px 0;font-size:0.8rem;color:#aaa;text-transform:uppercase">Mode</p>
        <button class="mode-btn active" data-mode="normal" style="margin-right:8px;padding:8px 16px;background:linear-gradient(135deg, #ffd700, #ffed4e);color:#000;border:none;border-radius:4px;cursor:pointer;font-weight:bold;font-size:0.85rem">Normal</button>
        <button class="mode-btn" data-mode="peaceful" style="padding:8px 16px;background:#666;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:0.85rem">Peaceful</button>
      </div>

      <div style="background:rgba(100,100,150,0.3);padding:18px;border-radius:8px;margin-bottom:28px;border-left:3px solid #4488ff">
        <p style="margin:0 0 10px 0;font-size:0.8rem;color:#aaa;text-transform:uppercase">Difficulty</p>
        <button class="diff-btn" data-diff="easy" style="margin-right:6px;padding:6px 12px;background:#666;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:0.8rem">Easy</button>
        <button class="diff-btn active" data-diff="medium" style="margin-right:6px;padding:6px 12px;background:linear-gradient(135deg, #ffd700, #ffed4e);color:#000;border:none;border-radius:4px;cursor:pointer;font-size:0.8rem;font-weight:bold">Med</button>
        <button class="diff-btn" data-diff="hard" style="padding:6px 12px;background:#666;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:0.8rem">Hard</button>
      </div>

      <button id="btn-play" style="width:100%;padding:14px;background:linear-gradient(135deg, #ffd700, #ffed4e);color:#000;border:none;border-radius:6px;font-size:1.1rem;font-weight:bold;cursor:pointer;box-shadow:0 6px 20px rgba(255,215,0,0.5);margin-bottom:18px">ENTER</button>

      <div style="font-size:0.75rem;color:#999;line-height:1.5">
        <p style="margin:0"><strong>Joystick:</strong> Move</p>
        <p style="margin:3px 0"><strong>Drag:</strong> Look</p>
        <p style="margin:3px 0"><strong>Q:</strong> Gum | <strong>F:</strong> Ability | <strong>E:</strong> Interact</p>
      </div>
    </div>
  `;

  const charBtns = menu.querySelectorAll('.char-btn');
  const modeBtns = menu.querySelectorAll('.mode-btn');
  const diffBtns = menu.querySelectorAll('.diff-btn');
  const playBtn = menu.querySelector('#btn-play');

  charBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      charBtns.forEach(b => {
        b.style.background = b.dataset.char === 'fat' ? 'linear-gradient(135deg, #5a4a3a, #8a6a4a)' : 
                            b.dataset.char === 'short' ? '#4a4a6a' : '#333333';
        b.style.borderColor = '#666';
        b.style.color = b.dataset.char === 'fat' ? '#ffd700' : '#fff';
      });
      btn.style.background = 'linear-gradient(135deg, #ffd700, #ffed4e)';
      btn.style.color = '#000';
      btn.style.borderColor = '#ffd700';
      btn.style.fontWeight = 'bold';
      characterChoice = btn.dataset.char;
    });
  });

  modeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      modeBtns.forEach(b => { b.style.background = '#666'; b.style.color = '#fff'; });
      btn.style.background = 'linear-gradient(135deg, #ffd700, #ffed4e)';
      btn.style.color = '#000';
      gameMode = btn.dataset.mode;
    });
  });

  diffBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      diffBtns.forEach(b => { b.style.background = '#666'; b.style.color = '#fff'; b.style.fontWeight = 'normal'; });
      btn.style.background = 'linear-gradient(135deg, #ffd700, #ffed4e)';
      btn.style.color = '#000';
      btn.style.fontWeight = 'bold';
      difficulty = btn.dataset.diff;
    });
  });

  playBtn.addEventListener('click', beginGame);
  playBtn.addEventListener('touchend', function(e){ e.preventDefault(); beginGame(); }, {passive:false});
}


function resizeGame() {
  if (!camera || !renderer) return;
  var w = window.innerWidth || document.documentElement.clientWidth || 360;
  var h = window.innerHeight || document.documentElement.clientHeight || 640;
  // visualViewport is more accurate on mobile rotate
  if (window.visualViewport) {
    w = Math.round(window.visualViewport.width) || w;
    h = Math.round(window.visualViewport.height) || h;
  }
  if (w < 1) w = 1;
  if (h < 1) h = 1;
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h, false);
  renderer.domElement.style.width = w + 'px';
  renderer.domElement.style.height = h + 'px';
}

window.addEventListener('resize', function () {
  setTimeout(resizeGame, 50);
  setTimeout(resizeGame, 250);
});
window.addEventListener('orientationchange', function () {
  setTimeout(resizeGame, 100);
  setTimeout(resizeGame, 400);
  setTimeout(resizeGame, 800);
});
if (window.visualViewport) {
  window.visualViewport.addEventListener('resize', function () {
    setTimeout(resizeGame, 50);
  });
}

function beginGame() {
  // apk entry
  var boot = document.getElementById('boot');
  if (boot) boot.classList.add('hidden');
  var sm = document.getElementById('start-menu');
  if (sm) sm.classList.add('hidden');

  const menu = document.getElementById('start-menu');
  const hud = document.getElementById('hud');

  if (menu) menu.classList.add('hidden');
  if (hud) hud.classList.remove('hidden');

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0xb8c0d0); // bright lobby sky-ish gray-blue
  scene.fog = null; // fog made half the view look black

  camera = new THREE.PerspectiveCamera(75, innerWidth / innerHeight, 0.1, 200);
  const charCfg = CHARACTERS[characterChoice];
  camera.position.set(0, charCfg.cameraHeight, 4);
  CONFIG.playerHeight = charCfg.cameraHeight;
  CONFIG.playerSpeed = charCfg.speed;

  if (characterChoice === 'fat') {
    hasTotem = true;
  }

  renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', alpha: false });
  renderer.setPixelRatio(1);
  renderer.shadowMap.enabled = false;
  if (renderer.outputColorSpace !== undefined) renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.domElement.style.cssText = 'position:fixed;left:0;top:0;width:100%;height:100%;z-index:1;display:block;';
  document.body.appendChild(renderer.domElement);
  resizeGame();

  // Bright lighting (hotel hallway, not pitch black)
  scene.add(new THREE.AmbientLight(0xffffff, 1.35));
  scene.add(new THREE.HemisphereLight(0xffffff, 0x8899aa, 0.85));
  const mainLight = new THREE.DirectionalLight(0xffffff, 0.9);
  mainLight.position.set(2, 10, 4);
  scene.add(mainLight);
  const fill = new THREE.PointLight(0xfff5e6, 1.2, 40);
  fill.position.set(0, 3, 2);
  scene.add(fill);

  createHUD();
  setupMobileControls();
  loadFloor(1);

  animate();
}

function setupMobileControls() {
  const joyBase = document.getElementById('joystick-base');
  const joyStick = document.getElementById('joystick-stick');

  let joyTouchId = null;
  let joyBaseX = 0, joyBaseY = 0;
  let lastLookX = 0, lastLookY = 0;
  let lookTouchId = null;

  document.addEventListener('touchstart', (e) => {
    if (gameOver) return;
    for (const t of e.changedTouches) {
      const w = window.innerWidth;
      const h = window.innerHeight;

      if (t.clientX < w * 0.35 && t.clientY > h * 0.55) {
        joyTouchId = t.identifier;
        joyBaseX = t.clientX;
        joyBaseY = t.clientY;
        if (joyBase) {
          joyBase.style.left = (t.clientX - 40) + 'px';
          joyBase.style.top = (t.clientY - 40) + 'px';
          joyBase.style.opacity = '0.8';
        }
        e.preventDefault();
      } else {
        lookTouchId = t.identifier;
        lastLookX = t.clientX;
        lastLookY = t.clientY;
        e.preventDefault();
      }
    }
  }, { passive: false });

  document.addEventListener('touchmove', (e) => {
    if (gameOver) return;
    const sens = 0.0015;
    for (const t of e.changedTouches) {
      if (t.identifier === joyTouchId) {
        const dx = t.clientX - joyBaseX;
        const dy = t.clientY - joyBaseY;
        const max = 55;
        const len = Math.hypot(dx, dy);

        if (len > 0) {
          const ratio = Math.min(1, len / max);
          joy.x = (dx / len) * ratio;
          joy.y = -(dy / len) * ratio;

          if (joyStick && len > 2) {
            const clampedDx = len > max ? (dx / len) * max : dx;
            const clampedDy = len > max ? (dy / len) * max : dy;
            joyStick.style.transform = `translate(calc(-50% + ${clampedDx}px), calc(-50% + ${clampedDy}px))`;
          }
        }
        e.preventDefault();
      } else if (t.identifier === lookTouchId) {
        lookD.x += (t.clientX - lastLookX) * sens;
        lookD.y += (t.clientY - lastLookY) * sens;
        lastLookX = t.clientX;
        lastLookY = t.clientY;
        e.preventDefault();
      }
    }
  }, { passive: false });

  const endTouch = (e) => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyTouchId) {
        joyTouchId = null;
        joy.x = 0;
        joy.y = 0;
        if (joyBase) joyBase.style.opacity = '0';
        if (joyStick) joyStick.style.transform = 'translate(-50%, -50%)';
      }
      if (t.identifier === lookTouchId) lookTouchId = null;
    }
  };

  document.addEventListener('touchend', endTouch, { passive: false });
  document.addEventListener('touchcancel', endTouch, { passive: false });

  // BUTTON CONTROLS
  const eBtn = document.getElementById('btn-e');
  const qBtn = document.getElementById('btn-q');
  const fBtn = document.getElementById('btn-f');

  if (eBtn) eBtn.addEventListener('click', tryInteract);
  if (qBtn) qBtn.addEventListener('click', tryUseGum);
  if (fBtn) fBtn.addEventListener('click', tryAbility);
}

function createWall(x, y, z, w, h, d, color) {
  const wall = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, d),
    new THREE.MeshLambertMaterial({ color, flatShading: true })
  );
  wall.castShadow = true;
  wall.receiveShadow = true;
  wall.position.set(x, y, z);
  scene.add(wall);
  return wall;
}

function loadFloor(floor) {
  while (scene.children.length > 6) {
    scene.remove(scene.children[6]);
  }
  monsters = [];
  interactables = [];
  parts = [];

  currentFloor = floor;

  const floorEl = document.getElementById('floor-indicator');
  if (floorEl) floorEl.textContent = `Floor ${floor}`;

  const floorMat = new THREE.MeshLambertMaterial({ color: 0x6a6a78 });
  const floorTile = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.lobbyWidth + 2, 0.2, CONFIG.lobbyDepth + 2),
    floorMat
  );
  floorTile.receiveShadow = true;
  floorTile.position.y = 0;
  scene.add(floorTile);

  const ceil = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.lobbyWidth + 2, 0.2, CONFIG.lobbyDepth + 2),
    new THREE.MeshLambertMaterial({ color: 0x8a8a98 })
  );
  ceil.position.y = 3.5;
  scene.add(ceil);

  createWall(-CONFIG.lobbyWidth / 2, 1.75, 0, CONFIG.wallThickness, 3.5, CONFIG.lobbyDepth, 0x2a3a4a);
  createWall(CONFIG.lobbyWidth / 2, 1.75, 0, CONFIG.wallThickness, 3.5, CONFIG.lobbyDepth, 0x2a3a4a);
  createWall(0, 1.75, CONFIG.lobbyDepth / 2, CONFIG.lobbyWidth, 3.5, CONFIG.wallThickness, 0x2a3a4a);

  const backWall = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.lobbyWidth, 3.5, CONFIG.wallThickness),
    new THREE.MeshLambertMaterial({ color: 0x7a8a9a })
  );
  backWall.castShadow = true;
  backWall.position.set(0, 1.75, -CONFIG.lobbyDepth / 2 - 0.2);
  scene.add(backWall);

  const redDoor = new THREE.Mesh(
    new THREE.BoxGeometry(0.9, 2.2, 0.12),
    new THREE.MeshLambertMaterial({ color: 0xaa1111 })
  );
  redDoor.castShadow = true;
  redDoor.position.set(-1, 1.1, CONFIG.lobbyDepth / 2 + 0.1);
  redDoor.userData = { type: 'door', side: 'red', floor };
  scene.add(redDoor);
  interactables.push(redDoor);

  const redGlow = new THREE.PointLight(0xff1111, 1, 18);
  redGlow.position.copy(redDoor.position);
  redGlow.position.z += 1;
  scene.add(redGlow);

  const blueDoor = new THREE.Mesh(
    new THREE.BoxGeometry(0.9, 2.2, 0.12),
    new THREE.MeshLambertMaterial({ color: 0x1111aa })
  );
  blueDoor.castShadow = true;
  blueDoor.position.set(1, 1.1, CONFIG.lobbyDepth / 2 + 0.1);
  blueDoor.userData = { type: 'door', side: 'blue', floor };
  scene.add(blueDoor);
  interactables.push(blueDoor);

  const blueGlow = new THREE.PointLight(0x1111ff, 1, 18);
  blueGlow.position.copy(blueDoor.position);
  blueGlow.position.z += 1;
  scene.add(blueGlow);

  const elevFloor = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.hallwayWidth, 0.2, CONFIG.hallwayDepth),
    new THREE.MeshLambertMaterial({ color: 0x6a6a78 })
  );
  elevFloor.receiveShadow = true;
  elevFloor.position.z = -(CONFIG.lobbyDepth / 2 + CONFIG.hallwayDepth / 2);
  scene.add(elevFloor);

  createWall(-CONFIG.hallwayWidth / 2 - 0.2, 1.75, -(CONFIG.lobbyDepth / 2 + CONFIG.hallwayDepth / 2), CONFIG.wallThickness, 3.5, CONFIG.hallwayDepth, 0x2a3a4a);
  createWall(CONFIG.hallwayWidth / 2 + 0.2, 1.75, -(CONFIG.lobbyDepth / 2 + CONFIG.hallwayDepth / 2), CONFIG.wallThickness, 3.5, CONFIG.hallwayDepth, 0x2a3a4a);

  const elevDoor = new THREE.Mesh(
    new THREE.BoxGeometry(1.1, 2.3, 0.15),
    new THREE.MeshLambertMaterial({ color: 0x6a6a7a })
  );
  elevDoor.castShadow = true;
  elevDoor.position.set(0, 1.15, -(CONFIG.lobbyDepth / 2 + CONFIG.hallwayDepth - 0.2));
  elevDoor.userData = { type: 'elevator-door', floor };
  scene.add(elevDoor);
  interactables.push(elevDoor);

  const elevGlow = new THREE.PointLight(0xffcc00, 0.8, 18);
  elevGlow.position.copy(elevDoor.position);
  elevGlow.position.y += 0.5;
  scene.add(elevGlow);

  if (Math.random() < 0.55) {
    const gum = new THREE.Mesh(
      new THREE.SphereGeometry(0.3, 12, 12),
      new THREE.MeshLambertMaterial({ color: 0xff00ff, emissive: 0xff00ff, emissiveIntensity: 0.6 })
    );
    gum.castShadow = true;
    gum.position.set(-1.5, 0.35, 1.5);
    gum.userData = { type: 'gum' };
    scene.add(gum);
    interactables.push(gum);

    const gumLight = new THREE.PointLight(0xff00ff, 0.4, 10);
    gumLight.position.copy(gum.position);
    scene.add(gumLight);
  }

  if (!hasTotem && characterChoice !== 'fat' && Math.random() < 0.4) {
    const totem = createTotem();
    totem.position.set(1.5, 0.4, 1.5);
    totem.userData = { type: 'totem' };
    scene.add(totem);
    interactables.push(totem);
  }

  spawnMonster(floor);
  camera.position.set(0, CONFIG.playerHeight, 4);
  camera.rotation.set(0, 0, 0);

  showMsg(`🏨 Floor ${floor}`);
}

function createTotem() {
  const g = new THREE.Group();

  const pole = new THREE.Mesh(
    new THREE.CylinderGeometry(0.1, 0.15, 0.5, 6),
    new THREE.MeshLambertMaterial({ color: 0x6a5a4a })
  );
  pole.castShadow = true;
  pole.position.y = 0.25;
  g.add(pole);

  const fire = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.15),
    new THREE.MeshLambertMaterial({ color: 0xff6600, emissive: 0xff5500, emissiveIntensity: 0.9 })
  );
  fire.castShadow = true;
  fire.position.y = 0.55;
  g.add(fire);

  const glow = new THREE.PointLight(0xff5500, 0.8, 14);
  glow.position.y = 0.6;
  g.add(glow);

  return g;
}

function spawnMonster(floor, x = 0, z = 0, count = 1) {
  const kinds = ['watcher', 'gaze', 'zombie', 'hunter', 'stalker'];
  for (let i = 0; i < count; i++) {
    const kind = kinds[floor % kinds.length];
    const offset = Math.random() * 0.5;
    const angle = (i / count) * Math.PI * 2;
    const mesh = createMonster(kind, floor);
    mesh.position.set(x + Math.cos(angle) * offset, 0.1, z + Math.sin(angle) * offset);
    mesh.castShadow = true;

    const speedMult = difficulty === 'hard' ? 1.5 : difficulty === 'easy' ? 0.6 : 1;
    mesh.userData = {
      type: 'monster',
      kind,
      alive: true,
      speed: (1.2 + (floor * 0.25)) * speedMult,
      floor,
      lookTimer: 0,
      slowMult: 1
    };

    scene.add(mesh);
    monsters.push(mesh);
  }
}

function createMonster(kind, floor) {
  const g = new THREE.Group();

  if (kind === 'watcher') {
    const body = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.2, 1.7, 4, 6),
      new THREE.MeshLambertMaterial({ color: 0x0a0a0a, flatShading: true })
    );
    body.castShadow = true;
    body.position.y = 0.85;
    g.add(body);

    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.28, 12, 12),
      new THREE.MeshLambertMaterial({ color: 0x1a1a1a, flatShading: true })
    );
    head.castShadow = true;
    head.position.y = 1.75;
    g.add(head);

    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 8), new THREE.MeshLambertMaterial({ color: 0xffffff }));
    eyeL.position.set(-0.15, 1.82, 0.22);
    g.add(eyeL);

    const eyeR = eyeL.clone();
    eyeR.position.x = 0.15;
    g.add(eyeR);

    const pupilL = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), new THREE.MeshLambertMaterial({ color: 0xff0000, emissive: 0xff0000, emissiveIntensity: 0.8 }));
    pupilL.position.set(-0.15, 1.82, 0.30);
    g.add(pupilL);

    const pupilR = pupilL.clone();
    pupilR.position.x = 0.15;
    g.add(pupilR);

    for (let s of [-1, 1]) {
      const arm = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.08, 1, 4, 4),
        new THREE.MeshLambertMaterial({ color: 0x050505 })
      );
      arm.castShadow = true;
      arm.position.set(s * 0.32, 1.2, 0);
      g.add(arm);
    }

    const glow = new THREE.PointLight(0xff2222, 0.4, 16);
    glow.position.y = 1.7;
    g.add(glow);

  } else if (kind === 'gaze') {
    const spine = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.24, 1.5, 4, 6),
      new THREE.MeshLambertMaterial({ color: 0x000000, flatShading: true })
    );
    spine.castShadow = true;
    spine.position.y = 0.75;
    spine.rotation.z = 0.4;
    g.add(spine);

    const head = new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.36, 3),
      new THREE.MeshLambertMaterial({ color: 0x050505, flatShading: true })
    );
    head.castShadow = true;
    head.position.set(0, 1.6, -0.35);
    g.add(head);

    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2;
      const eye = new THREE.Mesh(
        new THREE.SphereGeometry(0.12, 8, 8),
        new THREE.MeshLambertMaterial({ color: 0xff9900, emissive: 0xff9900, emissiveIntensity: 0.95 })
      );
      const r = 0.3;
      eye.position.set(Math.cos(angle) * r, 1.6 + Math.sin(angle) * 0.15, -0.3);
      g.add(eye);
    }

    const glow = new THREE.PointLight(0xff9900, 0.6, 18);
    glow.position.set(0, 1.6, -0.3);
    g.add(glow);

  } else if (kind === 'zombie') {
    const body = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.26, 1.3, 4, 6),
      new THREE.MeshLambertMaterial({ color: 0x4a6a4a, flatShading: true })
    );
    body.castShadow = true;
    body.position.y = 0.8;
    g.add(body);

    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.26, 10, 10),
      new THREE.MeshLambertMaterial({ color: 0x5a7a5a, flatShading: true })
    );
    head.castShadow = true;
    head.position.y = 1.7;
    g.add(head);

    const jaw = new THREE.Mesh(
      new THREE.BoxGeometry(0.38, 0.1, 0.16),
      new THREE.MeshLambertMaterial({ color: 0x2a4a2a })
    );
    jaw.position.set(0, 1.52, 0.26);
    g.add(jaw);

    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), new THREE.MeshLambertMaterial({ color: 0x777777 }));
    eyeL.position.set(-0.11, 1.75, 0.27);
    g.add(eyeL);

    const eyeR = eyeL.clone();
    eyeR.position.x = 0.11;
    g.add(eyeR);

  } else if (kind === 'hunter') {
    const body = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.22, 1.6, 4, 6),
      new THREE.MeshLambertMaterial({ color: 0x050505, flatShading: true })
    );
    body.castShadow = true;
    body.position.y = 0.8;
    body.rotation.z = 0.18;
    g.add(body);

    const head = new THREE.Mesh(
      new THREE.ConeGeometry(0.22, 0.48, 14),
      new THREE.MeshLambertMaterial({ color: 0x000000, flatShading: true })
    );
    head.castShadow = true;
    head.position.y = 1.75;
    g.add(head);

    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), new THREE.MeshLambertMaterial({ color: 0xff0000, emissive: 0xff0000, emissiveIntensity: 0.95 }));
    eyeL.position.set(-0.1, 1.65, 0.24);
    g.add(eyeL);

    const eyeR = eyeL.clone();
    eyeR.position.x = 0.1;
    g.add(eyeR);

    for (let i = 0; i < 4; i++) {
      const spike = new THREE.Mesh(
        new THREE.ConeGeometry(0.07, 0.42, 6),
        new THREE.MeshLambertMaterial({ color: 0x1a1a1a, flatShading: true })
      );
      spike.castShadow = true;
      spike.position.set(0, 1.1 - i * 0.32, -0.26);
      spike.rotation.z = Math.PI / 2 + 0.1;
      g.add(spike);
    }

    const glow = new THREE.PointLight(0xff2222, 0.5, 16);
    glow.position.y = 1.6;
    g.add(glow);

  } else if (kind === 'stalker') {
    const body = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.22, 1.4, 4, 6),
      new THREE.MeshLambertMaterial({ color: 0x5a5a8a, flatShading: true })
    );
    body.castShadow = true;
    body.position.y = 0.8;
    g.add(body);

    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.26, 10, 10),
      new THREE.MeshLambertMaterial({ color: 0x6a6a9a, flatShading: true })
    );
    head.castShadow = true;
    head.position.y = 1.7;
    g.add(head);

    const hair = new THREE.Mesh(
      new THREE.ConeGeometry(0.38, 0.85, 12),
      new THREE.MeshLambertMaterial({ color: 0x000000, flatShading: true })
    );
    hair.castShadow = true;
    hair.position.y = 1.25;
    g.add(hair);

    const eye = new THREE.Mesh(
      new THREE.SphereGeometry(0.1, 8, 8),
      new THREE.MeshLambertMaterial({ color: 0xff00ff, emissive: 0xff00ff, emissiveIntensity: 0.95 })
    );
    eye.position.set(0.15, 1.72, 0.27);
    g.add(eye);

    const glow = new THREE.PointLight(0xff00ff, 0.5, 16);
    glow.position.set(0.15, 1.7, 0.27);
    g.add(glow);
  }

  return g;
}

function tryUseGum() {
  if (hasGum <= 0 || gameOver) return;

  const origin = camera.getWorldPosition(new THREE.Vector3());
  const dir = camera.getWorldDirection(new THREE.Vector3());
  const raycaster = new THREE.Raycaster();
  raycaster.set(origin, dir);
  raycaster.far = 20;

  const hits = raycaster.intersectObjects(scene.children, true);
  for (const hit of hits) {
    const monster = hit.object.userData?.type === 'monster' ? hit.object :
      hit.object.parent?.userData?.type === 'monster' ? hit.object.parent : null;
    if (monster && monster.userData.alive) {
      monster.userData.alive = false;
      monster.visible = false;
      monstersKilled++;
      score += 300;
      hasGum--;
      showMsg('💥 INSTA-KILL +300');
      updateHUD();
      return;
    }
  }

  showMsg('No target');
}

function tryAbility() {
  if (gameOver) return;

  if (characterChoice === 'skinny') {
    if (slowCooldown > 0) return;
    slowCooldown = 18;
    slowActive = 3;
    monsters.forEach(m => { if (m.userData.alive) m.userData.slowMult = 0.4; });
    showMsg('⏱️ TIME SLOW +200');
    score += 200;
  }
  updateHUD();
}

function tryInteract() {
  if (gameOver) return;

  const origin = camera.getWorldPosition(new THREE.Vector3());
  const dir = camera.getWorldDirection(new THREE.Vector3());
  const raycaster = new THREE.Raycaster();
  raycaster.set(origin, dir);
  raycaster.far = 4.5;

  const hits = raycaster.intersectObjects(scene.children, true);
  for (const hit of hits) {
    const obj = hit.object;
    if (!obj.userData) continue;

    if (obj.userData.type === 'door') {
      createRoom(obj.userData.side);
      camera.position.set(obj.userData.side === 'red' ? -1.8 : 1.8, CONFIG.playerHeight, 1.5);
      showMsg('Find the part');
      return;
    }

    if (obj.userData.type === 'elevator-door') {
      showElevatorMenu();
      return;
    }

    if (obj.userData.type === 'part' && !obj.userData.collected) {
      obj.userData.collected = true;
      partsCollected++;
      obj.visible = false;
      score += 150;
      showMsg(`📦 Part ${partsCollected}/10 +150`);
      if (partsCollected === TOTAL_PARTS) winGame();
      updateHUD();
      return;
    }

    if (obj.userData.type === 'gum') {
      hasGum++;
      obj.visible = false;
      score += 75;
      showMsg('💜 Gum +75');
      updateHUD();
      return;
    }

    if (obj.userData.type === 'totem') {
      hasTotem = true;
      obj.visible = false;
      score += 250;
      showMsg('🔥 Totem! +250');
      updateHUD();
      return;
    }
  }
}

function createRoom(side) {
  const x = side === 'red' ? -1.9 : 1.9;

  const floorMat = new THREE.MeshLambertMaterial({ color: side === 'red' ? 0x2a1a1a : 0x1a1a2a });
  const floor = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.roomWidth, 0.2, CONFIG.roomDepth),
    floorMat
  );
  floor.receiveShadow = true;
  floor.position.set(x, 0, CONFIG.lobbyDepth / 2 + 0.6);
  scene.add(floor);

  const backWall = new THREE.Mesh(
    new THREE.BoxGeometry(CONFIG.roomWidth, 3.5, CONFIG.wallThickness),
    new THREE.MeshLambertMaterial({ color: 0x3a3a4a })
  );
  backWall.castShadow = true;
  backWall.position.set(x, 1.75, CONFIG.lobbyDepth / 2 + 0.6 + CONFIG.roomDepth / 2);
  scene.add(backWall);

  for (let wallSide of [-1, 1]) {
    const sideWall = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.wallThickness, 3.5, CONFIG.roomDepth),
      new THREE.MeshLambertMaterial({ color: 0x3a3a4a })
    );
    sideWall.castShadow = true;
    sideWall.position.set(x + wallSide * (CONFIG.roomWidth / 2), 1.75, CONFIG.lobbyDepth / 2 + 0.6);
    scene.add(sideWall);
  }

  const furnitureList = [
    { name: 'bed', w: 2, h: 0.6, d: 1.3, x: x - 0.2, z: CONFIG.lobbyDepth / 2 - 0.7, color: 0x4a4a5a },
    { name: 'desk', w: 1.3, h: 0.85, d: 0.6, x: x + 0.7, z: CONFIG.lobbyDepth / 2 + 1.4, color: 0x5a4a3a },
    { name: 'couch', w: 1.7, h: 0.7, d: 0.75, x: x - 0.2, z: CONFIG.lobbyDepth / 2 + 0.5, color: 0x4a5a4a }
  ];

  furnitureList.forEach((f) => {
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(f.w, f.h, f.d),
      new THREE.MeshLambertMaterial({ color: f.color, flatShading: true })
    );
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.position.set(f.x, f.h / 2, f.z);
    scene.add(mesh);

    const part = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.2),
      new THREE.MeshLambertMaterial({ color: 0xffdd00, emissive: 0xaa7700, emissiveIntensity: 0.8 })
    );
    part.castShadow = true;
    part.position.set(f.x, f.h + 0.35, f.z);
    part.userData = { type: 'part', collected: false };
    scene.add(part);
    interactables.push(part);
    parts.push(part);

    const partGlow = new THREE.PointLight(0xffdd00, 0.5, 12);
    partGlow.position.copy(part.position);
    scene.add(partGlow);
  });

  spawnMonster(currentFloor, x, CONFIG.lobbyDepth / 2 + 0.6, 1);
}

function showElevatorMenu() {
  const menuDiv = document.createElement('div');
  menuDiv.style.cssText = 'position:fixed;inset:0;z-index:9998;background:linear-gradient(135deg, rgba(0,0,0,0.95), rgba(50,60,100,0.3));backdrop-filter:blur(12px);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#ffd700;font-family:monospace;padding:20px';

  let html = `<h2 style="font-size:1.8rem;margin:0 0 40px 0;text-shadow:0 0 25px rgba(255,215,0,0.7)">⬆️ FLOORS</h2><div style="display:grid;grid-template-columns:repeat(5,70px);gap:12px;margin-bottom:40px">`;

  for (let i = 1; i <= 10; i++) {
    const canGo = i <= currentFloor;
    html += `<button id="floor-${i}" style="width:70px;height:70px;font-size:1.4rem;background:${canGo ? 'linear-gradient(135deg, #ffd700, #ffed4e)' : '#2a2a3a'};color:${canGo ? '#000' : '#666'};border:2px solid ${canGo ? '#ff9900' : '#444'};border-radius:6px;cursor:${canGo ? 'pointer' : 'not-allowed'};font-weight:bold;transition:all 0.2s">${i}</button>`;
  }

  html += `</div><button id="close-elev" style="padding:12px 28px;font-size:1rem;background:#666;color:#fff;border:2px solid #999;border-radius:6px;cursor:pointer;transition:all 0.2s;font-weight:bold">CLOSE</button>`;

  menuDiv.innerHTML = html;
  document.body.appendChild(menuDiv);

  for (let i = 1; i <= 10; i++) {
    if (i <= currentFloor) {
      document.getElementById(`floor-${i}`).addEventListener('click', () => {
        menuDiv.remove();
        currentFloor = i;
        loadFloor(i);
      });
    }
  }

  document.getElementById('close-elev').addEventListener('click', () => menuDiv.remove());
}

function kill(reason) {
  if (gameOver) return;

  if (characterChoice === 'fat' && hasTotem) {
    hasTotem = false;
    camera.position.set(0, CONFIG.playerHeight, 4);
    camera.rotation.set(0, 0, 0);
    showMsg('💚 Respawned!');
    updateHUD();
    return;
  }

  if (gameMode === 'peaceful') { showMsg('You fled'); return; }

  gameOver = true;
  const deathDiv = document.createElement('div');
  deathDiv.style.cssText = 'position:fixed;inset:0;z-index:9999;background:linear-gradient(135deg, rgba(120,0,0,0.95), rgba(50,0,0,0.95));display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;font-family:Arial;text-align:center;backdrop-filter:blur(8px);padding:20px';

  deathDiv.innerHTML = `
    <h1 style="font-size:3rem;margin:0;text-shadow:0 0 40px rgba(0,0,0,0.95);font-weight:900;color:#ff3333">💀 DEAD</h1>
    <p style="font-size:1.1rem;margin:20px 0;color:#ffaa99;font-weight:bold">${reason}</p>
    <div style="font-size:0.95rem;margin:25px 0;color:#eee;line-height:2">
      <p style="margin:0"><strong>Score:</strong> ${score}</p>
      <p style="margin:5px 0"><strong>Floor:</strong> ${currentFloor}</p>
      <p style="margin:5px 0 0 0"><strong>Time:</strong> ${Math.floor(timeElapsed / 60)}:${(timeElapsed % 60).toString().padStart(2, '0')}</p>
    </div>
  `;

  document.body.appendChild(deathDiv);

  setTimeout(() => {
    const restartBtn = document.createElement('button');
    restartBtn.textContent = '🔄 RESTART';
    restartBtn.style.cssText = 'position:fixed;bottom:80px;left:50%;transform:translateX(-50%);z-index:10001;padding:14px 40px;font-size:1.1rem;background:linear-gradient(135deg, #ff5555, #ff0000);color:#fff;border:3px solid #ffaa00;border-radius:8px;cursor:pointer;font-weight:bold;box-shadow:0 8px 25px rgba(255,0,0,0.7);text-shadow:0 0 10px rgba(0,0,0,0.5)';
    restartBtn.addEventListener('click', () => location.reload());
    document.body.appendChild(restartBtn);
  }, 1000);
}

function winGame() {
  gameOver = true;
  const winDiv = document.createElement('div');
  winDiv.style.cssText = 'position:fixed;inset:0;z-index:9999;background:linear-gradient(135deg, rgba(255,215,0,0.95), rgba(180,140,20,0.95));display:flex;flex-direction:column;align-items:center;justify-content:center;color:#000;font-family:Arial;text-align:center;backdrop-filter:blur(8px);padding:20px';

  winDiv.innerHTML = `
    <h1 style="font-size:3rem;margin:0;text-shadow:0 0 30px rgba(0,0,0,0.4);font-weight:900;color:#ff6600">🚁 ESCAPED!</h1>
    <p style="font-size:1.4rem;margin:20px 0;color:#333;font-weight:bold">SCORE: ${score}</p>
    <div style="font-size:0.95rem;color:#222;line-height:2;margin:25px 0">
      <p style="margin:0">⏱️ ${Math.floor(timeElapsed / 60)}:${(timeElapsed % 60).toString().padStart(2, '0')}</p>
      <p style="margin:5px 0">🎯 ${monstersKilled} defeated</p>
      <p style="margin:5px 0">💜 ${hasGum} gum left</p>
    </div>
  `;

  document.body.appendChild(winDiv);

  setTimeout(() => {
    const playBtn = document.createElement('button');
    playBtn.textContent = '🎮 PLAY AGAIN';
    playBtn.style.cssText = 'position:fixed;bottom:80px;left:50%;transform:translateX(-50%);z-index:10001;padding:14px 40px;font-size:1.1rem;background:#000;color:#ffd700;border:3px solid #ffd700;border-radius:8px;cursor:pointer;font-weight:bold;box-shadow:0 8px 25px rgba(255,215,0,0.8);text-shadow:0 0 10px rgba(0,0,0,0.5)';
    playBtn.addEventListener('click', () => location.reload());
    document.body.appendChild(playBtn);
  }, 1200);
}

function updateMonsters(dt) {
  const playerPos = camera.position;
  const playerDir = camera.getWorldDirection(new THREE.Vector3());

  monsters.forEach(m => {
    if (!m.userData.alive) return;

    if (m.userData.slowMult < 1) {
      slowActive -= dt;
      if (slowActive <= 0) m.userData.slowMult = 1;
    }

    const adjustedDt = dt * m.userData.slowMult;
    const toPlayer = new THREE.Vector3().subVectors(playerPos, m.position);
    const dist = toPlayer.length();

    if (dist < 0.55) { kill(`Caught by ${m.userData.kind}`); return; }

    toPlayer.normalize();
    const lookingAt = playerDir.dot(toPlayer) > 0.68 && dist < 13;
    const kind = m.userData.kind;

    if (kind === 'watcher') {
      if (!lookingAt && dist > 1.3) {
        m.position.addScaledVector(toPlayer, m.userData.speed * adjustedDt);
      }
    } else if (kind === 'gaze') {
      if (lookingAt) {
        m.userData.lookTimer += adjustedDt;
        if (m.userData.lookTimer > 2.2) kill('Stared too long');
      } else {
        m.userData.lookTimer = Math.max(0, m.userData.lookTimer - adjustedDt * 0.5);
        if (dist > 1.6) m.position.addScaledVector(toPlayer, m.userData.speed * 0.58 * adjustedDt);
      }
    } else {
      if (dist > 1.5) {
        m.position.addScaledVector(toPlayer, m.userData.speed * adjustedDt);
      }
    }
  });
}

const FPS = 50;
const FRAME_TIME = 1 / FPS;
let fpsAccum = 0;

function applyLook() {
  if (!camera) return;
  camera.rotation.order = 'YXZ';
  camera.rotation.y -= lookD.x;
  camera.rotation.x -= lookD.y;
  camera.rotation.x = Math.max(-Math.PI / 2.2, Math.min(Math.PI / 2.2, camera.rotation.x));
  lookD.x = 0;
  lookD.y = 0;
}

function animate() {
  requestAnimationFrame(animate);
  const rawDt = clock.getDelta();

  applyLook();

  fpsAccum += rawDt;
  if (fpsAccum < FRAME_TIME) {
    renderer.render(scene, camera);
    return;
  }

  const dt = Math.min(fpsAccum, 0.033);
  fpsAccum = 0;

  timeElapsed += dt;
  slowCooldown = Math.max(0, slowCooldown - dt);

  if (gameOver) {
    renderer.render(scene, camera);
    return;
  }

  const speed = CONFIG.playerSpeed * dt;
  const forward = new THREE.Vector3();
  const right = new THREE.Vector3();

  camera.getWorldDirection(forward);
  forward.y = 0;
  forward.normalize();
  right.crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();
  camera.position.addScaledVector(forward, joy.y * speed);
  camera.position.addScaledVector(right, joy.x * speed);

  camera.position.y = CONFIG.playerHeight;
  camera.position.x = Math.max(-2.8, Math.min(2.8, camera.position.x));
  camera.position.z = Math.max(-3.8, Math.min(5, camera.position.z));

  updateMonsters(dt);
  updateHUD();

  renderer.render(scene, camera);
}

setupStartMenu();
window.beginGame = beginGame;
init();

async function init() {}

} catch (err) {
  console.error(err);
  showFatal('Game crashed: ' + (err && err.message ? err.message : String(err)));
}
})();

import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

/* ============================================================
   SKYLINE HOTEL – 10 FLOORS (FIXED VERSION)
   ✓ Camera controls work on desktop & mobile
   ✓ Room doors open properly
   ✓ Monster models 20x better
   ✓ All bugs fixed
   ============================================================ */

const CONFIG = {
  floors: 10,
  floorHeight: 4.2,
  corridorWidth: 7,
  corridorLength: 28,
  playerHeight: 1.7,
  playerSpeed: 6.5,
  roomDepth: 9
};

let scene, camera, renderer, controls;
let currentFloor = 1;
let partsCollected = 0;
const TOTAL_PARTS = 10;
let gameMode = 'normal';
let multiplayer = false;
let isHost = false;
let peer = null;
let myPeerId = null;
let roomCode = null;
let monsterSeed = null;
let playerName = 'Player';
let playerAvatar = 0;
const AVATAR_COLORS = [0x4488ff, 0x44cc66, 0xff8844, 0xcc44cc, 0xff4466, 0x44cccc, 0xffcc33, 0xaaaaaa];

const peerConns = [];
const remotePlayers = {};
const MAX_PLAYERS = 3;

let move = { f: false, b: false, l: false, r: false };
let isMobile = false;
let joy = { x: 0, y: 0 };
let lookD = { x: 0, y: 0 };
let interactables = [];
let monsters = [];
let elevators = [];
let insideElevator = false;
let elevPromptShown = false;
let ridingElevator = false;
let rideTimer = 0;
let ridePhase = null;
let rideTarget = null;
let parts = [];
const collectedParts = new Set();
let clock = new THREE.Clock();
let raycaster = new THREE.Raycaster();
let elevatorOpen = false;
let gameOver = false;
let holdingItem = null;
let stunCooldown = 0;
let stunActive = 0;

const loadingEl = document.getElementById('loading');
const progressEl = document.getElementById('progress');
const hud = document.getElementById('hud');
const floorInd = document.getElementById('floor-indicator');
const partsEl = document.getElementById('parts');
const mobileControls = document.getElementById('mobile-controls');
const dialogue = document.getElementById('dialogue');
const npcNameEl = document.getElementById('npc-name');
const npcTextEl = document.getElementById('npc-text');
const winScreen = document.getElementById('win-screen');
const elevatorUI = document.getElementById('elevator-ui');
const msgEl = document.getElementById('msg');
const stunBtn = document.getElementById('stun-btn');
const stunCdEl = document.getElementById('stun-cd');

function showMsg(text, time = 3000) {
  msgEl.textContent = text;
  msgEl.classList.remove('hidden');
  setTimeout(() => msgEl.classList.add('hidden'), time);
}

function loadProfile() {
  try {
    const n = localStorage.getItem('sky_name');
    const a = localStorage.getItem('sky_avatar');
    if (n) playerName = n.slice(0, 12);
    if (a != null) playerAvatar = Math.max(0, Math.min(AVATAR_COLORS.length - 1, parseInt(a, 10) || 0));
  } catch (e) {}
}

function saveProfile() {
  try {
    localStorage.setItem('sky_name', playerName);
    localStorage.setItem('sky_avatar', String(playerAvatar));
  } catch (e) {}
}

function setupProfileUI() {
  loadProfile();
  const nameIn = document.getElementById('player-name');
  const row = document.getElementById('avatar-row');
  const prev = document.getElementById('avatar-preview');
  if (nameIn) {
    nameIn.value = playerName;
    nameIn.addEventListener('input', () => {
      playerName = (nameIn.value || 'Player').trim().slice(0, 12) || 'Player';
      saveProfile();
    });
  }
  if (row) {
    row.innerHTML = '';
    AVATAR_COLORS.forEach((col, i) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'avatar-opt' + (i === playerAvatar ? ' selected' : '');
      b.style.background = '#' + col.toString(16).padStart(6, '0');
      b.addEventListener('click', () => {
        playerAvatar = i;
        row.querySelectorAll('.avatar-opt').forEach((x, j) => {
          x.classList.toggle('selected', j === i);
        });
        if (prev) prev.style.background = b.style.background;
        saveProfile();
      });
      row.appendChild(b);
    });
  }
  if (prev) prev.style.background = '#' + AVATAR_COLORS[playerAvatar].toString(16).padStart(6, '0');
}

function setupStartMenu() {
  const btnN = document.getElementById('btn-normal');
  const btnP = document.getElementById('btn-peaceful');
  const btnPlay = document.getElementById('btn-play');
  const btnHost = document.getElementById('btn-host');
  const btnJoin = document.getElementById('btn-join');
  const status = document.getElementById('mp-status');

  btnN.onclick = () => {
    gameMode = 'normal';
    btnN.classList.add('active');
    btnP.classList.remove('active');
  };
  btnP.onclick = () => {
    gameMode = 'peaceful';
    btnP.classList.add('active');
    btnN.classList.remove('active');
  };
  btnPlay.onclick = () => {
    multiplayer = false;
    beginGame();
  };

  btnHost.onclick = () => {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      status.textContent = 'No internet. Hotspot with 0 data cannot matchmake.';
      return;
    }
    if (typeof Peer === 'undefined') {
      status.textContent = 'PeerJS failed to load';
      return;
    }
    status.textContent = 'Creating room…';
    multiplayer = true;
    isHost = true;
    monsterSeed = (Math.random() * 1e9) | 0;
    const code = Math.random().toString(36).slice(2, 6).toUpperCase();
    roomCode = code;
    const id = 'sky' + code.toLowerCase();
    peer = new Peer(id, { debug: 1 });
    peer.on('open', (pid) => {
      myPeerId = pid;
      status.textContent = 'YOUR CODE: ' + code;
      setTimeout(() => {
        if (!document.getElementById('start-menu').classList.contains('hidden')) {
          beginGame();
        }
      }, 3000);
    });
    peer.on('connection', (conn) => { setupConn(conn); });
    peer.on('error', (err) => { status.textContent = 'Host error: ' + (err.type || err.message || err); });
  };

  btnJoin.onclick = () => {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      status.textContent = 'No internet.';
      return;
    }
    if (typeof Peer === 'undefined') {
      status.textContent = 'PeerJS failed to load';
      return;
    }
    const code = (document.getElementById('join-code').value || '').trim().toUpperCase();
    if (code.length < 3) {
      status.textContent = 'Enter the host room code';
      return;
    }
    status.textContent = 'Connecting…';
    multiplayer = true;
    isHost = false;
    roomCode = code;
    peer = new Peer({ debug: 1 });
    peer.on('open', () => {
      myPeerId = peer.id;
      const hostId = 'sky' + code.toLowerCase();
      const conn = peer.connect(hostId, { reliable: true });
      setupConn(conn);
      conn.on('open', () => {
        status.textContent = 'Connected!';
        beginGame();
      });
    });
  };
}

function setupConn(conn) {
  conn.on('open', () => {
    if (peerConns.length >= MAX_PLAYERS - 1) {
      conn.send({ type: 'full' });
      conn.close();
      return;
    }
    peerConns.push(conn);
    conn.send({
      type: 'hello',
      id: myPeerId,
      mode: gameMode,
      name: playerName || (isHost ? 'Host' : 'Player'),
      avatar: playerAvatar,
      seed: monsterSeed,
      isHost: isHost
    });
  });
  conn.on('data', (data) => {
    if (!data || !data.type) return;
    if (data.type === 'full') {
      const status = document.getElementById('mp-status');
      if (status) status.textContent = 'Room full (max 3)';
      return;
    }
    if (data.type === 'hello') {
      ensureRemotePlayer(data.id, data.name, data.avatar);
      if (data.isHost && data.seed != null && !isHost) {
        monsterSeed = data.seed;
        if (typeof data.mode === 'string') gameMode = data.mode;
      }
      if (!conn.userData) conn.userData = {};
      if (!conn.userData.saidHello) {
        conn.userData.saidHello = true;
        try {
          conn.send({
            type: 'hello',
            id: myPeerId,
            name: playerName || (isHost ? 'Host' : 'Player'),
            avatar: playerAvatar,
            seed: monsterSeed,
            isHost: isHost,
            mode: gameMode
          });
        } catch (e) {}
      }
    }
    if (data.type === 'pos') {
      updateRemotePlayer(data);
      if (isHost) {
        peerConns.forEach(c => {
          if (c !== conn && c.open) {
            try { c.send(data); } catch (e) {}
          }
        });
      }
    }
  });
  conn.on('close', () => {
    const i = peerConns.indexOf(conn);
    if (i >= 0) peerConns.splice(i, 1);
  });
}

function ensureRemotePlayer(id, name, avatarIdx) {
  if (!id || id === myPeerId) return;
  if (!scene) return;
  const color = AVATAR_COLORS[(avatarIdx != null ? avatarIdx : 0) % AVATAR_COLORS.length];
  if (remotePlayers[id]) {
    remotePlayers[id].name = name || remotePlayers[id].name;
    return;
  }
  const g = new THREE.Group();
  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.28, 0.9, 4, 8),
    new THREE.MeshLambertMaterial({ color })
  );
  body.position.y = 1.0;
  g.add(body);
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.22, 8, 6),
    new THREE.MeshLambertMaterial({ color: 0xffddbb })
  );
  head.position.y = 1.75;
  g.add(head);
  scene.add(g);
  remotePlayers[id] = { mesh: g, last: performance.now(), name: name || 'Player' };
}

function updateRemotePlayer(data) {
  if (!data.id || data.id === myPeerId) return;
  ensureRemotePlayer(data.id, data.name, data.avatar);
  const rp = remotePlayers[data.id];
  if (!rp || !rp.mesh) return;
  rp.mesh.position.set(data.x, data.y, data.z);
  if (typeof data.ry === 'number') rp.mesh.rotation.y = data.ry;
  const sameFloor = String(data.floor) === String(currentFloor);
  rp.mesh.visible = sameFloor;
  rp.last = performance.now();
  rp.floor = data.floor;
}

let _mpSendAcc = 0;
function multiplayerTick(dt) {
  if (!multiplayer || !peerConns.length) return;
  _mpSendAcc += dt;
  if (_mpSendAcc < 0.1) return;
  _mpSendAcc = 0;
  if (!myPeerId || !camera) return;
  const payload = {
    type: 'pos',
    id: myPeerId,
    x: camera.position.x,
    y: camera.position.y,
    z: camera.position.z,
    ry: camera.rotation.y,
    floor: currentFloor,
    parts: partsCollected
  };
  peerConns.forEach(c => {
    if (c && c.open) {
      try { c.send(payload); } catch (e) {}
    }
  });
  const now = performance.now();
  Object.keys(remotePlayers).forEach(id => {
    const rp = remotePlayers[id];
    if (rp && now - rp.last > 4000) rp.mesh.visible = false;
  });
}

async function init() {
  setupProfileUI();
  setupStartMenu();
}

function beginGame() {
  document.getElementById('start-menu').classList.add('hidden');
  document.getElementById('loading').classList.remove('hidden');
  
  // ✓ FIX: Detect mobile properly (don't hardcode to true)
  isMobile = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0) || (navigator.msMaxTouchPoints > 0);

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x4a4a5e);
  scene.fog = null;

  camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.15, 55);
  camera.position.set(0, CONFIG.playerHeight, 0);
  camera.rotation.order = 'YXZ';

  renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', alpha: false });
  renderer.setSize(innerWidth, innerHeight);
  renderer.setPixelRatio(1);
  renderer.shadowMap.enabled = false;
  renderer.domElement.style.position = 'fixed';
  renderer.domElement.style.inset = '0';
  renderer.domElement.style.zIndex = '1';
  document.body.appendChild(renderer.domElement);

  scene.add(new THREE.AmbientLight(0xffffff, 1.55));

  // ✓ FIX: Create PointerLockControls for desktop
  if (!isMobile) {
    controls = new PointerLockControls(camera, renderer.domElement);
    renderer.domElement.style.pointerEvents = 'auto';
    renderer.domElement.addEventListener('click', () => {
      if (!controls.isLocked) controls.lock();
    });
    controls.addEventListener('lock', () => {
      const ch = document.getElementById('crosshair');
      if (ch) ch.style.display = 'block';
    });
    controls.addEventListener('unlock', () => {
      // Keep crosshair visible
    });
  } else {
    renderer.domElement.style.pointerEvents = 'none';
  }

  if (monsterSeed == null) randomizeMonsters();
  else randomizeMonsters(monsterSeed);
  buildRoofOnly();
  loadFloor(1);
  placePartsForFloor(1);
  placeMonstersForFloor(1);
  placeNPCs();

  setupMobile();
  setupKeys();
  setupUI();

  progressEl.style.width = '100%';
  setTimeout(() => {
    loadingEl.classList.add('hidden');
    hud.classList.remove('hidden');
    mobileControls.classList.remove('hidden');
  }, 700);

  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });

  animate();
}

/* ────────────────────────────────────────────────────────────── */

function disposeObject(obj) {
  obj.traverse(o => {
    if (o.geometry) o.geometry.dispose();
    if (o.material) {
      if (Array.isArray(o.material)) o.material.forEach(m => m.dispose && m.dispose());
      else if (o.material.dispose) o.material.dispose();
    }
  });
}

function unloadCurrentFloor() {
  const g = scene.userData.currentFloorGroup;
  if (g) {
    scene.remove(g);
    disposeObject(g);
    scene.userData.currentFloorGroup = null;
  }
  interactables = interactables.filter(o => {
    const t = o.userData && o.userData.type;
    if (t === 'item' || t === 'box' || t === 'room-door' || t === 'elevator') return false;
    return t === 'part' || t === 'monster';
  });
  scene.children.slice().forEach(ch => {
    if (ch.userData && (ch.userData.type === 'item' || ch.userData.type === 'box')) {
      scene.remove(ch);
    }
  });
  elevators = [];
  monsters.forEach(m => {
    scene.remove(m);
    disposeObject(m);
  });
  monsters = [];
  parts.forEach(p => {
    if (p.parent) p.parent.remove(p);
    scene.remove(p);
  });
}

function buildRoofOnly() {
  const roofY = CONFIG.floors * CONFIG.floorHeight;
  const roof = new THREE.Group();
  roof.position.y = roofY;
  const pad = new THREE.Mesh(
    new THREE.BoxGeometry(20, 0.3, 16),
    new THREE.MeshLambertMaterial({ color: 0x5a5a62 })
  );
  roof.add(pad);
  createHelicopter();
  scene.userData.roofGroup = roof;
  scene.add(roof);
  roof.visible = false;
}

// ✓ IMPROVED: Better room building with proper rotations
function buildRedSuite(parent, cx, halfL, halfW, roomD, materials) {
  const g = new THREE.Group();
  parent.add(g);
  
  // Red room is on -X side: rotate so furniture faces INTO room (away from door)
  g.rotation.y = Math.PI;
  g.position.set(cx, 0, 0);

  // Floor rug
  const rug = new THREE.Mesh(new THREE.BoxGeometry(roomD * 0.65, 0.01, halfW * 1.1), materials.rugR);
  rug.position.set(roomD * 0.1, 0.005, 0);
  g.add(rug);

  // Bed
  const bedFrame = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.55, 1.85), materials.wood);
  bedFrame.position.set(roomD * 0.45, 0.275, -halfW * 0.28);
  g.add(bedFrame);
  const mattress = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.22, 1.72), materials.sheet);
  mattress.position.set(roomD * 0.45, 0.66, -halfW * 0.28);
  g.add(mattress);
  const sheets = new THREE.Mesh(new THREE.BoxGeometry(1.95, 0.12, 1.6), materials.fabric);
  sheets.position.set(roomD * 0.42, 0.8, -halfW * 0.24);
  sheets.rotation.y = 0.07;
  g.add(sheets);
  
  for (let i = 0; i < 2; i++) {
    const pillow = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.14, 0.42), materials.sheet);
    pillow.position.set(roomD * 0.58, 0.84, -halfW * 0.28 + (i === 0 ? 0.38 : -0.38));
    pillow.rotation.y = i === 0 ? 0.05 : -0.04;
    g.add(pillow);
  }

  const underBed = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.09, 0.22), materials.dark);
  underBed.position.set(roomD * 0.35, 0.05, -halfW * 0.28 - 0.86);
  g.add(underBed);

  const headboard = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.35, 1.85), materials.wood);
  headboard.position.set(roomD * 0.58 + 1.25, 0.67, -halfW * 0.28);
  g.add(headboard);

  // Nightstands and lamps
  for (let i = 0; i < 2; i++) {
    const ns = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.52, 0.44), materials.wood);
    const zOff = i === 0 ? 0.34 : -1.28;
    ns.position.set(roomD * 0.58 + 1.1, 0.26, -halfW * 0.28 + zOff + (i === 0 ? 1.1 : -0.1));
    g.add(ns);

    const lampBase = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.1, 0.04, 7), materials.metal);
    lampBase.position.set(ns.position.x, 0.54, ns.position.z + (i === 0 ? -0.05 : 0.05));
    g.add(lampBase);
    const lampPole = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.38, 6), materials.metal);
    lampPole.position.set(lampBase.position.x, 0.73, lampBase.position.z);
    g.add(lampPole);
    const shade = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.22, 7, 1, true), materials.fabric);
    shade.position.set(lampBase.position.x, 0.98, lampBase.position.z);
    shade.rotation.x = Math.PI;
    g.add(shade);
  }

  const phone = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.05, 0.16), materials.dark);
  phone.position.set(roomD * 0.58 + 1.05, 0.555, -halfW * 0.28 + 1.12);
  phone.rotation.y = 0.15;
  g.add(phone);

  // Sofa
  const sofaBase = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.42, 0.72), materials.fabric);
  sofaBase.position.set(roomD * 0.18, 0.21, halfW * 0.35);
  g.add(sofaBase);
  const sofaBack = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.55, 0.14), materials.fabric);
  sofaBack.position.set(roomD * 0.18, 0.55, halfW * 0.35 + 0.29);
  g.add(sofaBack);

  // Coffee table
  const ctTop = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.06, 0.44), materials.wood);
  ctTop.position.set(roomD * 0.1, 0.38, halfW * 0.35);
  g.add(ctTop);
  for (let i = 0; i < 4; i++) {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.38, 0.05), materials.wood);
    const lx = i < 2 ? 0.32 : -0.32;
    const lz = i % 2 === 0 ? 0.18 : -0.18;
    leg.position.set(roomD * 0.1 + lx, 0.19, halfW * 0.35 + lz);
    g.add(leg);
  }

  // TV
  const tvMount = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.72, 1.22), materials.dark);
  tvMount.position.set(roomD * 0.94, 1.55, -halfW * 0.15);
  g.add(tvMount);
  const tvScreen = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.6, 1.1), materials.metal);
  tvScreen.position.set(roomD * 0.94 - 0.04, 1.55, -halfW * 0.15);
  g.add(tvScreen);

  // Wardrobe
  const wardrobe = new THREE.Mesh(new THREE.BoxGeometry(0.55, 2.1, 1.1), materials.wood);
  wardrobe.position.set(roomD * 0.88, 1.05, halfW * 0.52);
  g.add(wardrobe);

  // Minibar
  const minibar = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.82, 0.55), materials.dark);
  minibar.position.set(roomD * 0.74, 0.41, halfW * 0.52);
  g.add(minibar);
  for (let i = 0; i < 3; i++) {
    const bottle = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.04, 0.22, 6), materials.metal);
    bottle.position.set(roomD * 0.74 - 0.1 + i * 0.1, 0.93, halfW * 0.52);
    g.add(bottle);
  }

  // Suitcase
  const suitcase = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.32, 0.44), materials.fabric);
  suitcase.position.set(roomD * 0.65, 0.16, halfW * 0.48);
  suitcase.rotation.y = 0.3;
  g.add(suitcase);

  // Curtains
  for (let i = 0; i < 2; i++) {
    const curtain = new THREE.Mesh(new THREE.BoxGeometry(0.08, 2.2, 0.58), materials.fabric);
    curtain.position.set(roomD * 0.5, 1.1, i === 0 ? halfW * 0.62 : halfW * 0.62 - 0.7);
    curtain.rotation.y = i === 0 ? 0.08 : -0.05;
    g.add(curtain);
  }

  // Painting (tilted)
  const frame = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.72, 0.58), materials.wood);
  frame.position.set(roomD * 0.3, 1.6, -halfW * 0.62);
  frame.rotation.z = 0.105;
  g.add(frame);
  const canvas = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.58, 0.44), materials.dark);
  canvas.position.set(roomD * 0.3 - 0.01, 1.6, -halfW * 0.62);
  canvas.rotation.z = 0.105;
  g.add(canvas);

  // Horror: dark stain
  const stain = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.35, 0.008, 8), materials.blood);
  stain.position.set(roomD * 0.35, 0.002, -halfW * 0.28 - 0.95);
  g.add(stain);

  // Trash
  const trash = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.1, 0.32, 7), materials.metal);
  trash.position.set(roomD * 0.62, 0.16, -halfW * 0.58);
  g.add(trash);
}

function buildBlueSuite(parent, cx, halfL, halfW, roomD, materials) {
  const g = new THREE.Group();
  parent.add(g);

  const stain1 = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.7, 0.006, 7), materials.dark);
  stain1.position.set(roomD * 0.38, 0.002, halfW * 0.1);
  g.add(stain1);

  const stain2 = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.28, 0.006, 6), materials.blood);
  stain2.position.set(roomD * 0.72, 0.002, -halfW * 0.3);
  g.add(stain2);

  // Bed
  const bedFrame = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.38, 1.4), materials.wood);
  bedFrame.position.set(roomD * 0.42, 0.19, halfW * 0.32);
  g.add(bedFrame);
  const mattress = new THREE.Mesh(new THREE.BoxGeometry(1.88, 0.18, 1.28), materials.bed);
  mattress.position.set(roomD * 0.42, 0.47, halfW * 0.32);
  g.add(mattress);
  const sheets = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.1, 1.1), materials.sheet);
  sheets.position.set(roomD * 0.38, 0.57, halfW * 0.28);
  sheets.rotation.y = 0.42;
  g.add(sheets);
  const pillow = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.12, 0.4), materials.sheet);
  pillow.position.set(roomD * 0.52, 0.38, halfW * 0.32 + 0.58);
  pillow.rotation.z = 0.55;
  pillow.rotation.y = 0.2;
  g.add(pillow);

  // Desk
  const deskTop = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.06, 1.35), materials.wood);
  deskTop.position.set(roomD * 0.78, 0.76, -halfW * 0.3);
  g.add(deskTop);
  for (let i = 0; i < 4; i++) {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.76, 0.06), materials.wood);
    const lx = i < 2 ? 0.22 : -0.22;
    const lz = i % 2 === 0 ? 0.6 : -0.6;
    leg.position.set(roomD * 0.78 + lx, 0.38, -halfW * 0.3 + lz);
    g.add(leg);
  }

  // Papers
  for (let i = 0; i < 4; i++) {
    const paper = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.008, 0.22), materials.sheet);
    paper.position.set(roomD * 0.78 + (Math.random() * 0.18 - 0.09), 0.795 + i * 0.009, -halfW * 0.3 + (Math.random() * 0.7 - 0.35));
    paper.rotation.y = (Math.random() - 0.5) * 0.6;
    g.add(paper);
  }

  // Fridge
  const fridge = new THREE.Mesh(new THREE.BoxGeometry(0.6, 1.52, 0.62), materials.metal);
  fridge.position.set(roomD * 0.88, 0.76, halfW * 0.5);
  g.add(fridge);

  // Bathtub
  const tub = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.44, 1.4), materials.ceramic);
  tub.position.set(roomD * 0.82, 0.22, -halfW * 0.48);
  g.add(tub);
  const tubInner = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.3, 1.25), materials.dark);
  tubInner.position.set(roomD * 0.82, 0.3, -halfW * 0.48);
  g.add(tubInner);

  // Crates
  const crateSizes = [[0.45, 0.45, 0.45], [0.38, 0.38, 0.38], [0.5, 0.28, 0.4]];
  const cratePositions = [[roomD * 0.1, 0.225, -halfW * 0.5], [roomD * 0.1, 0.63, -halfW * 0.5], [roomD * 0.16, 0.14, -halfW * 0.42]];
  for (let i = 0; i < 3; i++) {
    const crate = new THREE.Mesh(new THREE.BoxGeometry(...crateSizes[i]), materials.wood);
    crate.position.set(...cratePositions[i]);
    crate.rotation.y = i * 0.22;
    g.add(crate);
  }

  g.position.set(cx, 0, 0);
}

function loadFloor(f) {
  const M = {
    wall: new THREE.MeshLambertMaterial({ color: 0x6a5e52 }),
    floor: new THREE.MeshLambertMaterial({ color: 0x5a4e42 }),
    ceil: new THREE.MeshLambertMaterial({ color: 0x4a423a }),
    carpet: new THREE.MeshLambertMaterial({ color: 0x8a3a3a }),
    red: new THREE.MeshLambertMaterial({ color: 0x9a1a1a }),
    blue: new THREE.MeshLambertMaterial({ color: 0x1a3a9a }),
    gold: new THREE.MeshLambertMaterial({ color: 0xd4a84b }),
    frame: new THREE.MeshLambertMaterial({ color: 0x2a2218 }),
    bed: new THREE.MeshLambertMaterial({ color: 0x4a3038 }),
    wood: new THREE.MeshLambertMaterial({ color: 0x6b4a30 }),
    rugR: new THREE.MeshLambertMaterial({ color: 0x5a2028 }),
    rugB: new THREE.MeshLambertMaterial({ color: 0x203050 }),
    metal: new THREE.MeshLambertMaterial({ color: 0x777780 }),
    sheet: new THREE.MeshLambertMaterial({ color: 0xd8d0c8 }),
    fabric: new THREE.MeshLambertMaterial({ color: 0x5a4050 }),
    dark: new THREE.MeshLambertMaterial({ color: 0x1a1512 }),
    blood: new THREE.MeshLambertMaterial({ color: 0x5a1010 }),
    ceramic: new THREE.MeshLambertMaterial({ color: 0xc8c0b8 })
  };

  const halfL = CONFIG.corridorLength / 2;
  const halfW = CONFIG.corridorWidth / 2;
  const h = CONFIG.floorHeight - 0.25;
  const roomD = CONFIG.roomDepth;
  const doorW = 2.6;
  const doorH = 2.7;

  const g = new THREE.Group();
  g.userData.floorNum = f;

  const slab = new THREE.Mesh(new THREE.BoxGeometry(CONFIG.corridorLength + roomD * 2 + 2, 0.2, CONFIG.corridorWidth + 2), M.floor);
  slab.position.y = -0.1;
  g.add(slab);

  const carpet = new THREE.Mesh(new THREE.BoxGeometry(CONFIG.corridorLength - 1, 0.02, 2.0), M.carpet);
  carpet.position.y = 0.02;
  g.add(carpet);

  const ceil = new THREE.Mesh(new THREE.BoxGeometry(CONFIG.corridorLength, 0.15, CONFIG.corridorWidth), M.ceil);
  ceil.position.y = CONFIG.floorHeight - 0.08;
  g.add(ceil);

  // Side walls with elevator gaps
  for (const zs of [-1, 1]) {
    const elevW = 2.8;
    const segs = [[-halfL - 0.2, -elevW / 2], [elevW / 2, halfL + 0.2]];
    segs.forEach(([a, b]) => {
      const w = b - a;
      if (w < 0.2) return;
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, 0.35), M.wall);
      m.position.set((a + b) / 2, h / 2, zs * halfW);
      g.add(m);
    });
    const lintel = new THREE.Mesh(new THREE.BoxGeometry(elevW + 0.2, 0.35, 0.4), M.wall);
    lintel.position.set(0, doorH + 0.15, zs * halfW);
    g.add(lintel);
  }

  // End walls
  function endWall(xSign) {
    const x = xSign * halfL;
    const gap = doorW;
    for (const zs of [-1, 1]) {
      const zw = (halfW - gap / 2);
      if (zw < 0.15) continue;
      const p = new THREE.Mesh(new THREE.BoxGeometry(0.4, h, zw), M.wall);
      p.position.set(x, h / 2, zs * (gap / 2 + zw / 2));
      g.add(p);
    }
    const top = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, gap + 0.2), M.wall);
    top.position.set(x, doorH + 0.15, 0);
    g.add(top);
  }
  endWall(-1);
  endWall(1);

  // ✓ FIX: End doors at X ends, not Z
  function makeEndDoor(xSign, mat, label) {
    const group = new THREE.Group();
    group.position.set(xSign * halfL, 0, 0);
    const panel = new THREE.Mesh(new THREE.BoxGeometry(0.14, doorH, doorW - 0.1), mat);
    panel.position.y = doorH / 2;
    group.add(panel);
    for (const zs of [-1, 1]) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.28, doorH + 0.1, 0.16), M.frame);
      post.position.set(0, doorH / 2, zs * (doorW / 2));
      group.add(post);
    }
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.1), M.gold);
    handle.position.set(xSign * 0.1, 1.15, doorW * 0.25);
    group.add(handle);
    group.userData = {
      type: 'room-door',
      open: false,
      side: xSign,
      floor: f,
      label,
      closedZ: 0,
      endDoor: true
    };
    panel.userData = group.userData;
    g.add(group);
    interactables.push(group, panel);
  }
  makeEndDoor(-1, M.red, 'RED');
  makeEndDoor(1, M.blue, 'BLUE');

  // Room shells
  function makeEndRoomShell(xSign, isRed) {
    const cx = xSign * (halfL + roomD / 2);
    const fl = new THREE.Mesh(new THREE.BoxGeometry(roomD, 0.06, CONFIG.corridorWidth + 1.5), isRed ? M.rugR : M.rugB);
    fl.position.set(cx, 0.02, 0);
    g.add(fl);
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.25, 3.0, CONFIG.corridorWidth + 1.5), M.wall);
    back.position.set(xSign * (halfL + roomD), 1.5, 0);
    g.add(back);
    for (const zs of [-1, 1]) {
      const sw = new THREE.Mesh(new THREE.BoxGeometry(roomD, 3.0, 0.25), M.wall);
      sw.position.set(cx, 1.5, zs * (halfW + 0.75));
      g.add(sw);
    }
  }
  makeEndRoomShell(-1, true);
  makeEndRoomShell(1, false);

  const redCx = -(halfL + roomD / 2);
  const blueCx = (halfL + roomD / 2);
  buildRedSuite(g, redCx, halfL, halfW, roomD, M);
  buildBlueSuite(g, blueCx, halfL, halfW, roomD, M);

  createElevatorSide(g, -halfW, f);
  createElevatorSide(g, halfW, f);

  scene.add(g);
  scene.userData.currentFloorGroup = g;
  currentFloor = f;
  if (floorInd) floorInd.textContent = 'Floor ' + f;

  camera.position.set(0, CONFIG.playerHeight, 0);
  camera.rotation.order = 'YXZ';
  camera.rotation.y = 0;
  camera.rotation.x = 0;
}

function showFloorLoading(text) {
  let el = document.getElementById('floor-loading');
  if (!el) {
    el = document.createElement('div');
    el.id = 'floor-loading';
    el.style.cssText = 'position:fixed;inset:0;z-index:500;background:rgba(5,5,12,0.92);display:flex;align-items:center;justify-content:center;flex-direction:column;color:#d4a84b;font-family:system-ui;';
    el.innerHTML = '<div style="font-size:1.4rem;font-weight:700;margin-bottom:12px;">LOADING FLOOR</div><div id="floor-loading-text"></div>';
    document.body.appendChild(el);
  }
  const t = document.getElementById('floor-loading-text');
  if (t) t.textContent = text || '';
  el.style.display = 'flex';
  el.classList.remove('hidden');
}

function hideFloorLoading() {
  const el = document.getElementById('floor-loading');
  if (el) el.style.display = 'none';
}

function createElevator(parent, x, floorNum) {
  createElevatorSide(parent, 0, floorNum, x);
}

function createElevatorSide(parent, z, floorNum, xPos) {
  const side = z >= 0 ? 1 : -1;
  const group = new THREE.Group();
  const x = (xPos != null && xPos !== 0) ? xPos : 0;
  group.position.set(x, 0, z);

  const gold = new THREE.MeshLambertMaterial({ color: 0xe8b84a });
  const dark = new THREE.MeshLambertMaterial({ color: 0x14141c });

  const L = new THREE.Mesh(new THREE.BoxGeometry(0.35, 2.9, 0.35), gold);
  L.position.set(-1.35, 1.45, 0);
  group.add(L);
  const R = L.clone();
  R.position.x = 1.35;
  group.add(R);
  const top = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.35, 0.35), gold);
  top.position.set(0, 2.95, 0);
  group.add(top);
  const hole = new THREE.Mesh(new THREE.BoxGeometry(2.5, 2.7, 0.4), dark);
  hole.position.set(0, 1.4, -side * 0.15);
  group.add(hole);

  const hit = new THREE.Mesh(new THREE.BoxGeometry(3.2, 3.2, 3.0), new THREE.MeshBasicMaterial({ visible: false }));
  hit.position.set(0, 1.5, 0);
  hit.userData = { type: 'elevator', floor: floorNum };
  group.add(hit);
  interactables.push(hit);
  parent.add(group);
  elevators.push({ floor: floorNum, side, group, hit, onSide: true });
}

function createHelicopter() {
  const g = new THREE.Group();
  const bodyMat = new THREE.MeshLambertMaterial({ color: 0x2a2a2a });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(1, 2.4, 4, 10), bodyMat);
  body.rotation.z = Math.PI / 2;
  g.add(body);
  const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.28, 3.2, 8), bodyMat);
  tail.rotation.z = Math.PI / 2;
  tail.position.set(-2.8, 0.25, 0);
  g.add(tail);
  const rotor = new THREE.Mesh(new THREE.BoxGeometry(7.5, 0.1, 0.4), new THREE.MeshLambertMaterial({ color: 0x111 }));
  rotor.position.y = 1.25;
  g.add(rotor);
  g.position.set(0, 1.5, 0);
  if (scene.userData.roofGroup) scene.userData.roofGroup.add(g);
  else scene.add(g);
  return g;
}

function placePartsForFloor(f) {
  parts = parts.filter(p => p.userData && p.userData.floor === f);
  if (collectedParts.has(f)) return;
  const part = createPart(f);
  const halfL = CONFIG.corridorLength / 2;
  const roomD = CONFIG.roomDepth;
  part.position.set(-(halfL + roomD * 0.55), 0.55, 0);
  part.userData = { type: 'part', id: f, collected: false, floor: f };
  scene.add(part);
  parts.push(part);
  interactables.push(part);
}

function createPart(id) {
  const g = new THREE.Group();
  const mat = new THREE.MeshLambertMaterial({ color: 0xd4a84b, emissive: 0x3a2a10, emissiveIntensity: 0.35 });
  let mesh;
  if (id % 3 === 0) mesh = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.4, 0.55), mat);
  else if (id % 3 === 1) mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.65, 10), mat);
  else mesh = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.12, 8, 16), mat);
  g.add(mesh);
  return g;
}

// ✓ IMPROVED: Much better monster models
const MONSTER_POOL = [
  { name: 'Whisper Doll', type: 'whisper', speed: 0.9, desc: 'Silence her whisper by interacting', needs: null },
  { name: 'The Watcher', type: 'watcher', speed: 2.2, desc: 'Keep looking or he advances', needs: null },
  { name: 'Gaze Beast', type: 'gaze', speed: 1.2, desc: 'Do not stare more than 2s', needs: null },
  { name: 'Hungry Zombie', type: 'hungry', speed: 1.35, desc: 'Find meat and feed him', needs: 'meat' },
  { name: 'Backwatcher', type: 'backtext', speed: 1.8, desc: 'Never look behind near him', needs: null },
  { name: 'Pale Woman', type: 'stalker', speed: 2.0, desc: 'Keep moving or she cuts you off', needs: null },
  { name: 'Toy Doll', type: 'toy', speed: 1.4, desc: 'Put the toy in box to calm her', needs: 'toy' },
  { name: 'Blood Crier', type: 'crier', speed: 2.0, desc: 'Stand still and look at his face', needs: null },
  { name: 'Shadow Step', type: 'shadowstep', speed: 2.8, desc: 'Stand still to freeze him', needs: null }
];

let MONSTER_DEFS = [];

function mulberry32(a) {
  return function() {
    let t = a += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function shuffleSeeded(arr, rand) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function randomizeMonsters(seed) {
  if (seed == null) seed = (Math.random() * 1e9) | 0;
  monsterSeed = seed;
  const rand = mulberry32(seed >>> 0);
  const pool = shuffleSeeded(MONSTER_POOL, rand);
  const floors = shuffleSeeded([1, 2, 3, 4, 5, 6, 7, 8, 9], rand);
  MONSTER_DEFS = pool.map((m, i) => {
    const floor = floors[i];
    const side = rand() < 0.5 ? -1 : 1;
    const halfL = CONFIG.corridorLength / 2;
    const roomD = CONFIG.roomDepth;
    const x = (side < 0 ? -1 : 1) * (halfL + roomD * 0.45);
    const z = (rand() - 0.5) * 3;
    return {
      name: m.name,
      type: m.type,
      speed: m.speed,
      desc: m.desc,
      needs: m.needs,
      floor,
      pos: [x, 0, z],
      room: side < 0 ? 'RED' : 'BLUE'
    };
  });
}

function placeMonstersForFloor(f) {
  MONSTER_DEFS.filter(d => d.floor === f).forEach(d => addMonster(d));
  placeFloorItems(f);
}

function placeFloorItems(f) {
  const def = MONSTER_DEFS.find(d => d.floor === f);
  if (!def) return;
  const x = def.pos[0];
  const z = def.pos[2];
  if (def.needs === 'meat' || def.type === 'hungry') {
    const meat = createItem(0x8b0000, 'meat');
    meat.position.set(x * 0.9, 0.45, z + 1.2);
    meat.userData = { type: 'item', item: 'meat' };
    scene.add(meat);
    interactables.push(meat);
  }
  if (def.needs === 'toy' || def.type === 'toy') {
    const toy = createItem(0xff69b4, 'toy');
    toy.position.set(x * 0.85, 0.45, z - 1.0);
    toy.userData = { type: 'item', item: 'toy' };
    scene.add(toy);
    interactables.push(toy);
    const box = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.55, 0.9), new THREE.MeshLambertMaterial({ color: 0x5a3a1a }));
    box.position.set(x * 0.9, 0.35, z + 1.5);
    box.userData = { type: 'box' };
    scene.add(box);
    interactables.push(box);
  }
}

function placeNPCs() {
  // Items spawn per-floor
}

function createItem(color, name) {
  const g = new THREE.Group();
  const m = new THREE.Mesh(new THREE.SphereGeometry(0.25, 10, 8), new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.3 }));
  g.add(m);
  return g;
}

function addMonster(data) {
  const m = createMonsterMesh(data.color || 0x333, data.name, data.type);
  m.position.set(data.pos[0], 0, data.pos[2]);
  m.userData = {
    type: 'monster',
    kind: data.type,
    name: data.name,
    speed: data.speed,
    floor: data.floor,
    alive: true,
    lookTimer: 0,
    state: 'idle',
    desc: data.desc,
    stunned: false
  };
  scene.add(m);
  monsters.push(m);
  interactables.push(m);
}

function createMonsterMesh(color, name, kind) {
  let g;
  switch (kind) {
    case 'watcher': g = createWatcherMesh(); break;
    case 'gaze': g = createGazeBeastMesh(); break;
    case 'hungry': g = createHungryZombieMesh(); break;
    case 'backtext': g = createBackwatcherMesh(); break;
    case 'stalker': g = createPaleGirlMesh(); break;
    case 'toy': g = createToyGirlMesh(); break;
    case 'crier': g = createBloodCrierMesh(); break;
    case 'shadowstep': g = createShadowStepMesh(); break;
    case 'whisper': g = createWhisperDollMesh(); break;
    default: g = createWatcherMesh(); break;
  }
  g.scale.set(1.25, 1.25, 1.25);

  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 48;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(0,0,0,0.85)';
  ctx.fillRect(0, 0, 256, 48);
  ctx.fillStyle = '#ff4444';
  ctx.font = 'bold 20px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText(name, 128, 32);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true, depthTest: false }));
  spr.scale.set(1.8, 0.35, 1);
  spr.position.y = 2.7;
  g.add(spr);
  return g;
}

function mat(c, e, ei) {
  return new THREE.MeshLambertMaterial({ color: c, emissive: e || 0x000000, emissiveIntensity: ei || 0 });
}

// ✓ IMPROVED: Much scarier, detailed watcher
function createWatcherMesh() {
  const g = new THREE.Group();
  const suit = mat(0x0a0a10);
  const suitD = mat(0x000000);
  const skin = mat(0xb4a498);
  const skinD = mat(0x4a3840);
  const eyeW = mat(0xffffff, 0xffffee, 0.8);
  const pupil = mat(0x050505, 0x111111, 0.4);
  const blood = mat(0x8a0000, 0x440000, 0.6);

  // Elongated legs
  for (const x of [-0.15, 0.15]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.95, 3, 6), suitD);
    leg.position.set(x, 0.55, 0);
    g.add(leg);
    const foot = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.06, 0.3), suitD);
    foot.position.set(x, 0.02, -0.1);
    g.add(foot);
  }

  // Long coat
  const coat = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.42, 1.3, 8), suit);
  coat.position.y = 1.2;
  g.add(coat);

  // Shoulders
  const shoulders = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.22, 0.32), suit);
  shoulders.position.y = 1.8;
  g.add(shoulders);

  // Hanging arms
  for (const x of [-0.42, 0.42]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.72, 3, 6), suit);
    arm.position.set(x, 1.1, 0);
    g.add(arm);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.08, 6, 5), skin);
    hand.position.set(x, 0.65, 0);
    g.add(hand);
  }

  // Gaunt head
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 0.22, 6), skin);
  neck.position.y = 2.0;
  g.add(neck);
  
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.26, 10, 8), skin);
  head.scale.set(0.8, 1.3, 0.75);
  head.position.y = 2.28;
  g.add(head);

  // Cheekbones
  for (const x of [-0.14, 0.14]) {
    const ch = new THREE.Mesh(new THREE.SphereGeometry(0.09, 6, 4), skinD);
    ch.scale.set(1, 0.4, 0.3);
    ch.position.set(x, 2.1, -0.18);
    g.add(ch);
  }

  // HUGE staring eyes
  for (const x of [-0.11, 0.11]) {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.095, 8, 6), eyeW);
    e.scale.z = 0.4;
    e.position.set(x, 2.32, -0.24);
    g.add(e);
    const p = new THREE.Mesh(new THREE.SphereGeometry(0.04, 6, 5), pupil);
    p.position.set(x, 2.32, -0.28);
    g.add(p);
  }

  // Blood dripping from mouth
  const drip = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.16, 0.02), blood);
  drip.position.set(0.06, 1.92, -0.25);
  g.add(drip);

  return g;
}

// ✓ IMPROVED: Menacing gaze beast
function createGazeBeastMesh() {
  const g = new THREE.Group();
  const fur = mat(0x1a1512);
  const furD = mat(0x0a0808);
  const muzzle = mat(0x4a3840);
  const eye = mat(0xff3300, 0xcc0000, 0.9);
  const claw = mat(0x2a2018);

  const hip = new THREE.Mesh(new THREE.SphereGeometry(0.42, 8, 6), furD);
  hip.scale.set(1.2, 0.95, 1.1);
  hip.position.set(0, 0.6, 0.2);
  g.add(hip);

  const torso = new THREE.Mesh(new THREE.SphereGeometry(0.45, 8, 6), fur);
  torso.scale.set(1.2, 1.25, 0.8);
  torso.rotation.x = -0.55;
  torso.position.set(0, 1.05, -0.1);
  g.add(torso);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.36, 8, 6), fur);
  head.position.set(0, 1.65, -0.4);
  g.add(head);

  const snout = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.55, 7), muzzle);
  snout.rotation.x = Math.PI / 2;
  snout.position.set(0, 1.55, -0.72);
  g.add(snout);

  // Many glowing eyes in predatory pattern
  const eyePositions = [[-0.18, 1.68, -0.58], [0.18, 1.68, -0.58], [-0.12, 1.54, -0.65], [0.12, 1.54, -0.65],
    [-0.24, 1.5, -0.55], [0.24, 1.5, -0.55], [-0.06, 1.75, -0.5], [0.06, 1.75, -0.5]];
  eyePositions.forEach(p => {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.045, 5, 4), eye);
    e.position.set(p[0], p[1], p[2]);
    g.add(e);
  });

  // Claws
  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.78, 3, 6), fur);
    arm.position.set(s * 0.5, 0.95, -0.2);
    arm.rotation.z = s * 0.4;
    g.add(arm);
    const claw1 = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.15, 4), claw);
    claw1.rotation.x = Math.PI / 2;
    claw1.position.set(s * 0.62, 0.45, -0.32);
    g.add(claw1);
    const claw2 = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.15, 4), claw);
    claw2.rotation.x = Math.PI / 2;
    claw2.position.set(s * 0.68, 0.42, -0.28);
    g.add(claw2);
  }

  // Back legs
  for (const s of [-1, 1]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.12, 0.5, 3, 6), furD);
    leg.position.set(s * 0.28, 0.38, 0.2);
    g.add(leg);
  }

  return g;
}

// ✓ IMPROVED: Rotting zombie
function createHungryZombieMesh() {
  const g = new THREE.Group();
  const skin = mat(0x5a6a4a);
  const skinD = mat(0x2a3525);
  const shirt = mat(0x4a4a42);
  const pants = mat(0x1a1a20);
  const blood = mat(0x7a1010, 0x440000, 0.5);
  const teeth = mat(0xd8c0a0);

  // Legs
  for (const x of [-0.16, 0.16]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.11, 0.62, 3, 6), pants);
    leg.position.set(x, 0.48, 0);
    g.add(leg);
  }

  // Torso
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 0.85, 8), shirt);
  body.position.y = 0.95;
  g.add(body);

  // Open chest — horror detail
  const chest = new THREE.Mesh(new THREE.ConeGeometry(0.25, 0.32, 8), blood);
  chest.position.set(0, 1.2, 0.15);
  g.add(chest);

  // Ribs showing
  for (let i = 0; i < 3; i++) {
    const rib = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.04, 0.08), blood);
    rib.position.set(0, 0.85 + i * 0.15, 0.18);
    g.add(rib);
  }

  // Reaching arms
  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.7, 3, 6), skin);
    arm.position.set(s * 0.38, 1.0, 0.08);
    arm.rotation.z = s * 0.6;
    g.add(arm);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.09, 5, 4), skinD);
    hand.position.set(s * 0.6, 0.5, 0.25);
    g.add(hand);
  }

  // Head
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 6), skin);
  head.position.y = 1.8;
  g.add(head);

  // Open mouth
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.08, 0.04), skinD);
  mouth.position.set(0, 1.72, -0.2);
  g.add(mouth);

  // Teeth
  for (let i = 0; i < 4; i++) {
    const tooth = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.05, 0.02), teeth);
    tooth.position.set(-0.06 + i * 0.04, 1.68, -0.22);
    g.add(tooth);
  }

  return g;
}

// ✓ NEW: Backwatcher (tall, backwards-facing)
function createBackwatcherMesh() {
  const g = new THREE.Group();
  const dark = mat(0x0a0a0a);
  const coat = mat(0x1a1a22);
  const back_skin = mat(0xa8a098);

  // Elongated body
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.25, 1.4, 4, 8), coat);
  body.position.y = 1.3;
  g.add(body);

  // Long legs (backwards)
  for (const x of [-0.12, 0.12]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 1.1, 3, 6), dark);
    leg.position.set(x, 0.6, 0);
    g.add(leg);
  }

  // Head (backwards-facing — no front features)
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.24, 8, 6), back_skin);
  head.position.y = 2.2;
  g.add(head);

  // Long hair
  const hair = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.22, 0.8, 8), dark);
  hair.position.set(0, 2.7, 0.15);
  g.add(hair);

  return g;
}

// ✓ NEW: Pale Woman (elegant but wrong)
function createPaleGirlMesh() {
  const g = new THREE.Group();
  const dress = mat(0x2a2a32);
  const skin = mat(0xf0f0e0);
  const hair = mat(0x1a1a1a);

  // Dress
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.35, 0.95, 8), dress);
  body.position.y = 0.95;
  g.add(body);

  // Legs
  for (const x of [-0.1, 0.1]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.065, 0.9, 3, 6), skin);
    leg.position.set(x, 0.5, 0);
    g.add(leg);
  }

  // Long arms
  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 1.0, 3, 6), skin);
    arm.position.set(s * 0.4, 1.15, 0);
    arm.rotation.z = s * 0.3;
    g.add(arm);
  }

  // Head
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.26, 8, 6), skin);
  head.position.y = 2.0;
  g.add(head);

  // Long hair
  const h = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.24, 1.2, 8), hair);
  h.position.set(0, 2.4, 0);
  g.add(h);

  return g;
}

// ✓ NEW: Creepy Toy Doll
function createToyGirlMesh() {
  const g = new THREE.Group();
  const porcelain = mat(0xf5f5f0);
  const dress_mat = mat(0xff69b4);
  const crack = mat(0x3a3a3a);

  // Body
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.35, 0.2), dress_mat);
  body.position.y = 0.3;
  g.add(body);

  // Head (porcelain, cracked)
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 6), porcelain);
  head.position.y = 0.78;
  g.add(head);

  // Cracks on face
  const crack1 = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.15, 0.02), crack);
  crack1.position.set(-0.08, 0.85, -0.15);
  crack1.rotation.z = -0.4;
  g.add(crack1);

  const crack2 = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.18, 0.02), crack);
  crack2.position.set(0.08, 0.8, -0.15);
  crack2.rotation.z = 0.35;
  g.add(crack2);

  // Eyes (empty)
  for (const x of [-0.07, 0.07]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.035, 5, 4), crack);
    eye.position.set(x, 0.85, -0.18);
    g.add(eye);
  }

  // Mouth (stitched)
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.02, 0.02), crack);
  mouth.position.set(0, 0.65, -0.18);
  g.add(mouth);

  // Arms
  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.04, 0.3, 3, 4), dress_mat);
    arm.position.set(s * 0.2, 0.45, 0);
    g.add(arm);
  }

  // Legs
  for (const s of [-1, 1]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.045, 0.25, 3, 4), porcelain);
    leg.position.set(s * 0.08, 0.1, 0);
    g.add(leg);
  }

  return g;
}

// ✓ NEW: Blood Crier (skeletal, weeping)
function createBloodCrierMesh() {
  const g = new THREE.Group();
  const bone = mat(0xd0c0b0);
  const boneD = mat(0x6a5a4a);
  const blood = mat(0x8a0000, 0x440000, 0.6);

  // Skeletal body
  const spine = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.85, 0.1), boneD);
  spine.position.y = 0.95;
  g.add(spine);

  // Ribs
  for (let i = 0; i < 5; i++) {
    const rib = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.05, 0.1), bone);
    rib.position.set(0, 0.6 + i * 0.2, 0);
    g.add(rib);
  }

  // Skull
  const skull = new THREE.Mesh(new THREE.SphereGeometry(0.28, 10, 8), bone);
  skull.scale.set(1.0, 1.15, 0.9);
  skull.position.y = 2.0;
  g.add(skull);

  // Eye holes (empty)
  for (const x of [-0.11, 0.11]) {
    const eye_hole = new THREE.Mesh(new THREE.SphereGeometry(0.05, 5, 4), boneD);
    eye_hole.position.set(x, 2.15, -0.18);
    g.add(eye_hole);
  }

  // Tears of blood
  for (const x of [-0.11, 0.11]) {
    for (let i = 0; i < 2; i++) {
      const tear = new THREE.Mesh(new THREE.SphereGeometry(0.025, 4, 4), blood);
      tear.position.set(x, 2.05 - i * 0.15, -0.2);
      g.add(tear);
    }
  }

  // Arms (bone)
  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.75, 3, 6), bone);
    arm.position.set(s * 0.35, 1.25, 0);
    g.add(arm);
  }

  // Legs
  for (const s of [-1, 1]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.9, 3, 6), boneD);
    leg.position.set(s * 0.15, 0.5, 0);
    g.add(leg);
  }

  return g;
}

// ✓ NEW: Shadow Step (dark liquid form)
function createShadowStepMesh() {
  const g = new THREE.Group();
  const shadow = mat(0x050505, 0x000000, 0.1);

  // Liquid form — amorphous blob that suggests a figure
  const main = new THREE.Mesh(new THREE.SphereGeometry(0.4, 8, 6), shadow);
  main.scale.set(0.9, 1.2, 0.7);
  main.position.y = 0.8;
  g.add(main);

  // Head suggestion
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 6, 5), shadow);
  head.position.y = 1.6;
  g.add(head);

  // Tendrils
  for (let i = 0; i < 3; i++) {
    const tendril = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.5, 3, 6), shadow);
    const angle = (i / 3) * Math.PI * 2;
    tendril.position.set(Math.cos(angle) * 0.4, 0.3 + Math.sin(angle) * 0.3, Math.sin(angle) * 0.2);
    g.add(tendril);
  }

  return g;
}

// ✓ NEW: Whisper Doll (small phonograph-like)
function createWhisperDollMesh() {
  const g = new THREE.Group();
  const metal = mat(0x2a2a2a);
  const wood_mat = mat(0x6a4a3a);
  const horn = mat(0xd4a84b);

  // Main body (cylinder base)
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.38, 0.4, 10), wood_mat);
  base.position.y = 0.25;
  g.add(base);

  // Rotating horn (cone pointing up)
  const horn_mesh = new THREE.Mesh(new THREE.ConeGeometry(0.25, 0.5, 8), horn);
  horn_mesh.position.y = 0.7;
  g.add(horn_mesh);

  // Crank handle
  const crank = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.3, 0.08), metal);
  crank.position.set(0.35, 0.35, 0);
  g.add(crank);

  // Small doll head on top
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.15, 6, 5), mat(0xf5f5f0));
  head.position.y = 0.95;
  g.add(head);

  return g;
}

function setupKeys() {
  const on = (e, p) => {
    switch (e.code) {
      case 'KeyW': case 'ArrowUp':    move.f = p; break;
      case 'KeyS': case 'ArrowDown':  move.b = p; break;
      case 'KeyA': case 'ArrowLeft':  move.l = p; break;
      case 'KeyD': case 'ArrowRight': move.r = p; break;
      case 'KeyE': case 'Space': if (p) tryInteract(); break;
      case 'KeyQ': case 'KeyF': if (p) tryStun(); break;
    }
  };
  addEventListener('keydown', e => on(e, true));
  addEventListener('keyup', e => on(e, false));
}

function setupMobile() {
  const base = document.getElementById('joystick-base');
  const stick = document.getElementById('joystick-stick');
  const interactBtn = document.getElementById('interact-btn');
  const stunBtn = document.getElementById('stun-btn');

  let joyId = null;
  let lookId = null;
  let lastX = 0, lastY = 0;

  function inJoystick(clientX, clientY) {
    const w = window.innerWidth || 360;
    const h = window.innerHeight || 640;
    return clientX < w * 0.34 && clientY > h * 0.72;
  }

  function inButton(clientX, clientY) {
    const w = window.innerWidth || 360;
    const h = window.innerHeight || 640;
    return clientX > w * 0.62 && clientY > h * 0.72;
  }

  document.addEventListener('touchstart', e => {
    for (const t of e.changedTouches) {
      if (inJoystick(t.clientX, t.clientY)) {
        joyId = t.identifier;
        e.preventDefault();
        continue;
      }
      if (inButton(t.clientX, t.clientY)) continue;
      lookId = t.identifier;
      lastX = t.clientX;
      lastY = t.clientY;
      e.preventDefault();
    }
  }, { passive: false, capture: true });

  document.addEventListener('touchmove', e => {
    let used = false;
    // ✓ FIX: Proper look sensitivity calibration
    const sens = 0.002 * 18; // ~0.036 per pixel
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        used = true;
        const w = window.innerWidth || 360;
        const h = window.innerHeight || 640;
        const cx = w * 0.17;
        const cy = h * 0.86;
        const max = Math.min(w, h) * 0.12;
        let dx = t.clientX - cx, dy = t.clientY - cy;
        const len = Math.hypot(dx, dy) || 1;
        if (len > max) { dx = dx / len * max; dy = dy / len * max; }
        if (stick) stick.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
        joy.x = dx / max;
        joy.y = -dy / max;
      }
      if (t.identifier === lookId) {
        used = true;
        lookD.x += (t.clientX - lastX) * sens;
        lookD.y += (t.clientY - lastY) * sens;
        lastX = t.clientX;
        lastY = t.clientY;
      }
    }
    if (used) e.preventDefault();
  }, { passive: false, capture: true });

  const endTouch = e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        joyId = null;
        if (stick) stick.style.transform = 'translate(-50%, -50%)';
        joy.x = 0;
        joy.y = 0;
      }
      if (t.identifier === lookId) lookId = null;
    }
  };
  document.addEventListener('touchend', endTouch, { capture: true });
  document.addEventListener('touchcancel', endTouch, { capture: true });

  if (interactBtn) {
    const doI = (e) => { e.preventDefault(); e.stopPropagation(); tryInteract(); };
    interactBtn.addEventListener('touchend', doI, { passive: false });
    interactBtn.addEventListener('click', doI);
  }
  if (stunBtn) {
    const doS = (e) => { e.preventDefault(); e.stopPropagation(); tryStun(); };
    stunBtn.addEventListener('touchend', doS, { passive: false });
    stunBtn.addEventListener('click', doS);
  }

  const onOrient = () => {
    if (!camera || !renderer) return;
    const w = window.innerWidth;
    const h = window.innerHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
    renderer.setPixelRatio(1);
  };
  window.addEventListener('orientationchange', () => setTimeout(onOrient, 150));
  window.addEventListener('resize', onOrient);
}

function tryInteract() {
  if (gameOver) return;
  const uiOpen = elevatorUI && !elevatorUI.classList.contains('hidden');
  if (elevatorOpen && uiOpen) return;

  const mover = camera.position;
  const origin = camera.getWorldPosition(new THREE.Vector3());
  const dir = camera.getWorldDirection(new THREE.Vector3());
  raycaster.set(origin, dir);
  raycaster.far = 4.5;

  const hits = raycaster.intersectObjects(interactables, true);
  let obj = null;
  if (hits.length) {
    obj = hits[0].object;
    while (obj && !(obj.userData && obj.userData.type)) obj = obj.parent;
  }

  if (!obj || obj.userData.type !== 'room-door') {
    let bestDoor = null, bestD = 3.2;
    for (const o of interactables) {
      if (!o.userData || o.userData.type !== 'room-door') continue;
      const wp = new THREE.Vector3();
      o.getWorldPosition(wp);
      const d = wp.distanceTo(mover);
      if (d < bestD) { bestD = d; bestDoor = o; }
    }
    if (bestDoor && (!obj || obj.userData.type === 'elevator' || bestD < 2.5)) {
      obj = bestDoor;
    }
  }

  if (!obj) {
    const nearElev = interactables.find(o => {
      if (!o.userData || o.userData.type !== 'elevator') return false;
      const wp = new THREE.Vector3();
      o.getWorldPosition(wp);
      return wp.distanceTo(mover) < 3.5;
    });
    if (nearElev) obj = nearElev;
  }

  if (!obj) {
    showMsg('Nothing to interact');
    return;
  }

  const d = obj.userData;

  if (d.type === 'room-door') {
    toggleRoomDoor(obj);
    return;
  }
  if (d.type === 'part' && !d.collected) {
    d.collected = true;
    collectedParts.add(d.id);
    partsCollected = collectedParts.size;
    if (partsEl) partsEl.textContent = `Parts: ${partsCollected} / ${TOTAL_PARTS}`;
    obj.visible = false;
    showMsg(`Part ${d.id} collected!`);
    if (partsCollected >= TOTAL_PARTS) {
      const ob = document.getElementById('objective');
      if (ob) ob.textContent = 'All parts found! Go to the roof and fix the helicopter.';
    }
    return;
  }
  if (d.type === 'floor-btn') {
    startElevatorRide(d.targetFloor);
    return;
  }
  if (d.type === 'elevator' || d.type === 'elevator-btn') {
    openElevatorUI();
    return;
  }
  if (d.type === 'item') {
    holdingItem = d.item;
    obj.visible = false;
    showMsg(`Picked up ${d.item}`);
    return;
  }
  if (d.type === 'box' && holdingItem === 'toy') {
    holdingItem = null;
    showMsg('Toy placed. Toy Girl is calm.');
    return;
  }
  if (d.type === 'monster') {
    handleMonsterInteract(obj);
  }
}

function toggleRoomDoor(obj) {
  let target = obj;
  if (obj.parent && obj.parent.userData && obj.parent.userData.type === 'room-door') {
    target = obj.parent;
  }
  const d = target.userData;
  if (d.endDoor) {
    // ✓ FIX: Slide panel up (into lintel) not sideways
    const panel = target.children[0];
    if (!panel) return;
    if (!d.open) {
      d.open = true;
      if (obj.userData) obj.userData.open = true;
      panel.position.y = 3.8;
      showMsg((d.label || 'Door') + ' opened');
    } else {
      d.open = false;
      if (obj.userData) obj.userData.open = false;
      panel.position.y = CONFIG.floorHeight / 2 - 0.1;
      showMsg((d.label || 'Door') + ' closed');
    }
    return;
  }
  if (d.closedX === undefined) d.closedX = target.position.x;
  if (!d.open) {
    d.open = true;
    if (obj.userData) obj.userData.open = true;
    target.position.x = d.closedX + 2.6;
    showMsg((d.label || 'Door') + ' opened');
  } else {
    d.open = false;
    if (obj.userData) obj.userData.open = false;
    target.position.x = d.closedX;
    showMsg((d.label || 'Door') + ' closed');
  }
}

function openElevatorUI() {
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (!ui) {
    showMsg('Elevator UI missing');
    return;
  }
  elevatorOpen = true;
  const box = document.getElementById('elevator-buttons');
  if (box && box.children.length === 0) {
    for (let i = 1; i <= 10; i++) {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = String(i);
      b.addEventListener('click', (e) => { e.preventDefault(); goToFloor(i); });
      b.addEventListener('touchend', (e) => { e.preventDefault(); goToFloor(i); }, { passive: false });
      box.appendChild(b);
    }
    const roofBtn = document.createElement('button');
    roofBtn.type = 'button';
    roofBtn.textContent = 'ROOF';
    roofBtn.addEventListener('click', (e) => { e.preventDefault(); goToFloor('roof'); });
    roofBtn.addEventListener('touchend', (e) => { e.preventDefault(); goToFloor('roof'); }, { passive: false });
    box.appendChild(roofBtn);
  }
  if (box) {
    [...box.querySelectorAll('button')].forEach(b => {
      b.classList.remove('current');
      if (String(currentFloor) === b.textContent || (currentFloor === 'Roof' && b.textContent === 'ROOF')) {
        b.classList.add('current');
      }
    });
  }
  const label = document.getElementById('elevator-current');
  if (label) label.textContent = currentFloor === 'Roof' ? 'Now: Roof' : `Now: Floor ${currentFloor}`;
  ui.classList.remove('hidden');
  showMsg('Choose a floor');
}

function startElevatorRide(target) {
  if (ridingElevator || gameOver) return;
  if (target !== 'roof' && Number(target) === Number(currentFloor)) {
    showMsg('Already here');
    return;
  }
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (ui) ui.classList.add('hidden');
  elevatorOpen = false;

  ridingElevator = true;
  rideTarget = target;
  ridePhase = 'loading';
  rideTimer = 2.0;
  const label = target === 'roof' ? 'Roof' : ('Floor ' + target);
  showFloorLoading('Traveling to ' + label);
  showMsg('Loading…');
}

function goToFloor(f) {
  startElevatorRide(f);
}

function updateElevatorRide(dt) {
  if (!ridingElevator) return;
  rideTimer -= dt;
  if (rideTimer > 0) return;

  if (ridePhase === 'loading') {
    if (scene.userData.roofGroup) scene.userData.roofGroup.visible = false;
    unloadCurrentFloor();

    const mover = camera;
    if (rideTarget === 'roof') {
      if (scene.userData.roofGroup) scene.userData.roofGroup.visible = true;
      mover.position.set(0, CONFIG.playerHeight, 0);
      currentFloor = 'Roof';
      if (floorInd) floorInd.textContent = 'Roof';
      showMsg('Roof');
      if (partsCollected >= TOTAL_PARTS) {
        setTimeout(() => {
          if (winScreen) winScreen.classList.remove('hidden');
          gameOver = true;
        }, 600);
      } else {
        showMsg('Need all 10 parts');
      }
    } else {
      const floorNum = Number(rideTarget);
      loadFloor(floorNum);
      placePartsForFloor(floorNum);
      placeMonstersForFloor(floorNum);
      const side = mover.position.x >= 0 ? 1 : -1;
      const halfL = CONFIG.corridorLength / 2;
      mover.position.set(side * (halfL - 1.5), CONFIG.playerHeight, 0);
      showMsg('Floor ' + floorNum);
    }
    hideFloorLoading();
    ridingElevator = false;
    ridePhase = null;
  }
}

function handleMonsterInteract(m) {
  const k = m.userData.kind;
  if (k === 'hungry' && holdingItem === 'meat') {
    holdingItem = null;
    m.userData.alive = false;
    m.visible = false;
    showMsg('Fed the Hungry Zombie.');
  } else if (k === 'whisper') {
    showMsg('Whisper silenced…');
    m.userData.state = 'calm';
  } else {
    showMsg(m.userData.desc);
  }
}

function updateMonsters(dt) {
  if (gameOver) return;
  const playerPos = (isMobile || !controls) ? camera.position : controls.getObject().position;
  const halfL = CONFIG.corridorLength / 2;
  playerInRoom = Math.abs(playerPos.x) > halfL - 0.5;

  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor !== currentFloor && currentFloor !== 'Roof') return;
    if (!playerInRoom && currentFloor !== 'Roof') {
      m.lookAt(playerPos.x, m.position.y, playerPos.z);
      return;
    }

    if (m.userData.stunned) return;

    const kind = m.userData.kind;
    const toPlayer = new THREE.Vector3().subVectors(playerPos, m.position);
    const dist = toPlayer.length();
    toPlayer.y = 0;
    toPlayer.normalize();

    const lookDir = camera.getWorldDirection(new THREE.Vector3());
    const toM = new THREE.Vector3().subVectors(m.position, camera.position).normalize();
    const lookingAt = lookDir.dot(toM) > 0.85 && dist < 12;

    if (kind === 'watcher') {
      if (lookingAt) {
        // frozen
      } else if (dist > 1.5) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      } else {
        kill('The Watcher touched you');
      }
    } else if (kind === 'gaze') {
      if (lookingAt) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 2) kill('Stared too long at the Gaze Beast');
      } else {
        m.userData.lookTimer = Math.max(0, m.userData.lookTimer - dt * 0.5);
      }
      if (dist > 2 && !lookingAt) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
    } else if (kind === 'hungry') {
      if (holdingItem === 'meat') {
        // passive — meat holder safe
      } else if (dist > 1.5) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      } else {
        kill('Hungry Zombie ate you');
      }
    } else if (kind === 'backtext') {
      if (lookingAt && Math.abs(m.position.x - playerPos.x) < 3) {
        kill('The Backwatcher sensed you looking');
      } else if (dist > 2) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      }
    } else if (kind === 'stalker') {
      if (dist > 2) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (dist > 0.2) {
        const block = new THREE.Vector3().copy(toPlayer).applyAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI / 2);
        m.position.addScaledVector(block, m.userData.speed * dt);
      }
      if (dist < 0.8) kill('Pale Woman cut you off');
    } else if (kind === 'toy') {
      if (holdingItem === 'toy' || m.userData.state === 'calm') {
        // calm
      } else if (dist > 2) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      } else {
        kill('Toy Doll got you');
      }
    } else if (kind === 'crier') {
      if (lookingAt) {
        // frozen
      } else if (dist > 2) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      } else {
        kill('Blood Crier touched you');
      }
    } else if (kind === 'shadowstep') {
      const moving = Math.abs(joy.x) + Math.abs(joy.y) > 0.1 || move.f || move.b || move.l || move.r;
      if (moving && dist > 1.5) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (!moving) {
        // frozen
      } else {
        kill('Shadow Step touched you');
      }
    } else if (kind === 'whisper') {
      if (m.userData.state !== 'calm' && dist < 4) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 4) kill('Whisper Doll's voice took you');
      }
    }
  });
}

function kill(reason) {
  if (gameOver) return;
  if (gameMode === 'peaceful') {
    showMsg('Peaceful mode — you survive');
    return;
  }
  gameOver = true;
  showMsg(reason, 5000);
  setTimeout(() => location.reload(), 3500);
}

function tryStun() {
  if (gameOver || stunCooldown > 0 || stunActive > 0) return;
  let hit = 0;
  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor === currentFloor || currentFloor === 'Roof') {
      m.userData.stunned = true;
      hit++;
    }
  });
  if (hit > 0) {
    stunActive = 3;
    stunCooldown = 15;
    showMsg(`Stunned ${hit} monsters!`);
  } else {
    showMsg('No monsters here');
    stunCooldown = 2;
  }
  updateStunUI();
}

function updateStunUI() {
  const desk = document.getElementById('stun-btn-desktop');
  const setState = (btn, text, disabled) => {
    if (!btn) return;
    btn.disabled = disabled;
    btn.textContent = text;
  };
  if (stunCooldown > 0) {
    const t = Math.ceil(stunCooldown) + 's';
    setState(stunBtn, t, true);
    setState(desk, t, true);
    if (stunCdEl) stunCdEl.textContent = 'Cooldown';
  } else if (stunActive > 0) {
    setState(stunBtn, 'ACTIVE', true);
    setState(desk, 'ACTIVE', true);
  } else {
    setState(stunBtn, 'STUN', false);
    setState(desk, 'STUN (Q)', false);
    if (stunCdEl) stunCdEl.textContent = 'Ready';
  }
}

const FPS_LIMIT = 40;
const FRAME_TIME = 1 / FPS_LIMIT;
let fpsAccum = 0;

function applyLook() {
  if (!camera) return;
  if (lookD.x === 0 && lookD.y === 0) return;
  camera.rotation.order = 'YXZ';
  camera.rotation.y -= lookD.x;
  camera.rotation.x -= lookD.y;
  camera.rotation.x = Math.max(-1.35, Math.min(1.35, camera.rotation.x));
  lookD.x = 0;
  lookD.y = 0;
}

function animate() {
  requestAnimationFrame(animate);
  const rawDt = clock.getDelta();

  applyLook();

  fpsAccum += rawDt;
  if (fpsAccum < FRAME_TIME) {
    if (renderer && scene && camera) renderer.render(scene, camera);
    return;
  }
  const dt = Math.min(fpsAccum, 0.05);
  fpsAccum = 0;

  if (gameOver) {
    renderer.render(scene, camera);
    return;
  }

  if (stunActive > 0) {
    stunActive -= dt;
    if (stunActive <= 0) {
      stunActive = 0;
      monsters.forEach(m => { m.userData.stunned = false; });
    }
  }
  if (stunCooldown > 0) {
    stunCooldown -= dt;
    if (stunCooldown < 0) stunCooldown = 0;
  }
  updateStunUI();

  const speed = ridingElevator ? 0 : CONFIG.playerSpeed * dt;
  const forward = new THREE.Vector3();
  const right = new THREE.Vector3();
  const mover = isMobile || !controls ? camera : controls.getObject();

  if (isMobile) {
    camera.getWorldDirection(forward);
    forward.y = 0;
    forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();
    mover.position.addScaledVector(forward, joy.y * speed);
    mover.position.addScaledVector(right, joy.x * speed);
  } else if (controls && controls.isLocked) {
    controls.getDirection(forward);
    forward.y = 0;
    forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();
    if (move.f) mover.position.addScaledVector(forward, speed);
    if (move.b) mover.position.addScaledVector(forward, -speed);
    if (move.l) mover.position.addScaledVector(right, -speed);
    if (move.r) mover.position.addScaledVector(right, speed);
  }

  // ✓ FIX: Proper Z bounds expansion when in rooms
  const inRoom = Math.abs(mover.position.x) > CONFIG.corridorLength / 2 - 0.2;
  const maxX = CONFIG.corridorLength / 2 + CONFIG.roomDepth - 0.4;
  const maxZ = inRoom ? (CONFIG.corridorWidth / 2 + 0.6) : (CONFIG.corridorWidth / 2 - 0.35);
  mover.position.x = Math.max(-maxX, Math.min(maxX, mover.position.x));
  mover.position.z = Math.max(-maxZ, Math.min(maxZ, mover.position.z));

  mover.position.y = CONFIG.playerHeight;

  updateElevatorRide(dt);

  {
    const pos = camera.position;
    let inElev = false;
    if (currentFloor !== 'Roof') {
      for (const el of elevators) {
        if (el.floor !== currentFloor) continue;
        const wp = new THREE.Vector3();
        el.group.getWorldPosition(wp);
        if (Math.abs(pos.x - wp.x) < 2.5 && Math.abs(pos.z - wp.z) < 2.2) {
          inElev = true;
          break;
        }
      }
      const halfW = CONFIG.corridorWidth / 2;
      if (Math.abs(Math.abs(pos.z) - halfW) < 2.2 && Math.abs(pos.x) < 3.0) {
        inElev = true;
      }
    }
    insideElevator = inElev;
    if (inElev && !elevPromptShown && !gameOver && !ridingElevator) {
      elevPromptShown = true;
      showMsg('INTERACT to open floor menu', 2000);
    }
    if (!inElev) elevPromptShown = false;
  }

  updateMonsters(dt);
  multiplayerTick(dt);

  parts.forEach(p => {
    if (!p.userData.collected) p.rotation.y += dt * 0.8;
  });

  renderer.render(scene, camera);
}

function setupUI() {
  const box = document.getElementById('elevator-buttons');
  if (box) box.innerHTML = '';
  for (let i = 1; i <= 10; i++) {
    const b = document.createElement('button');
    b.textContent = i;
    b.type = 'button';
    const go = (e) => { e.preventDefault(); goToFloor(i); };
    b.addEventListener('click', go);
    b.addEventListener('touchend', go, { passive: false });
    box.appendChild(b);
  }
  const roofBtn = document.createElement('button');
  roofBtn.textContent = 'ROOF';
  roofBtn.className = 'roof';
  roofBtn.type = 'button';
  const goRoof = (e) => { e.preventDefault(); goToFloor('roof'); };
  roofBtn.addEventListener('click', goRoof);
  roofBtn.addEventListener('touchend', goRoof, { passive: false });
  box.appendChild(roofBtn);

  document.getElementById('dialogue-close').onclick = () => dialogue.classList.add('hidden');
  document.getElementById('restart-btn').onclick = () => location.reload();

  if (stunBtn) {
    stunBtn.addEventListener('click', tryStun);
    stunBtn.addEventListener('touchstart', e => { e.preventDefault(); tryStun(); }, { passive: false });
  }
  const stunDesk = document.getElementById('stun-btn-desktop');
  if (stunDesk) {
    stunDesk.addEventListener('click', tryStun);
  }

  let p = 0;
  const iv = setInterval(() => {
    p += 15;
    progressEl.style.width = Math.min(p, 95) + '%';
    if (p >= 95) clearInterval(iv);
  }, 60);
}

init().catch(console.error);

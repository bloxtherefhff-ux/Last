import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

/* ============================================================
   SKYLINE HOTEL – 10 FLOORS
   Brighter atmosphere + monsters with counters
   ============================================================ */

const CONFIG = {
  floors: 10,
  floorHeight: 4.5,
  corridorWidth: 7,
  corridorLength: 32,
  playerHeight: 1.7,
  playerSpeed: 5.2
};

let scene, camera, renderer, controls;
let currentFloor = 1;
let partsCollected = 0;
const TOTAL_PARTS = 10;
let move = { f: false, b: false, l: false, r: false };
let isMobile = false;
let joy = { x: 0, y: 0 };
let lookD = { x: 0, y: 0 };
let interactables = [];
let monsters = [];
let parts = [];
let clock = new THREE.Clock();
let raycaster = new THREE.Raycaster();
let elevatorOpen = false;
let gameOver = false;
let holdingItem = null; // for toy / meat
let stunCooldown = 0;   // seconds remaining before stun can be used again
let stunActive = 0;     // seconds remaining of current stun

// DOM
const loadingEl = document.getElementById('loading');
const progressEl = document.getElementById('progress');
const hud = document.getElementById('hud');
const floorInd = document.getElementById('floor-indicator');
const partsEl = document.getElementById('parts');
const mobileControls = document.getElementById('mobile-controls');
const dialogue = document.getElementById('dialogue');
const npcNameEl = document.getElementById('npc-name');
const npcTextEl = document.getElementById('npc-text');
const winScreen = document.getElementById('win-screen');
const elevatorUI = document.getElementById('elevator-ui');
const msgEl = document.getElementById('msg');
const stunBtn = document.getElementById('stun-btn');
const stunCdEl = document.getElementById('stun-cd');

function showMsg(text, time = 3000) {
  msgEl.textContent = text;
  msgEl.classList.remove('hidden');
  setTimeout(() => msgEl.classList.add('hidden'), time);
}

async function init() {
  isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) || innerWidth < 900;

  scene = new THREE.Scene();
  // Much brighter background + almost no fog
  scene.background = new THREE.Color(0x3a3a50);
  scene.fog = new THREE.FogExp2(0x3a3a50, 0.008);

  camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.1, 90);
  camera.position.set(0, CONFIG.playerHeight, 12);

  renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setSize(innerWidth, innerHeight);
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  document.body.appendChild(renderer.domElement);

  // Very bright lighting – no dark hotel feel
  scene.add(new THREE.AmbientLight(0xffffff, 1.15));
  const hemi = new THREE.HemisphereLight(0xffffff, 0x8888aa, 1.0);
  scene.add(hemi);
  // Strong directional light so everything is clearly visible
  const dir = new THREE.DirectionalLight(0xfff8f0, 0.9);
  dir.position.set(5, 20, 10);
  scene.add(dir);

  buildHotel();
  placeParts();
  placeMonsters();
  placeNPCs();

  if (!isMobile) {
    controls = new PointerLockControls(camera, document.body);
    scene.add(controls.getObject());
    document.body.addEventListener('click', () => {
      if (!dialogue.classList.contains('hidden') || elevatorOpen || gameOver) return;
      controls.lock();
    });
  } else {
    setupMobile();
  }

  setupKeys();
  setupUI();

  progressEl.style.width = '100%';
  setTimeout(() => {
    loadingEl.classList.add('hidden');
    hud.classList.remove('hidden');
    if (isMobile) mobileControls.classList.remove('hidden');
  }, 700);

  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });

  animate();
}

/* -------------------- HOTEL -------------------- */
function buildHotel() {
  const wallMat = new THREE.MeshStandardMaterial({ color: 0x6a5e52, roughness: 0.75 });
  const floorMat = new THREE.MeshStandardMaterial({ color: 0x5a4e42, roughness: 0.85 });
  const ceilMat  = new THREE.MeshStandardMaterial({ color: 0x4a423a, roughness: 0.9 });
  const carpetMat = new THREE.MeshStandardMaterial({ color: 0x8a3a3a, roughness: 0.9 });
  const goldMat = new THREE.MeshStandardMaterial({ color: 0xd4a84b, metalness: 0.5, roughness: 0.35 });

  for (let f = 1; f <= CONFIG.floors; f++) {
    const y = (f - 1) * CONFIG.floorHeight;
    const g = new THREE.Group();
    g.position.y = y;

    // Floor
    const slab = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength + 18, 0.3, CONFIG.corridorWidth + 10),
      floorMat
    );
    slab.position.y = -0.15;
    slab.receiveShadow = true;
    g.add(slab);

    // Carpet
    const carpet = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength - 1, 0.02, 2.4),
      carpetMat
    );
    carpet.position.y = 0.01;
    g.add(carpet);

    // Ceiling
    const ceil = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength + 18, 0.2, CONFIG.corridorWidth + 10),
      ceilMat
    );
    ceil.position.y = CONFIG.floorHeight - 0.1;
    g.add(ceil);

    // Walls
    const h = CONFIG.floorHeight - 0.3;
    const long = new THREE.BoxGeometry(CONFIG.corridorLength + 2, h, 0.35);
    const n = new THREE.Mesh(long, wallMat); n.position.set(0, h/2, -CONFIG.corridorWidth/2); g.add(n);
    const s = new THREE.Mesh(long, wallMat); s.position.set(0, h/2,  CONFIG.corridorWidth/2); g.add(s);

    const end = new THREE.BoxGeometry(0.35, h, CONFIG.corridorWidth + 1);
    const e = new THREE.Mesh(end, wallMat); e.position.set( CONFIG.corridorLength/2 + 0.4, h/2, 0); g.add(e);
    const w = new THREE.Mesh(end, wallMat); w.position.set(-CONFIG.corridorLength/2 - 0.4, h/2, 0); g.add(w);

    // Room doors visual
    for (let i = -3; i <= 3; i++) {
      if (i === 0) continue;
      const door = new THREE.Mesh(
        new THREE.BoxGeometry(1.5, 2.5, 0.12),
        new THREE.MeshStandardMaterial({ color: 0x4a3525 })
      );
      door.position.set(i * 4.5, 1.25, i > 0 ? CONFIG.corridorWidth/2 - 0.1 : -CONFIG.corridorWidth/2 + 0.1);
      g.add(door);
    }

    // No small lamps – global bright lighting only

    // Elevator doors both ends
    createElevator(g,  CONFIG.corridorLength/2 - 0.3, f);
    createElevator(g, -CONFIG.corridorLength/2 + 0.3, f);

    // Floor number
    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 64;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#222'; ctx.fillRect(0,0,128,64);
    ctx.fillStyle = '#d4a84b'; ctx.font = 'bold 36px system-ui';
    ctx.textAlign = 'center'; ctx.fillText('F' + f, 64, 44);
    const tex = new THREE.CanvasTexture(canvas);
    const label = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.7), new THREE.MeshBasicMaterial({ map: tex }));
    label.position.set(0, 2.4, -CONFIG.corridorWidth/2 + 0.2);
    g.add(label);

    scene.add(g);
  }

  // Roof + helicopter
  const roofY = CONFIG.floors * CONFIG.floorHeight;
  const roof = new THREE.Group();
  roof.position.y = roofY;

  const roofSlab = new THREE.Mesh(
    new THREE.BoxGeometry(42, 0.4, 32),
    new THREE.MeshStandardMaterial({ color: 0x333333 })
  );
  roofSlab.position.y = 0.2;
  roof.add(roofSlab);

  const pad = new THREE.Mesh(
    new THREE.CylinderGeometry(6, 6, 0.15, 32),
    new THREE.MeshStandardMaterial({ color: 0x222222 })
  );
  pad.position.y = 0.35;
  roof.add(pad);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(4.5, 5, 32),
    new THREE.MeshBasicMaterial({ color: 0xd4a84b, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI/2;
  ring.position.y = 0.43;
  roof.add(ring);

  const heli = createHelicopter();
  heli.position.set(0, 1.9, 0);
  roof.add(heli);

  const rl = new THREE.PointLight(0xffffff, 1.4, 30);
  rl.position.set(0, 7, 0);
  roof.add(rl);

  scene.add(roof);
}

function createElevator(parent, x, floorNum) {
  const mat = new THREE.MeshStandardMaterial({ color: 0x555555, metalness: 0.55, roughness: 0.35 });
  const door = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.8, 2.2), mat);
  door.position.set(x, 1.4, 0);
  door.userData = { type: 'elevator', floor: floorNum };
  parent.add(door);
  interactables.push(door);

  // Big visible gold call button
  const btn = new THREE.Mesh(
    new THREE.BoxGeometry(0.35, 0.55, 0.2),
    new THREE.MeshStandardMaterial({ color: 0xd4a84b, emissive: 0x5a3a10, emissiveIntensity: 0.5 })
  );
  btn.position.set(x + (x > 0 ? -0.4 : 0.4), 1.45, 1.3);
  btn.userData = { type: 'elevator-btn', floor: floorNum };
  parent.add(btn);
  interactables.push(btn);

  // Invisible larger hitbox so it's easy to click
  const hit = new THREE.Mesh(
    new THREE.BoxGeometry(1.2, 3.0, 2.5),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hit.position.set(x, 1.5, 0);
  hit.userData = { type: 'elevator', floor: floorNum };
  parent.add(hit);
  interactables.push(hit);
}

function createHelicopter() {
  const g = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x2a2a2a, metalness: 0.5, roughness: 0.4 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(1, 2.4, 4, 12), bodyMat);
  body.rotation.z = Math.PI/2;
  g.add(body);
  const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.28, 3.2, 8), bodyMat);
  tail.rotation.z = Math.PI/2;
  tail.position.set(-2.8, 0.25, 0);
  g.add(tail);
  const rotor = new THREE.Mesh(new THREE.BoxGeometry(7.5, 0.1, 0.4), new THREE.MeshStandardMaterial({ color: 0x111 }));
  rotor.position.y = 1.25;
  g.add(rotor);
  return g;
}

/* -------------------- PARTS (1 per floor) -------------------- */
function placeParts() {
  for (let f = 1; f <= 10; f++) {
    const part = createPart(f);
    const y = (f - 1) * CONFIG.floorHeight + 0.5;
    const side = (f % 2 === 0) ? 1 : -1;
    part.position.set((Math.random() * 10 - 5), y, side * 1.8);
    part.userData = { type: 'part', id: f, collected: false, floor: f };
    scene.add(part);
    parts.push(part);
    interactables.push(part);
  }
}

function createPart(id) {
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({
    color: 0xd4a84b, metalness: 0.7, roughness: 0.3,
    emissive: 0x3a2a10, emissiveIntensity: 0.4
  });
  let mesh;
  if (id % 3 === 0) mesh = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.4, 0.55), mat);
  else if (id % 3 === 1) mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.65, 10), mat);
  else mesh = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.12, 8, 16), mat);
  g.add(mesh);
  const light = new THREE.PointLight(0xd4a84b, 0.7, 3.5);
  light.position.y = 0.3;
  g.add(light);
  return g;
}

/* -------------------- MONSTERS -------------------- */
function placeMonsters() {
  // 1 – Watcher: stops when looked at, follows otherwise
  addMonster({
    name: 'The Watcher',
    floor: 2,
    pos: [8, 0, 1.5],
    color: 0x4a2020,
    type: 'watcher',
    speed: 2.8,
    desc: 'Looks at you → freezes. Look away → he comes.'
  });

  // 2 – Gaze Beast: looking too long = death
  addMonster({
    name: 'Gaze Beast',
    floor: 3,
    pos: [-9, 0, -1.6],
    color: 0x2a4a2a,
    type: 'gaze',
    speed: 1.5,
    desc: 'Do not stare at it for more than 2 seconds.'
  });

  // 3 – Hungry Zombie: needs meat
  addMonster({
    name: 'Hungry Zombie',
    floor: 4,
    pos: [6, 0, 1.7],
    color: 0x3a5a3a,
    type: 'hungry',
    speed: 3.2,
    desc: 'Find the meat on this floor and give it to him.'
  });

  // 4 – Text Animal: “if you watch your back you die”
  addMonster({
    name: 'Backwatcher',
    floor: 5,
    pos: [-7, 0, -1.4],
    color: 0x5a3a1a,
    type: 'backtext',
    speed: 2.0,
    desc: 'Never look behind you while near it.'
  });

  // 5 – Black Suit Girl: stalks based on path
  addMonster({
    name: 'Pale Girl',
    floor: 6,
    pos: [4, 0, 1.8],
    color: 0x111111,
    type: 'stalker',
    speed: 2.4,
    desc: 'She predicts where you will go. Keep changing direction.'
  });

  // 6 – Toy Girl: needs toy put in box
  addMonster({
    name: 'Toy Girl',
    floor: 7,
    pos: [-5, 0, -1.7],
    color: 0x6a4a6a,
    type: 'toy',
    speed: 1.8,
    desc: 'Find the toy and put it in the box. She will then show the part.'
  });

  // 7 – Blood Crier (invented counter: look him in the eyes while standing still)
  addMonster({
    name: 'Blood Crier',
    floor: 8,
    pos: [9, 0, 1.3],
    color: 0xffffff,
    type: 'crier',
    speed: 2.6,
    desc: 'Stand still and look directly at his face to calm him.'
  });

  // 8 – Shadow Step (new): only moves when you move
  addMonster({
    name: 'Shadow Step',
    floor: 9,
    pos: [-8, 0, 1.5],
    color: 0x1a1a2a,
    type: 'shadowstep',
    speed: 4.0,
    desc: 'He only moves when YOU move. Stand still to freeze him.'
  });

  // 9 – Whisper Doll (new): must answer by interacting with the correct door
  addMonster({
    name: 'Whisper Doll',
    floor: 1,
    pos: [0, 0, -2],
    color: 0x8a6a4a,
    type: 'whisper',
    speed: 1.2,
    desc: 'When she whispers, interact with the left elevator button to silence her.'
  });
}

function addMonster(data) {
  const m = createMonsterMesh(data.color, data.name);
  const y = (data.floor - 1) * CONFIG.floorHeight;
  m.position.set(data.pos[0], y, data.pos[2]);
  m.userData = {
    type: 'monster',
    kind: data.type,
    name: data.name,
    speed: data.speed,
    floor: data.floor,
    alive: true,
    lookTimer: 0,
    state: 'idle',
    desc: data.desc
  };
  scene.add(m);
  monsters.push(m);
  interactables.push(m);
}

function createMonsterMesh(color, name) {
  const g = new THREE.Group();

  // Tall thin twisted body
  const bodyMat = new THREE.MeshStandardMaterial({
    color,
    roughness: 0.55,
    metalness: 0.15,
    emissive: color,
    emissiveIntensity: 0.12
  });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.38, 1.35, 6, 12), bodyMat);
  body.position.y = 1.35;
  body.scale.x = 0.85;
  g.add(body);

  // Shoulders / cloak mass
  const shoulders = new THREE.Mesh(
    new THREE.BoxGeometry(1.05, 0.35, 0.5),
    new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.9 })
  );
  shoulders.position.y = 1.85;
  g.add(shoulders);

  // Long arms
  const armMat = new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.8 });
  const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.9, 4, 6), armMat);
  armL.position.set(-0.55, 1.3, 0.1);
  armL.rotation.z = 0.4;
  g.add(armL);
  const armR = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.9, 4, 6), armMat);
  armR.position.set(0.55, 1.3, 0.1);
  armR.rotation.z = -0.4;
  g.add(armR);

  // Head – elongated + tilted
  const headColor = color === 0xffffff ? 0xf0e8e0 : 0xb8957a;
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.34, 14, 12),
    new THREE.MeshStandardMaterial({ color: headColor, roughness: 0.65 })
  );
  head.position.y = 2.25;
  head.scale.set(0.95, 1.15, 0.9);
  g.add(head);

  // Glowing red eyes
  const eyeMat = new THREE.MeshStandardMaterial({
    color: 0xff0000,
    emissive: 0xff0000,
    emissiveIntensity: 2.5,
    toneMapped: false
  });
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 6), eyeMat);
  eyeL.position.set(-0.12, 2.28, 0.28);
  g.add(eyeL);
  const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 6), eyeMat);
  eyeR.position.set(0.12, 2.28, 0.28);
  g.add(eyeR);

  // Eye glow lights
  const el = new THREE.PointLight(0xff2200, 0.8, 4);
  el.position.set(0, 2.3, 0.4);
  g.add(el);

  // Jagged mouth
  const mouth = new THREE.Mesh(
    new THREE.BoxGeometry(0.28, 0.06, 0.08),
    new THREE.MeshStandardMaterial({ color: 0x1a0000 })
  );
  mouth.position.set(0, 2.08, 0.3);
  g.add(mouth);

  // Hair / tendrils for extra horror
  const hairMat = new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: 0.95 });
  for (let i = 0; i < 5; i++) {
    const strand = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.7, 5), hairMat);
    strand.position.set((i - 2) * 0.12, 2.55, -0.05);
    strand.rotation.x = 0.3 + Math.random() * 0.4;
    strand.rotation.z = (i - 2) * 0.15;
    g.add(strand);
  }

  // Name plate
  const canvas = document.createElement('canvas');
  canvas.width = 256; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(20,0,0,0.75)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.strokeStyle = '#ff3333';
  ctx.lineWidth = 3;
  ctx.strokeRect(2, 2, 252, 60);
  ctx.fillStyle = '#ff4444';
  ctx.font = 'bold 24px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText(name, 128, 40);
  const tex = new THREE.CanvasTexture(canvas);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  spr.scale.set(2.1, 0.52, 1);
  spr.position.y = 3.0;
  g.add(spr);

  return g;
}

/* -------------------- ITEMS for counters -------------------- */
function placeNPCs() {
  // Meat on floor 4
  const meat = createItem(0x8b0000, 'meat');
  meat.position.set(-4, (4-1)*CONFIG.floorHeight + 0.4, 1.5);
  meat.userData = { type: 'item', item: 'meat' };
  scene.add(meat);
  interactables.push(meat);

  // Toy on floor 7
  const toy = createItem(0xff69b4, 'toy');
  toy.position.set(7, (7-1)*CONFIG.floorHeight + 0.4, -1.6);
  toy.userData = { type: 'item', item: 'toy' };
  scene.add(toy);
  interactables.push(toy);

  // Box on floor 7
  const box = new THREE.Mesh(
    new THREE.BoxGeometry(0.8, 0.5, 0.8),
    new THREE.MeshStandardMaterial({ color: 0x5a3a1a })
  );
  box.position.set(-2, (7-1)*CONFIG.floorHeight + 0.3, 1.7);
  box.userData = { type: 'box' };
  scene.add(box);
  interactables.push(box);
}

function createItem(color, name) {
  const g = new THREE.Group();
  const m = new THREE.Mesh(
    new THREE.SphereGeometry(0.25, 10, 8),
    new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.3 })
  );
  g.add(m);
  const light = new THREE.PointLight(color, 0.6, 2.5);
  g.add(light);
  return g;
}

/* -------------------- CONTROLS -------------------- */
function setupKeys() {
  const on = (e, p) => {
    switch (e.code) {
      case 'KeyW': case 'ArrowUp':    move.f = p; break;
      case 'KeyS': case 'ArrowDown':  move.b = p; break;
      case 'KeyA': case 'ArrowLeft':  move.l = p; break;
      case 'KeyD': case 'ArrowRight': move.r = p; break;
      case 'KeyE': case 'Space': if (p) tryInteract(); break;
      case 'KeyQ': case 'KeyF': if (p) tryStun(); break;
    }
  };
  addEventListener('keydown', e => on(e, true));
  addEventListener('keyup',   e => on(e, false));
}

function setupMobile() {
  const base = document.getElementById('joystick-base');
  const stick = document.getElementById('joystick-stick');
  const lookZone = document.getElementById('look-zone');
  const interactBtn = document.getElementById('interact-btn');

  let joyId = null, lookId = null, last = { x:0, y:0 };

  base.addEventListener('touchstart', e => {
    e.preventDefault();
    joyId = e.changedTouches[0].identifier;
  }, { passive: false });

  addEventListener('touchmove', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        const r = base.getBoundingClientRect();
        const cx = r.left + r.width/2, cy = r.top + r.height/2;
        let dx = t.clientX - cx, dy = t.clientY - cy;
        const max = r.width/2 - 8;
        const len = Math.hypot(dx, dy);
        if (len > max) { dx = dx/len*max; dy = dy/len*max; }
        stick.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
        joy.x = dx / max;
        joy.y = -dy / max;
      }
      if (t.identifier === lookId) {
        lookD.x += (t.clientX - last.x) * 0.004;
        lookD.y += (t.clientY - last.y) * 0.004;
        last.x = t.clientX; last.y = t.clientY;
      }
    }
  }, { passive: false });

  addEventListener('touchend', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        joyId = null;
        stick.style.transform = 'translate(-50%, -50%)';
        joy.x = 0; joy.y = 0;
      }
      if (t.identifier === lookId) lookId = null;
    }
  });

  lookZone.addEventListener('touchstart', e => {
    e.preventDefault();
    lookId = e.changedTouches[0].identifier;
    last.x = e.changedTouches[0].clientX;
    last.y = e.changedTouches[0].clientY;
  }, { passive: false });

  interactBtn.addEventListener('touchstart', e => {
    e.preventDefault();
    tryInteract();
  }, { passive: false });
}

/* -------------------- INTERACTION + ELEVATOR -------------------- */
function tryInteract() {
  if (gameOver || elevatorOpen) return;

  const origin = camera.getWorldPosition(new THREE.Vector3());
  const dir = camera.getWorldDirection(new THREE.Vector3());
  raycaster.set(origin, dir);
  raycaster.far = 4.0;

  const hits = raycaster.intersectObjects(interactables, true);
  let obj = null;
  if (hits.length) {
    obj = hits[0].object;
    while (obj && !obj.userData.type) obj = obj.parent;
  }

  // Proximity fallback for elevators (so it always works near doors)
  if (!obj || (obj.userData.type !== 'elevator' && obj.userData.type !== 'elevator-btn')) {
    const mover = isMobile || !controls ? camera.position : controls.getObject().position;
    const nearElev = interactables.find(o => {
      if (!o.userData || (o.userData.type !== 'elevator' && o.userData.type !== 'elevator-btn')) return false;
      const wp = new THREE.Vector3();
      o.getWorldPosition(wp);
      return wp.distanceTo(mover) < 3.5 && Math.abs(wp.y - mover.y) < 2.5;
    });
    if (nearElev) obj = nearElev;
  }

  if (!obj) return;
  const d = obj.userData;

  if (d.type === 'part' && !d.collected) {
    d.collected = true;
    partsCollected++;
    partsEl.textContent = `Parts: ${partsCollected} / ${TOTAL_PARTS}`;
    obj.visible = false;
    showMsg(`Part ${d.id} collected!`);
    if (partsCollected >= TOTAL_PARTS) {
      document.getElementById('objective').textContent = 'All parts found! Go to the roof and fix the helicopter.';
    }
  }
  else if (d.type === 'elevator' || d.type === 'elevator-btn') {
    openElevatorUI();
  }
  else if (d.type === 'item') {
    holdingItem = d.item;
    obj.visible = false;
    showMsg(`Picked up ${d.item}`);
  }
  else if (d.type === 'box' && holdingItem === 'toy') {
    holdingItem = null;
    showMsg('Toy placed in the box. Toy Girl is calm and shows the part.');
  }
  else if (d.type === 'monster') {
    handleMonsterInteract(obj);
  }
}

function openElevatorUI() {
  elevatorOpen = true;
  if (controls && controls.isLocked) controls.unlock();
  elevatorUI.classList.remove('hidden');
}

function goToFloor(f) {
  elevatorUI.classList.add('hidden');
  elevatorOpen = false;

  const mover = isMobile || !controls ? camera : controls.getObject();
  if (f === 'roof') {
    mover.position.set(0, CONFIG.floors * CONFIG.floorHeight + CONFIG.playerHeight, 0);
    currentFloor = 'Roof';
    floorInd.textContent = 'Roof';
    if (partsCollected >= TOTAL_PARTS) {
      setTimeout(() => {
        winScreen.classList.remove('hidden');
        gameOver = true;
      }, 600);
    } else {
      showMsg('You need all 10 parts to fix the helicopter!');
    }
  } else {
    const y = (f - 1) * CONFIG.floorHeight + CONFIG.playerHeight;
    mover.position.set(0, y, 8);
    currentFloor = f;
    floorInd.textContent = `Floor ${f}`;
  }
}

function handleMonsterInteract(m) {
  const k = m.userData.kind;
  if (k === 'hungry' && holdingItem === 'meat') {
    holdingItem = null;
    m.userData.alive = false;
    m.visible = false;
    showMsg('Hungry Zombie is satisfied. He leaves.');
  } else if (k === 'whisper') {
    showMsg('Whisper silenced… for now.');
    m.userData.state = 'calm';
  } else {
    showMsg(m.userData.desc);
  }
}

/* -------------------- MONSTER AI -------------------- */
function updateMonsters(dt) {
  if (gameOver) return;
  const playerPos = (isMobile || !controls) ? camera.position : controls.getObject().position;

  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor !== currentFloor && currentFloor !== 'Roof') return;

    // Stunned monsters do nothing
    if (m.userData.stunned) return;

    const kind = m.userData.kind;
    const toPlayer = new THREE.Vector3().subVectors(playerPos, m.position);
    const dist = toPlayer.length();
    toPlayer.y = 0;
    toPlayer.normalize();

    // Is player looking at monster?
    const lookDir = camera.getWorldDirection(new THREE.Vector3());
    const toM = new THREE.Vector3().subVectors(m.position, camera.position).normalize();
    const lookingAt = lookDir.dot(toM) > 0.85 && dist < 12;

    if (kind === 'watcher') {
      if (lookingAt) {
        // freeze
      } else if (dist > 1.5) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      } else kill('The Watcher caught you');
    }
    else if (kind === 'gaze') {
      if (lookingAt) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 2.0) kill('You stared too long at the Gaze Beast');
      } else {
        m.userData.lookTimer = Math.max(0, m.userData.lookTimer - dt * 0.5);
      }
    }
    else if (kind === 'hungry') {
      if (dist > 1.8) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (holdingItem !== 'meat') kill('The Hungry Zombie reached you');
    }
    else if (kind === 'backtext') {
      // if player is looking roughly away from monster while close
      const away = lookDir.dot(toM) < -0.3;
      if (away && dist < 8) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.2) kill('You looked at your back…');
      } else m.userData.lookTimer = 0;
      if (dist > 2) m.position.addScaledVector(toPlayer, m.userData.speed * 0.6 * dt);
    }
    else if (kind === 'stalker') {
      // moves toward where player is going
      const predict = playerPos.clone().add(lookDir.clone().multiplyScalar(3));
      const toPred = new THREE.Vector3().subVectors(predict, m.position);
      toPred.y = 0; toPred.normalize();
      if (dist > 1.6) m.position.addScaledVector(toPred, m.userData.speed * dt);
      else kill('The Pale Girl caught you');
    }
    else if (kind === 'toy') {
      if (holdingItem === 'toy') {
        // follows calmly
        if (dist > 2.5) m.position.addScaledVector(toPlayer, 1.5 * dt);
      } else if (dist < 2.0) {
        // aggressive until toy is placed
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      }
    }
    else if (kind === 'crier') {
      if (lookingAt && Math.abs(joy.x) + Math.abs(joy.y) < 0.1 && !move.f && !move.b && !move.l && !move.r) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.5) {
          m.userData.alive = false;
          m.visible = false;
          showMsg('Blood Crier calmed down and vanished.');
        }
      } else {
        m.userData.lookTimer = 0;
        if (dist > 1.7) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
        else kill('The Blood Crier reached you');
      }
    }
    else if (kind === 'shadowstep') {
      const moving = Math.abs(joy.x) + Math.abs(joy.y) > 0.1 || move.f || move.b || move.l || move.r;
      if (moving && dist > 1.5) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (!moving) { /* frozen */ }
      else kill('Shadow Step touched you');
    }
    else if (kind === 'whisper') {
      if (m.userData.state !== 'calm' && dist < 4) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 4) kill('The Whisper Doll’s voice took you');
      }
    }
  });
}

function kill(reason) {
  if (gameOver) return;
  gameOver = true;
  showMsg(reason, 5000);
  setTimeout(() => location.reload(), 3500);
}

function tryStun() {
  if (gameOver || stunCooldown > 0 || stunActive > 0) return;
  // Stun every monster on the current floor
  let hit = 0;
  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor === currentFloor || currentFloor === 'Roof') {
      m.userData.stunned = true;
      hit++;
    }
  });
  if (hit > 0) {
    stunActive = 3;
    stunCooldown = 15;
    showMsg(`Monster stunned for 3 seconds! (${hit})`);
  } else {
    showMsg('No monster on this floor');
    stunCooldown = 2; // small anti-spam
  }
  updateStunUI();
}

function updateStunUI() {
  const desk = document.getElementById('stun-btn-desktop');
  const setState = (btn, text, disabled) => {
    if (!btn) return;
    btn.disabled = disabled;
    btn.textContent = text;
  };
  if (stunCooldown > 0) {
    const t = Math.ceil(stunCooldown) + 's';
    setState(stunBtn, t, true);
    setState(desk, t, true);
    if (stunCdEl) stunCdEl.textContent = 'Cooldown';
  } else if (stunActive > 0) {
    setState(stunBtn, 'STUNNED', true);
    setState(desk, 'STUNNED', true);
  } else {
    setState(stunBtn, 'STUN', false);
    setState(desk, 'STUN (Q)', false);
    if (stunCdEl) stunCdEl.textContent = 'Ready';
  }
}

/* -------------------- ANIMATION -------------------- */
function animate() {
  requestAnimationFrame(animate);
  if (gameOver) {
    renderer.render(scene, camera);
    return;
  }
  const dt = Math.min(clock.getDelta(), 0.05);

  // Stun timers
  if (stunActive > 0) {
    stunActive -= dt;
    if (stunActive <= 0) {
      stunActive = 0;
      monsters.forEach(m => { m.userData.stunned = false; });
    }
  }
  if (stunCooldown > 0) {
    stunCooldown -= dt;
    if (stunCooldown < 0) stunCooldown = 0;
  }
  updateStunUI();

  const speed = CONFIG.playerSpeed * dt;
  const forward = new THREE.Vector3();
  const right = new THREE.Vector3();
  const mover = isMobile || !controls ? camera : controls.getObject();

  if (isMobile) {
    camera.rotation.order = 'YXZ';
    camera.rotation.y -= lookD.x;
    camera.rotation.x -= lookD.y;
    camera.rotation.x = Math.max(-1.2, Math.min(1.2, camera.rotation.x));
    lookD.x = 0; lookD.y = 0;

    camera.getWorldDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    mover.position.addScaledVector(forward, joy.y * speed);
    mover.position.addScaledVector(right, joy.x * speed);
  } else if (controls && controls.isLocked) {
    controls.getDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    if (move.f) mover.position.addScaledVector(forward, speed);
    if (move.b) mover.position.addScaledVector(forward, -speed);
    if (move.l) mover.position.addScaledVector(right, -speed);
    if (move.r) mover.position.addScaledVector(right, speed);
  }

  // Bounds
  const halfL = CONFIG.corridorLength/2 - 1;
  const halfW = CONFIG.corridorWidth/2 - 0.7;
  mover.position.x = Math.max(-halfL, Math.min(halfL, mover.position.x));
  mover.position.z = Math.max(-halfW, Math.min(halfW, mover.position.z));

  // Floor height lock
  if (currentFloor !== 'Roof') {
    const targetY = (currentFloor - 1) * CONFIG.floorHeight + CONFIG.playerHeight;
    mover.position.y += (targetY - mover.position.y) * 0.3;
  }

  updateMonsters(dt);

  // Part bob
  parts.forEach(p => {
    if (!p.userData.collected) {
      p.rotation.y += dt * 1.3;
      p.position.y += Math.sin(clock.elapsedTime * 2 + p.userData.id) * 0.002;
    }
  });

  renderer.render(scene, camera);
}

function setupUI() {
  // Elevator buttons
  const box = document.getElementById('elevator-buttons');
  for (let i = 1; i <= 10; i++) {
    const b = document.createElement('button');
    b.textContent = i;
    b.onclick = () => goToFloor(i);
    box.appendChild(b);
  }
  const roofBtn = document.createElement('button');
  roofBtn.textContent = 'ROOF';
  roofBtn.className = 'roof';
  roofBtn.onclick = () => goToFloor('roof');
  box.appendChild(roofBtn);

  document.getElementById('elevator-close').onclick = () => {
    elevatorUI.classList.add('hidden');
    elevatorOpen = false;
  };

  document.getElementById('dialogue-close').onclick = () => dialogue.classList.add('hidden');
  document.getElementById('restart-btn').onclick = () => location.reload();

  if (stunBtn) {
    stunBtn.addEventListener('click', tryStun);
    stunBtn.addEventListener('touchstart', e => { e.preventDefault(); tryStun(); }, { passive: false });
  }
  const stunDesk = document.getElementById('stun-btn-desktop');
  if (stunDesk) {
    stunDesk.addEventListener('click', tryStun);
  }

  let p = 0;
  const iv = setInterval(() => {
    p += 15;
    progressEl.style.width = Math.min(p, 95) + '%';
    if (p >= 95) clearInterval(iv);
  }, 60);
}

init().catch(console.error);

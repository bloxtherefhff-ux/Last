import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

/* ============================================================
   SKYLINE HOTEL – 10 FLOORS
   Brighter atmosphere + monsters with counters
   ============================================================ */

const CONFIG = {
  floors: 10,
  floorHeight: 4.5,
  corridorWidth: 7,
  corridorLength: 32,
  playerHeight: 1.7,
  playerSpeed: 5.2
};

let scene, camera, renderer, controls;
let currentFloor = 1;
let partsCollected = 0;
const TOTAL_PARTS = 10;
let move = { f: false, b: false, l: false, r: false };
let isMobile = false;
let joy = { x: 0, y: 0 };
let lookD = { x: 0, y: 0 };
let interactables = [];
let monsters = [];
let elevators = []; // {floor, side, doorL, doorR, group, zone}
let insideElevator = false;
let elevPromptShown = false;
let ridingElevator = false;
let rideTimer = 0;
let ridePhase = null; // closing | moving | opening
let rideTarget = null;
let parts = [];
let clock = new THREE.Clock();
let raycaster = new THREE.Raycaster();
let elevatorOpen = false;
let gameOver = false;
let holdingItem = null; // for toy / meat
let stunCooldown = 0;   // seconds remaining before stun can be used again
let stunActive = 0;     // seconds remaining of current stun

// DOM
const loadingEl = document.getElementById('loading');
const progressEl = document.getElementById('progress');
const hud = document.getElementById('hud');
const floorInd = document.getElementById('floor-indicator');
const partsEl = document.getElementById('parts');
const mobileControls = document.getElementById('mobile-controls');
const dialogue = document.getElementById('dialogue');
const npcNameEl = document.getElementById('npc-name');
const npcTextEl = document.getElementById('npc-text');
const winScreen = document.getElementById('win-screen');
const elevatorUI = document.getElementById('elevator-ui');
const msgEl = document.getElementById('msg');
const stunBtn = document.getElementById('stun-btn');
const stunCdEl = document.getElementById('stun-cd');

function showMsg(text, time = 3000) {
  msgEl.textContent = text;
  msgEl.classList.remove('hidden');
  setTimeout(() => msgEl.classList.add('hidden'), time);
}

async function init() {
  // MOBILE ONLY game
  isMobile = true;

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x4a4a5e);
  scene.fog = null; // fog costs FPS on mobile

  camera = new THREE.PerspectiveCamera(72, innerWidth / innerHeight, 0.1, 90);
  camera.position.set(0, CONFIG.playerHeight, 0);
  camera.rotation.order = 'YXZ';
  camera.rotation.y = -Math.PI / 2; // face +X elevator in the end wall
  camera.rotation.order = 'YXZ';

  renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', alpha: false });
  renderer.setSize(innerWidth, innerHeight);
  // Critical for mid-range phones: never above 1
  renderer.setPixelRatio(1);
  renderer.shadowMap.enabled = false;
  document.body.appendChild(renderer.domElement);

  // Cheap lighting only (point lights kill mobile FPS)
  scene.add(new THREE.AmbientLight(0xffffff, 1.4));
  scene.add(new THREE.HemisphereLight(0xffffff, 0x888899, 0.9));

  buildHotel();
  placeParts();
  placeMonsters();
  placeNPCs();

  setupMobile();
  setupKeys();
  setupUI();

  progressEl.style.width = '100%';
  setTimeout(() => {
    loadingEl.classList.add('hidden');
    hud.classList.remove('hidden');
    mobileControls.classList.remove('hidden');
  }, 700);

  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });

  animate();
}

/* -------------------- HOTEL -------------------- */
function buildHotel() {
  // Lambert = much cheaper than Standard on mobile GPUs
  const wallMat = new THREE.MeshLambertMaterial({ color: 0x6a5e52 });
  const floorMat = new THREE.MeshLambertMaterial({ color: 0x5a4e42 });
  const ceilMat  = new THREE.MeshLambertMaterial({ color: 0x4a423a });
  const carpetMat = new THREE.MeshLambertMaterial({ color: 0x8a3a3a });
  const goldMat = new THREE.MeshLambertMaterial({ color: 0xd4a84b });

  scene.userData.floorGroups = [];
  for (let f = 1; f <= CONFIG.floors; f++) {
    const y = (f - 1) * CONFIG.floorHeight;
    const g = new THREE.Group();
    g.position.y = y;
    scene.userData.floorGroups.push(g);

    // Floor
    const slab = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength + 18, 0.3, CONFIG.corridorWidth + 10),
      floorMat
    );
    slab.position.y = -0.15;
    slab.receiveShadow = true;
    g.add(slab);

    // Carpet
    const carpet = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength - 1, 0.02, 2.4),
      carpetMat
    );
    carpet.position.y = 0.01;
    g.add(carpet);

    // Ceiling
    const ceil = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength + 18, 0.2, CONFIG.corridorWidth + 10),
      ceilMat
    );
    ceil.position.y = CONFIG.floorHeight - 0.1;
    g.add(ceil);

    // Walls
    const h = CONFIG.floorHeight - 0.3;
    const long = new THREE.BoxGeometry(CONFIG.corridorLength + 2, h, 0.35);
    const n = new THREE.Mesh(long, wallMat); n.position.set(0, h/2, -CONFIG.corridorWidth/2); g.add(n);
    const s = new THREE.Mesh(long, wallMat); s.position.set(0, h/2,  CONFIG.corridorWidth/2); g.add(s);

    // End walls with CENTER OPENING for elevator (not a solid block)
    const endSideH = (CONFIG.corridorWidth + 1 - 2.6) / 2;
    for (const sx of [1, -1]) {
      const baseX = sx * (CONFIG.corridorLength/2 + 0.2);
      // left and right pillars of end wall
      for (const zSign of [-1, 1]) {
        const pillar = new THREE.Mesh(
          new THREE.BoxGeometry(0.4, h, endSideH),
          wallMat
        );
        const zOff = zSign * (CONFIG.corridorWidth/2 + 0.5 - endSideH/2);
        pillar.position.set(baseX, h/2, zOff);
        g.add(pillar);
      }
      // top lintel above elevator
      const lintel = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 2.8), wallMat);
      lintel.position.set(baseX, h - 0.25, 0);
      g.add(lintel);
    }

    // Fewer room doors (perf)
    for (const i of [-4, -2, 2, 4]) {
      const door = new THREE.Mesh(
        new THREE.BoxGeometry(1.4, 2.4, 0.1),
        new THREE.MeshLambertMaterial({ color: 0x4a3525 })
      );
      door.position.set(i * 3.5, 1.2, i > 0 ? CONFIG.corridorWidth/2 - 0.1 : -CONFIG.corridorWidth/2 + 0.1);
      g.add(door);
    }

    // No small lamps – global bright lighting only

    // Elevator doors both ends
    // Dead center of each corridor END (crosshair target)
    createElevator(g,  CONFIG.corridorLength/2 - 0.8, f);
    createElevator(g, -CONFIG.corridorLength/2 + 0.8, f);



    // Floor number
    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 64;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#222'; ctx.fillRect(0,0,128,64);
    ctx.fillStyle = '#d4a84b'; ctx.font = 'bold 36px system-ui';
    ctx.textAlign = 'center'; ctx.fillText('F' + f, 64, 44);
    const tex = new THREE.CanvasTexture(canvas);
    const label = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.7), new THREE.MeshBasicMaterial({ map: tex }));
    label.position.set(0, 2.4, -CONFIG.corridorWidth/2 + 0.2);
    g.add(label);

    scene.add(g);
  }

  // Roof + helicopter
  const roofY = CONFIG.floors * CONFIG.floorHeight;
  const roof = new THREE.Group();
  roof.position.y = roofY;

  const roofSlab = new THREE.Mesh(
    new THREE.BoxGeometry(42, 0.4, 32),
    new THREE.MeshStandardMaterial({ color: 0x333333 })
  );
  roofSlab.position.y = 0.2;
  roof.add(roofSlab);

  const pad = new THREE.Mesh(
    new THREE.CylinderGeometry(6, 6, 0.15, 32),
    new THREE.MeshStandardMaterial({ color: 0x222222 })
  );
  pad.position.y = 0.35;
  roof.add(pad);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(4.5, 5, 32),
    new THREE.MeshBasicMaterial({ color: 0xd4a84b, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI/2;
  ring.position.y = 0.43;
  roof.add(ring);

  const heli = createHelicopter();
  heli.position.set(0, 1.9, 0);
  roof.add(heli);

  // no point light on roof (perf)

  scene.add(roof);
}








function createElevator(parent, x, floorNum) {
  // Big always-open gold portal in the CENTER of the end wall
  const side = x > 0 ? 1 : -1;
  const group = new THREE.Group();
  group.position.set(x, 0, 0);

  const gold = new THREE.MeshLambertMaterial({ color: 0xe8b84a });
  const dark = new THREE.MeshLambertMaterial({ color: 0x111118 });
  const green = new THREE.MeshLambertMaterial({ color: 0x44ff66 });

  // Wide gold arch (centered on z=0 = middle of hallway)
  const top = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.45, 3.2), gold);
  top.position.set(0, 2.9, 0); group.add(top);
  const bot = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.25, 3.2), gold);
  bot.position.set(0, 0.12, 0); group.add(bot);
  const L = new THREE.Mesh(new THREE.BoxGeometry(0.5, 3.0, 0.45), gold);
  L.position.set(0, 1.5, -1.6); group.add(L);
  const R = new THREE.Mesh(new THREE.BoxGeometry(0.5, 3.0, 0.45), gold);
  R.position.set(0, 1.5, 1.6); group.add(R);

  // Open hole (no doors ever)
  const hole = new THREE.Mesh(new THREE.BoxGeometry(0.6, 2.7, 2.6), dark);
  hole.position.set(-side * 0.35, 1.45, 0); group.add(hole);
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.2, 2.6, 2.5),
    new THREE.MeshLambertMaterial({ color: 0x333340 }));
  back.position.set(-side * 1.5, 1.4, 0); group.add(back);

  // Green light bar
  const lite = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.25, 2.4), green);
  lite.position.set(0.05 * side, 3.25, 0); group.add(lite);

  // Giant hitbox
  const hit = new THREE.Mesh(
    new THREE.BoxGeometry(4, 3.5, 4),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hit.position.set(-side * 0.5, 1.5, 0);
  hit.userData = { type: 'elevator', floor: floorNum };
  group.add(hit);
  interactables.push(hit);

  parent.add(group);
  elevators.push({ floor: floorNum, side, doorL: null, doorR: null, group, openAmount: 1, targetOpen: 1, closedZL: 0, closedZR: 0 });
}

function createHelicopter() {
  const g = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x2a2a2a, metalness: 0.5, roughness: 0.4 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(1, 2.4, 4, 12), bodyMat);
  body.rotation.z = Math.PI/2;
  g.add(body);
  const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.28, 3.2, 8), bodyMat);
  tail.rotation.z = Math.PI/2;
  tail.position.set(-2.8, 0.25, 0);
  g.add(tail);
  const rotor = new THREE.Mesh(new THREE.BoxGeometry(7.5, 0.1, 0.4), new THREE.MeshStandardMaterial({ color: 0x111 }));
  rotor.position.y = 1.25;
  g.add(rotor);
  return g;
}

/* -------------------- PARTS (1 per floor) -------------------- */
function placeParts() {
  for (let f = 1; f <= 10; f++) {
    const part = createPart(f);
    const y = (f - 1) * CONFIG.floorHeight + 0.5;
    const side = (f % 2 === 0) ? 1 : -1;
    part.position.set((Math.random() * 10 - 5), y, side * 1.8);
    part.userData = { type: 'part', id: f, collected: false, floor: f };
    scene.add(part);
    parts.push(part);
    interactables.push(part);
  }
}

function createPart(id) {
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({
    color: 0xd4a84b, metalness: 0.7, roughness: 0.3,
    emissive: 0x3a2a10, emissiveIntensity: 0.4
  });
  let mesh;
  if (id % 3 === 0) mesh = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.4, 0.55), mat);
  else if (id % 3 === 1) mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.65, 10), mat);
  else mesh = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.12, 8, 16), mat);
  g.add(mesh);
  // no point light (mobile perf)
  return g;
}

/* -------------------- MONSTERS -------------------- */

function placeMonsters() {
  // 9 enemies from concept gallery
  addMonster({
    name: 'The Watcher',
    floor: 2,
    pos: [8, 0, 1.4],
    color: 0x2a2a28,
    type: 'watcher',
    speed: 2.6,
    desc: 'Keep looking at him or he comes.'
  });
  addMonster({
    name: 'Gaze Beast',
    floor: 3,
    pos: [-9, 0, -1.5],
    color: 0x2e2a24,
    type: 'gaze',
    speed: 1.4,
    desc: 'Do not stare more than 2 seconds.'
  });
  addMonster({
    name: 'Hungry Zombie',
    floor: 4,
    pos: [6, 0, 1.6],
    color: 0x6b8a72,
    type: 'hungry',
    speed: 3.0,
    desc: 'Find meat and give it to him.'
  });
  addMonster({
    name: 'Backwatcher',
    floor: 5,
    pos: [-7, 0, -1.3],
    color: 0x1c1a17,
    type: 'backtext',
    speed: 2.0,
    desc: 'Never look behind near him.'
  });
  addMonster({
    name: 'Pale Woman',
    floor: 6,
    pos: [4, 0, 1.7],
    color: 0x141315,
    type: 'stalker',
    speed: 2.3,
    desc: 'She cuts you off. Keep changing path.'
  });
  addMonster({
    name: 'Toy Doll',
    floor: 7,
    pos: [-5, 0, -1.6],
    color: 0x2a2024,
    type: 'toy',
    speed: 1.7,
    desc: 'Put the toy in the box to calm her.'
  });
  addMonster({
    name: 'Blood Crier',
    floor: 8,
    pos: [9, 0, 1.2],
    color: 0xd8d2c6,
    type: 'crier',
    speed: 2.5,
    desc: 'Stand still and look at his face.'
  });
  addMonster({
    name: 'Shadow Step',
    floor: 9,
    pos: [-8, 0, 1.4],
    color: 0x070708,
    type: 'shadowstep',
    speed: 3.8,
    desc: 'Only moves when you move. Stand still.'
  });
  addMonster({
    name: 'Whisper Doll',
    floor: 1,
    pos: [0, 0, -2],
    color: 0x3a3228,
    type: 'whisper',
    speed: 1.1,
    desc: 'Interact to silence her whisper.'
  });
}

function addMonster(data) {
  const m = createMonsterMesh(data.color, data.name, data.type);
  const y = (data.floor - 1) * CONFIG.floorHeight;
  m.position.set(data.pos[0], y, data.pos[2]);
  m.userData = {
    type: 'monster',
    kind: data.type,
    name: data.name,
    speed: data.speed,
    floor: data.floor,
    alive: true,
    lookTimer: 0,
    state: 'idle',
    desc: data.desc,
    stunned: false
  };
  scene.add(m);
  monsters.push(m);
  interactables.push(m);
}






function createMonsterMesh(color, name, kind) {
  let g;
  switch (kind) {
    case 'watcher': g = createWatcherMesh(); break;
    case 'gaze': g = createGazeBeastMesh(); break;
    case 'hungry': g = createHungryZombieMesh(); break;
    case 'backtext': g = createBackwatcherMesh(); break;
    case 'stalker': g = createPaleGirlMesh(); break;
    case 'toy': g = createToyGirlMesh(); break;
    case 'crier': g = createBloodCrierMesh(); break;
    case 'shadowstep': g = createShadowStepMesh(); break;
    case 'whisper': g = createWhisperDollMesh(); break;
    default: g = createWatcherMesh(); break;
  }

  // Name plate above head
  const canvas = document.createElement('canvas');
  canvas.width = 256; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(10,0,0,0.88)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.strokeStyle = '#cc2222';
  ctx.lineWidth = 2;
  ctx.strokeRect(2, 2, 252, 60);
  ctx.fillStyle = '#ff6666';
  ctx.font = 'bold 18px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText(name, 128, 40);
  const tex = new THREE.CanvasTexture(canvas);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  spr.scale.set(1.9, 0.48, 1);
  spr.position.y = 2.55;
  g.add(spr);
  return g;
}


function createWatcherMesh() {
  const g = new THREE.Group();
  const suit = new THREE.MeshLambertMaterial({ color: 0x3a2a22 });
  const shirt = new THREE.MeshLambertMaterial({ color: 0x8b8175 });
  const skin = new THREE.MeshLambertMaterial({ color: 0xb6a49a });
  const dark = new THREE.MeshLambertMaterial({ color: 0x171518 });
  const eye = new THREE.MeshLambertMaterial({ color: 0xeeeecc });
  const pupil = new THREE.MeshLambertMaterial({ color: 0x080808 });
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.78, 0.28), suit);
  torso.position.y = 1.22; g.add(torso);
  const vest = new THREE.Mesh(new THREE.BoxGeometry(0.27, 0.65, 0.30), dark);
  vest.position.set(0, 1.25, -0.015); g.add(vest);
  const shirtFront = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.58, 0.31), shirt);
  shirtFront.position.set(0, 1.28, -0.17); g.add(shirtFront);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.23, 10, 8), skin);
  head.scale.set(0.88, 1.15, 0.9); head.position.y = 1.82; g.add(head);
  const hair = new THREE.Mesh(new THREE.CylinderGeometry(0.235, 0.22, 0.12, 10), dark);
  hair.position.y = 2.03; g.add(hair);
  const leftEye = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 6), eye);
  leftEye.scale.z = 0.35; leftEye.position.set(-0.085, 1.85, -0.205); g.add(leftEye);
  const rightEye = leftEye.clone(); rightEye.position.x = 0.085; g.add(rightEye);
  const leftPupil = new THREE.Mesh(new THREE.SphereGeometry(0.022, 6, 5), pupil);
  leftPupil.position.set(-0.085, 1.85, -0.225); g.add(leftPupil);
  const rightPupil = leftPupil.clone(); rightPupil.position.x = 0.085; g.add(rightPupil);
  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.12, 6), skin);
  nose.rotation.x = -Math.PI / 2; nose.position.set(0, 1.78, -0.23); g.add(nose);
  const leftArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.48, 4, 6), suit);
  leftArm.position.set(-0.31, 1.24, 0); leftArm.rotation.z = -0.06; g.add(leftArm);
  const rightArm = leftArm.clone(); rightArm.position.x = 0.31; rightArm.rotation.z = 0.06; g.add(rightArm);
  const leftHand = new THREE.Mesh(new THREE.SphereGeometry(0.075, 7, 5), skin);
  leftHand.position.set(-0.32, 0.88, 0); g.add(leftHand);
  const rightHand = leftHand.clone(); rightHand.position.x = 0.32; g.add(rightHand);
  const leftLeg = new THREE.Mesh(new THREE.CapsuleGeometry(0.10, 0.48, 4, 6), dark);
  leftLeg.position.set(-0.13, 0.48, 0); g.add(leftLeg);
  const rightLeg = leftLeg.clone(); rightLeg.position.x = 0.13; g.add(rightLeg);
  const leftShoe = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.08, 0.34), dark);
  leftShoe.position.set(-0.13, 0.06, -0.045); g.add(leftShoe);
  const rightShoe = leftShoe.clone(); rightShoe.position.x = 0.13; g.add(rightShoe);
  return g;
}

function createGazeBeastMesh() {
  const g = new THREE.Group();
  const fur = new THREE.MeshLambertMaterial({ color: 0x302a27 });
  const furDark = new THREE.MeshLambertMaterial({ color: 0x171516 });
  const skin = new THREE.MeshLambertMaterial({ color: 0x74645d });
  const eyes = new THREE.MeshLambertMaterial({ color: 0x090909 });
  const body = new THREE.Mesh(new THREE.SphereGeometry(0.42, 10, 8), fur);
  body.scale.set(1.0, 1.35, 0.72); body.rotation.x = -0.22; body.position.set(0, 1.05, 0.03); g.add(body);
  const shoulders = new THREE.Mesh(new THREE.SphereGeometry(0.46, 8, 6), fur);
  shoulders.scale.z = 0.65; shoulders.position.set(0, 1.38, 0); g.add(shoulders);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.32, 9, 7), fur);
  head.scale.set(0.9, 1.0, 0.85); head.rotation.x = 0.18; head.position.set(0, 1.68, -0.03); g.add(head);
  const snout = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.55, 8), skin);
  snout.rotation.x = Math.PI / 2; snout.position.set(0, 1.59, -0.39); g.add(snout);
  const nose = new THREE.Mesh(new THREE.SphereGeometry(0.10, 7, 5), furDark);
  nose.scale.z = 0.55; nose.position.set(0, 1.59, -0.65); g.add(nose);
  [[-0.15,1.78,-0.28],[0.15,1.78,-0.28],[-0.08,1.68,-0.32],[0.08,1.68,-0.32],[-0.18,1.67,-0.27],[0.18,1.67,-0.27]].forEach(p => {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.045, 6, 5), eyes);
    e.position.set(p[0], p[1], p[2]); g.add(e);
  });
  const leftArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.10, 0.70, 4, 6), fur);
  leftArm.position.set(-0.46, 0.92, -0.04); leftArm.rotation.z = -0.20; leftArm.rotation.x = -0.18; g.add(leftArm);
  const rightArm = leftArm.clone(); rightArm.position.x = 0.46; rightArm.rotation.z = 0.20; g.add(rightArm);
  const leftHand = new THREE.Mesh(new THREE.SphereGeometry(0.11, 7, 5), skin);
  leftHand.position.set(-0.56, 0.48, -0.12); g.add(leftHand);
  const rightHand = leftHand.clone(); rightHand.position.x = 0.56; g.add(rightHand);
  const leftLeg = new THREE.Mesh(new THREE.CapsuleGeometry(0.13, 0.55, 4, 6), furDark);
  leftLeg.position.set(-0.20, 0.43, 0); leftLeg.rotation.x = -0.18; g.add(leftLeg);
  const rightLeg = leftLeg.clone(); rightLeg.position.x = 0.20; g.add(rightLeg);
  const leftFoot = new THREE.Mesh(new THREE.SphereGeometry(0.16, 7, 5), furDark);
  leftFoot.scale.set(0.8, 0.45, 1.35); leftFoot.position.set(-0.20, 0.09, -0.10); g.add(leftFoot);
  const rightFoot = leftFoot.clone(); rightFoot.position.x = 0.20; g.add(rightFoot);
  return g;
}

function createHungryZombieMesh() {
  const g = new THREE.Group();
  const skin = new THREE.MeshLambertMaterial({ color: 0x66705d });
  const wound = new THREE.MeshLambertMaterial({ color: 0x3d1715 });
  const shirt = new THREE.MeshLambertMaterial({ color: 0x77766b });
  const pants = new THREE.MeshLambertMaterial({ color: 0x252627 });
  const blood = new THREE.MeshLambertMaterial({ color: 0x4a1715 });
  const eye = new THREE.MeshLambertMaterial({ color: 0x171313 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.25, 0.55, 5, 7), shirt);
  torso.scale.z = 0.62; torso.position.y = 1.20; g.add(torso);
  const chestWound = new THREE.Mesh(new THREE.SphereGeometry(0.13, 7, 5), wound);
  chestWound.scale.set(1.4, 1.8, 0.35); chestWound.position.set(-0.08, 1.25, -0.20); g.add(chestWound);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.25, 9, 7), skin);
  head.scale.set(0.9, 1.15, 0.85); head.position.y = 1.83; g.add(head);
  const jaw = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6), wound);
  jaw.scale.set(1.0, 0.45, 0.7); jaw.position.set(0, 1.68, -0.20); g.add(jaw);
  const leftEye = new THREE.Mesh(new THREE.SphereGeometry(0.045, 6, 5), eye);
  leftEye.position.set(-0.09, 1.86, -0.22); g.add(leftEye);
  const rightEye = leftEye.clone(); rightEye.position.x = 0.09; g.add(rightEye);
  const bloodPatch = new THREE.Mesh(new THREE.SphereGeometry(0.11, 7, 5), blood);
  bloodPatch.scale.set(0.7, 1.5, 0.3); bloodPatch.position.set(0.17, 1.32, -0.22); g.add(bloodPatch);
  const leftArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.085, 0.48, 4, 6), shirt);
  leftArm.position.set(-0.31, 1.05, 0); leftArm.rotation.z = 0.12; g.add(leftArm);
  const reachingArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.085, 0.55, 4, 6), shirt);
  reachingArm.position.set(0.39, 1.18, -0.20); reachingArm.rotation.z = -0.58; reachingArm.rotation.x = -0.25; g.add(reachingArm);
  const leftHand = new THREE.Mesh(new THREE.SphereGeometry(0.09, 7, 5), skin);
  leftHand.position.set(-0.34, 0.72, 0); g.add(leftHand);
  const reachingHand = new THREE.Mesh(new THREE.SphereGeometry(0.10, 7, 5), skin);
  reachingHand.position.set(0.67, 1.05, -0.35); g.add(reachingHand);
  for (let i = 0; i < 3; i++) {
    const f = new THREE.Mesh(new THREE.CapsuleGeometry(0.018, 0.10, 3, 4), skin);
    f.position.set(0.61 + i * 0.045, 1.00, -0.39); f.rotation.z = -0.4; g.add(f);
  }
  const leftLeg = new THREE.Mesh(new THREE.CapsuleGeometry(0.105, 0.48, 4, 6), pants);
  leftLeg.position.set(-0.13, 0.43, 0); g.add(leftLeg);
  const rightLeg = leftLeg.clone(); rightLeg.position.x = 0.13; g.add(rightLeg);
  const leftShoe = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.10, 0.34), pants);
  leftShoe.position.set(-0.13, 0.06, -0.04); g.add(leftShoe);
  const rightShoe = leftShoe.clone(); rightShoe.position.x = 0.13; g.add(rightShoe);
  return g;
}

function createBackwatcherMesh() {
  const g = new THREE.Group();
  const dark = new THREE.MeshLambertMaterial({ color: 0x252321 });
  const skin = new THREE.MeshLambertMaterial({ color: 0x766b66 });
  const black = new THREE.MeshLambertMaterial({ color: 0x111010 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.25, 0.60, 5, 7), dark);
  torso.scale.set(0.8, 1.0, 0.62); torso.position.y = 1.20; g.add(torso);
  const chest = new THREE.Mesh(new THREE.SphereGeometry(0.24, 8, 6), skin);
  chest.scale.set(0.8, 1.2, 0.4); chest.position.set(0, 1.31, -0.17); g.add(chest);
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.10, 0.13, 0.22, 7), skin);
  neck.position.y = 1.67; g.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.24, 9, 7), skin);
  head.scale.set(0.9, 1.0, 0.85); head.position.set(0.07, 1.82, 0.08);
  head.rotation.y = Math.PI; head.rotation.z = -0.35; g.add(head);
  const face = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 6), skin);
  face.scale.z = 0.45; face.position.set(0.02, 1.81, 0.29); face.rotation.y = Math.PI; g.add(face);
  const leftEye = new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 5), black);
  leftEye.position.set(-0.07, 1.85, 0.36); g.add(leftEye);
  const rightEye = leftEye.clone(); rightEye.position.x = 0.10; g.add(rightEye);
  const leftLeg = new THREE.Mesh(new THREE.CapsuleGeometry(0.13, 0.48, 4, 6), dark);
  leftLeg.position.set(-0.19, 0.52, 0); leftLeg.rotation.z = -0.12; g.add(leftLeg);
  const rightLeg = leftLeg.clone(); rightLeg.position.x = 0.19; rightLeg.rotation.z = 0.12; g.add(rightLeg);
  const leftShin = new THREE.Mesh(new THREE.CapsuleGeometry(0.105, 0.38, 4, 6), black);
  leftShin.position.set(-0.25, 0.19, -0.02); leftShin.rotation.z = -0.10; g.add(leftShin);
  const rightShin = leftShin.clone(); rightShin.position.x = 0.25; rightShin.rotation.z = 0.10; g.add(rightShin);
  const leftFoot = new THREE.Mesh(new THREE.SphereGeometry(0.15, 7, 5), black);
  leftFoot.scale.set(0.75, 0.45, 1.4); leftFoot.position.set(-0.28, 0.07, -0.07); g.add(leftFoot);
  const rightFoot = leftFoot.clone(); rightFoot.position.x = 0.28; g.add(rightFoot);
  const leftArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.55, 4, 6), dark);
  leftArm.position.set(-0.32, 1.08, 0); leftArm.rotation.z = 0.08; g.add(leftArm);
  const rightArm = leftArm.clone(); rightArm.position.x = 0.32; rightArm.rotation.z = -0.08; g.add(rightArm);
  return g;
}

function createPaleGirlMesh() {
  const g = new THREE.Group();
  const suit = new THREE.MeshLambertMaterial({ color: 0x161519 });
  const hairMat = new THREE.MeshLambertMaterial({ color: 0x050506 });
  const skin = new THREE.MeshLambertMaterial({ color: 0xd0c4bd });
  const eyeWhite = new THREE.MeshLambertMaterial({ color: 0xe7e2d9 });
  const pupil = new THREE.MeshLambertMaterial({ color: 0x080708 });
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.39, 0.58, 0.25), suit);
  torso.position.y = 1.30; g.add(torso);
  const skirt = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.58, 10), suit);
  skirt.position.y = 0.82; g.add(skirt);
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.10, 0.14, 8), skin);
  neck.position.y = 1.65; g.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 9, 7), skin);
  head.scale.set(0.88, 1.12, 0.85); head.position.y = 1.82; g.add(head);
  const hair = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.28, 0.55, 10), hairMat);
  hair.scale.z = 0.75; hair.position.set(0, 1.78, 0.01); g.add(hair);
  const hairFront = new THREE.Mesh(new THREE.BoxGeometry(0.43, 0.48, 0.12), hairMat);
  hairFront.position.set(0, 1.80, -0.22); g.add(hairFront);
  const visibleEye = new THREE.Mesh(new THREE.SphereGeometry(0.045, 7, 5), eyeWhite);
  visibleEye.scale.z = 0.35; visibleEye.position.set(0.10, 1.84, -0.285); g.add(visibleEye);
  const visiblePupil = new THREE.Mesh(new THREE.SphereGeometry(0.020, 6, 5), pupil);
  visiblePupil.position.set(0.10, 1.84, -0.302); g.add(visiblePupil);
  const leftArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.065, 0.48, 4, 6), suit);
  leftArm.position.set(-0.27, 1.28, 0); g.add(leftArm);
  const rightArm = leftArm.clone(); rightArm.position.x = 0.27; g.add(rightArm);
  const leftHand = new THREE.Mesh(new THREE.SphereGeometry(0.065, 7, 5), skin);
  leftHand.position.set(-0.27, 0.91, 0); g.add(leftHand);
  const rightHand = leftHand.clone(); rightHand.position.x = 0.27; g.add(rightHand);
  const leftLeg = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.42, 4, 6), skin);
  leftLeg.position.set(-0.11, 0.27, 0); g.add(leftLeg);
  const rightLeg = leftLeg.clone(); rightLeg.position.x = 0.11; g.add(rightLeg);
  const leftShoe = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.07, 0.27), hairMat);
  leftShoe.position.set(-0.11, 0.045, -0.04); g.add(leftShoe);
  const rightShoe = leftShoe.clone(); rightShoe.position.x = 0.11; g.add(rightShoe);
  return g;
}

function createToyGirlMesh() {
  const g = new THREE.Group();
  const dress = new THREE.MeshLambertMaterial({ color: 0x292526 });
  const porcelain = new THREE.MeshLambertMaterial({ color: 0xc9c0b6 });
  const crack = new THREE.MeshLambertMaterial({ color: 0x332d2b });
  const hair = new THREE.MeshLambertMaterial({ color: 0x171416 });
  const teddy = new THREE.MeshLambertMaterial({ color: 0x55463e });
  const eye = new THREE.MeshLambertMaterial({ color: 0x111012 });
  const dressBody = new THREE.Mesh(new THREE.CylinderGeometry(0.19, 0.31, 0.48, 8), dress);
  dressBody.position.y = 0.65; g.add(dressBody);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.20, 8, 7), porcelain);
  head.position.y = 1.10; g.add(head);
  const hairCap = new THREE.Mesh(new THREE.SphereGeometry(0.215, 8, 6), hair);
  hairCap.scale.set(1.05, 0.75, 0.85); hairCap.position.set(0, 1.17, 0.01); g.add(hairCap);
  const leftEye = new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 5), eye);
  leftEye.position.set(-0.07, 1.12, -0.18); g.add(leftEye);
  const rightEye = leftEye.clone(); rightEye.position.x = 0.07; g.add(rightEye);
  const smile = new THREE.Mesh(new THREE.TorusGeometry(0.055, 0.012, 4, 8, Math.PI), crack);
  smile.rotation.x = Math.PI; smile.position.set(0, 1.03, -0.19); g.add(smile);
  const crackLine = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.13, 0.008), crack);
  crackLine.position.set(0.035, 1.16, -0.195); crackLine.rotation.z = 0.25; g.add(crackLine);
  const leftArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.29, 4, 6), dress);
  leftArm.position.set(-0.22, 0.72, 0); leftArm.rotation.z = 0.25; g.add(leftArm);
  const rightArm = leftArm.clone(); rightArm.position.x = 0.22; rightArm.rotation.z = -0.25; g.add(rightArm);
  const leftHand = new THREE.Mesh(new THREE.SphereGeometry(0.055, 6, 5), porcelain);
  leftHand.position.set(-0.16, 0.55, -0.10); g.add(leftHand);
  const rightHand = leftHand.clone(); rightHand.position.x = 0.16; g.add(rightHand);
  const teddyBody = new THREE.Mesh(new THREE.SphereGeometry(0.10, 7, 5), teddy);
  teddyBody.scale.y = 1.25; teddyBody.position.set(0, 0.57, -0.18); g.add(teddyBody);
  const teddyHead = new THREE.Mesh(new THREE.SphereGeometry(0.075, 7, 5), teddy);
  teddyHead.position.set(0, 0.70, -0.19); g.add(teddyHead);
  const ear1 = new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 5), teddy);
  ear1.position.set(-0.06, 0.75, -0.18); g.add(ear1);
  const ear2 = ear1.clone(); ear2.position.x = 0.06; g.add(ear2);
  const leg1 = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.25, 4, 5), porcelain);
  leg1.position.set(-0.09, 0.25, 0); g.add(leg1);
  const leg2 = leg1.clone(); leg2.position.x = 0.09; g.add(leg2);
  const foot1 = new THREE.Mesh(new THREE.BoxGeometry(0.10, 0.06, 0.18), hair);
  foot1.position.set(-0.09, 0.04, -0.02); g.add(foot1);
  const foot2 = foot1.clone(); foot2.position.x = 0.09; g.add(foot2);
  return g;
}

function createBloodCrierMesh() {
  const g = new THREE.Group();
  const skin = new THREE.MeshLambertMaterial({ color: 0xb8a7a0 });
  const shirt = new THREE.MeshLambertMaterial({ color: 0xc4c0b6 });
  const pants = new THREE.MeshLambertMaterial({ color: 0x252326 });
  const blood = new THREE.MeshLambertMaterial({ color: 0x4b1112 });
  const mouth = new THREE.MeshLambertMaterial({ color: 0x18090a });
  const eye = new THREE.MeshLambertMaterial({ color: 0x230b0c });
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.72, 0.28), shirt);
  torso.position.y = 1.20; g.add(torso);
  const bloodChest = new THREE.Mesh(new THREE.SphereGeometry(0.20, 8, 6), blood);
  bloodChest.scale.set(0.8, 1.55, 0.28); bloodChest.position.set(0, 1.22, -0.17); g.add(bloodChest);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.24, 9, 7), skin);
  head.scale.set(0.9, 1.15, 0.85); head.position.y = 1.82; g.add(head);
  const openMouth = new THREE.Mesh(new THREE.SphereGeometry(0.105, 8, 6), mouth);
  openMouth.scale.set(1.15, 1.65, 0.45); openMouth.position.set(0, 1.72, -0.225); g.add(openMouth);
  const upperTeeth = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.025, 0.025), shirt);
  upperTeeth.position.set(0, 1.79, -0.27); g.add(upperTeeth);
  const lowerTeeth = upperTeeth.clone(); lowerTeeth.position.y = 1.65; g.add(lowerTeeth);
  const leftEye = new THREE.Mesh(new THREE.SphereGeometry(0.045, 6, 5), eye);
  leftEye.position.set(-0.09, 1.86, -0.22); g.add(leftEye);
  const rightEye = leftEye.clone(); rightEye.position.x = 0.09; g.add(rightEye);
  const leftTear = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.012, 0.13, 5), blood);
  leftTear.position.set(-0.09, 1.75, -0.225); g.add(leftTear);
  const rightTear = leftTear.clone(); rightTear.position.x = 0.09; g.add(rightTear);
  const leftArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.085, 0.50, 4, 6), shirt);
  leftArm.position.set(-0.32, 1.12, -0.04); leftArm.rotation.z = -0.55; leftArm.rotation.x = -0.25; g.add(leftArm);
  const rightArm = leftArm.clone(); rightArm.position.x = 0.32; rightArm.rotation.z = 0.55; g.add(rightArm);
  const leftHand = new THREE.Mesh(new THREE.SphereGeometry(0.09, 7, 5), skin);
  leftHand.position.set(-0.55, 0.84, -0.18); g.add(leftHand);
  const rightHand = leftHand.clone(); rightHand.position.x = 0.55; g.add(rightHand);
  const leftLeg = new THREE.Mesh(new THREE.CapsuleGeometry(0.10, 0.48, 4, 6), pants);
  leftLeg.position.set(-0.13, 0.43, 0); g.add(leftLeg);
  const rightLeg = leftLeg.clone(); rightLeg.position.x = 0.13; g.add(rightLeg);
  const leftShoe = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.08, 0.32), pants);
  leftShoe.position.set(-0.13, 0.05, -0.03); g.add(leftShoe);
  const rightShoe = leftShoe.clone(); rightShoe.position.x = 0.13; g.add(rightShoe);
  return g;
}

function createShadowStepMesh() {
  const g = new THREE.Group();
  const shadow = new THREE.MeshLambertMaterial({ color: 0x030305 });
  const redEye = new THREE.MeshLambertMaterial({ color: 0x550505 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.70, 4, 6), shadow);
  torso.scale.set(0.72, 1.15, 0.55); torso.position.y = 1.25; g.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 6), shadow);
  head.scale.set(0.8, 1.1, 0.75); head.position.y = 1.91; g.add(head);
  const leftEye = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 5), redEye);
  leftEye.position.set(-0.075, 1.93, -0.19); g.add(leftEye);
  const rightEye = leftEye.clone(); rightEye.position.x = 0.075; g.add(rightEye);
  const leftArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.75, 4, 6), shadow);
  leftArm.position.set(-0.31, 1.10, 0); leftArm.rotation.z = 0.05; g.add(leftArm);
  const rightArm = leftArm.clone(); rightArm.position.x = 0.31; rightArm.rotation.z = -0.05; g.add(rightArm);
  const leftHand = new THREE.Mesh(new THREE.SphereGeometry(0.065, 6, 5), shadow);
  leftHand.position.set(-0.32, 0.55, 0); g.add(leftHand);
  const rightHand = leftHand.clone(); rightHand.position.x = 0.32; g.add(rightHand);
  const leftLeg = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.65, 4, 6), shadow);
  leftLeg.position.set(-0.12, 0.42, 0); g.add(leftLeg);
  const rightLeg = leftLeg.clone(); rightLeg.position.x = 0.12; g.add(rightLeg);
  const leftFoot = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.06, 0.29), shadow);
  leftFoot.position.set(-0.12, 0.04, -0.04); g.add(leftFoot);
  const rightFoot = leftFoot.clone(); rightFoot.position.x = 0.12; g.add(rightFoot);
  return g;
}

function createWhisperDollMesh() {
  const g = new THREE.Group();
  const dirtyDress = new THREE.MeshLambertMaterial({ color: 0x4a403d });
  const skin = new THREE.MeshLambertMaterial({ color: 0xa79d95 });
  const crack = new THREE.MeshLambertMaterial({ color: 0x242022 });
  const mouth = new THREE.MeshLambertMaterial({ color: 0x100b0c });
  const hair = new THREE.MeshLambertMaterial({ color: 0x211c1c });
  const dress = new THREE.Mesh(new THREE.ConeGeometry(0.25, 0.48, 8), dirtyDress);
  dress.position.y = 0.54; g.add(dress);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 7), skin);
  head.scale.set(0.95, 1.1, 0.85); head.position.y = 1.00; g.add(head);
  const hairCap = new THREE.Mesh(new THREE.SphereGeometry(0.19, 8, 6), hair);
  hairCap.scale.set(1.05, 0.85, 0.9); hairCap.position.set(0, 1.07, 0.02); g.add(hairCap);
  const leftEye = new THREE.Mesh(new THREE.SphereGeometry(0.028, 6, 5), crack);
  leftEye.position.set(-0.065, 1.01, -0.16); g.add(leftEye);
  const rightEye = leftEye.clone(); rightEye.position.x = 0.065; g.add(rightEye);
  const whisperMouth = new THREE.Mesh(new THREE.SphereGeometry(0.045, 7, 5), mouth);
  whisperMouth.scale.set(0.7, 1.45, 0.4); whisperMouth.position.set(0, 0.93, -0.17); g.add(whisperMouth);
  const faceCrack = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.12, 0.008), crack);
  faceCrack.position.set(-0.03, 1.08, -0.165); faceCrack.rotation.z = -0.3; g.add(faceCrack);
  const leftArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.045, 0.30, 4, 5), dirtyDress);
  leftArm.position.set(-0.25, 0.63, 0); leftArm.rotation.z = 0.18; g.add(leftArm);
  const rightArm = leftArm.clone(); rightArm.position.x = 0.25; rightArm.rotation.z = -0.18; g.add(rightArm);
  const leftHand = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 5), skin);
  leftHand.position.set(-0.28, 0.43, 0); g.add(leftHand);
  const rightHand = leftHand.clone(); rightHand.position.x = 0.28; g.add(rightHand);
  const leftLeg = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.28, 4, 5), skin);
  leftLeg.position.set(-0.09, 0.22, 0); g.add(leftLeg);
  const rightLeg = leftLeg.clone(); rightLeg.position.x = 0.09; g.add(rightLeg);
  const leftFoot = new THREE.Mesh(new THREE.BoxGeometry(0.10, 0.06, 0.18), dirtyDress);
  leftFoot.position.set(-0.09, 0.035, -0.025); g.add(leftFoot);
  const rightFoot = leftFoot.clone(); rightFoot.position.x = 0.09; g.add(rightFoot);
  return g;
}


/* -------------------- ITEMS for counters -------------------- */
function placeNPCs() {
  // Meat on floor 4
  const meat = createItem(0x8b0000, 'meat');
  meat.position.set(-4, (4-1)*CONFIG.floorHeight + 0.4, 1.5);
  meat.userData = { type: 'item', item: 'meat' };
  scene.add(meat);
  interactables.push(meat);

  // Toy on floor 7
  const toy = createItem(0xff69b4, 'toy');
  toy.position.set(7, (7-1)*CONFIG.floorHeight + 0.4, -1.6);
  toy.userData = { type: 'item', item: 'toy' };
  scene.add(toy);
  interactables.push(toy);

  // Box on floor 7
  const box = new THREE.Mesh(
    new THREE.BoxGeometry(0.8, 0.5, 0.8),
    new THREE.MeshStandardMaterial({ color: 0x5a3a1a })
  );
  box.position.set(-2, (7-1)*CONFIG.floorHeight + 0.3, 1.7);
  box.userData = { type: 'box' };
  scene.add(box);
  interactables.push(box);
}

function createItem(color, name) {
  const g = new THREE.Group();
  const m = new THREE.Mesh(
    new THREE.SphereGeometry(0.25, 10, 8),
    new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.3 })
  );
  g.add(m);
  // no point light
  return g;
}

/* -------------------- CONTROLS -------------------- */
function setupKeys() {
  const on = (e, p) => {
    switch (e.code) {
      case 'KeyW': case 'ArrowUp':    move.f = p; break;
      case 'KeyS': case 'ArrowDown':  move.b = p; break;
      case 'KeyA': case 'ArrowLeft':  move.l = p; break;
      case 'KeyD': case 'ArrowRight': move.r = p; break;
      case 'KeyE': case 'Space': if (p) tryInteract(); break;
      case 'KeyQ': case 'KeyF': if (p) tryStun(); break;
    }
  };
  addEventListener('keydown', e => on(e, true));
  addEventListener('keyup',   e => on(e, false));
}

function setupMobile() {
  const base = document.getElementById('joystick-base');
  const stick = document.getElementById('joystick-stick');
  const lookZone = document.getElementById('look-zone');
  const interactBtn = document.getElementById('interact-btn');

  let joyId = null, lookId = null, last = { x:0, y:0 };

  base.addEventListener('touchstart', e => {
    e.preventDefault();
    joyId = e.changedTouches[0].identifier;
  }, { passive: false });

  addEventListener('touchmove', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        const r = base.getBoundingClientRect();
        const cx = r.left + r.width/2, cy = r.top + r.height/2;
        let dx = t.clientX - cx, dy = t.clientY - cy;
        const max = r.width/2 - 8;
        const len = Math.hypot(dx, dy);
        if (len > max) { dx = dx/len*max; dy = dy/len*max; }
        stick.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
        joy.x = dx / max;
        joy.y = -dy / max;
      }
      if (t.identifier === lookId) {
        lookD.x += (t.clientX - last.x) * 0.004;
        lookD.y += (t.clientY - last.y) * 0.004;
        last.x = t.clientX; last.y = t.clientY;
      }
    }
  }, { passive: false });

  addEventListener('touchend', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        joyId = null;
        stick.style.transform = 'translate(-50%, -50%)';
        joy.x = 0; joy.y = 0;
      }
      if (t.identifier === lookId) lookId = null;
    }
  });

  lookZone.addEventListener('touchstart', e => {
    e.preventDefault();
    lookId = e.changedTouches[0].identifier;
    last.x = e.changedTouches[0].clientX;
    last.y = e.changedTouches[0].clientY;
  }, { passive: false });

  if (interactBtn) {
    const doInteract = (e) => {
      e.preventDefault();
      e.stopPropagation();
      tryInteract();
    };
    interactBtn.addEventListener('touchstart', doInteract, { passive: false });
    interactBtn.addEventListener('touchend', doInteract, { passive: false });
    interactBtn.addEventListener('click', doInteract);
  }
}


/* -------------------- INTERACTION + ELEVATOR -------------------- */
function tryInteract() {
  if (gameOver) return;
  if (elevatorOpen && elevatorUI && !elevatorUI.classList.contains('hidden')) return;

  const mover = camera.position;

  // 1) Near elevator ends? Open floor menu immediately (most reliable)
  const halfL = CONFIG.corridorLength / 2;
  if (currentFloor !== 'Roof' && Math.abs(Math.abs(mover.x) - halfL) < 5.5 && Math.abs(mover.z) < 3.5) {
    openElevatorUI();
    return;
  }

  const origin = camera.getWorldPosition(new THREE.Vector3());
  const dir = camera.getWorldDirection(new THREE.Vector3());
  raycaster.set(origin, dir);
  raycaster.far = 5.0;

  const hits = raycaster.intersectObjects(interactables, true);
  let obj = null;
  if (hits.length) {
    obj = hits[0].object;
    while (obj && !obj.userData.type) obj = obj.parent;
  }

  if (!obj || (obj.userData.type !== 'elevator' && obj.userData.type !== 'elevator-btn' && obj.userData.type !== 'floor-btn')) {
    const near = interactables.find(o => {
      if (!o.userData || !o.userData.type) return false;
      const wp = new THREE.Vector3();
      o.getWorldPosition(wp);
      return wp.distanceTo(mover) < 5.0 && Math.abs(wp.y - mover.y) < 3.5;
    });
    if (near) obj = near;
  }

  if (!obj) return;
  const d = obj.userData;

  if (d.type === 'part' && !d.collected) {
    d.collected = true;
    partsCollected++;
    partsEl.textContent = `Parts: ${partsCollected} / ${TOTAL_PARTS}`;
    obj.visible = false;
    showMsg(`Part ${d.id} collected!`);
    if (partsCollected >= TOTAL_PARTS) {
      document.getElementById('objective').textContent = 'All parts found! Go to the roof and fix the helicopter.';
    }
  }
  else if (d.type === 'floor-btn') {
    startElevatorRide(d.targetFloor);
  }
  else if (d.type === 'elevator' || d.type === 'elevator-btn') {
    openElevatorUI(); // floor menu
  }
  else if (d.type === 'item') {
    holdingItem = d.item;
    obj.visible = false;
    showMsg(`Picked up ${d.item}`);
  }
  else if (d.type === 'box' && holdingItem === 'toy') {
    holdingItem = null;
    showMsg('Toy placed in the box. Toy Girl is calm and shows the part.');
  }
  else if (d.type === 'monster') {
    handleMonsterInteract(obj);
  }
}



function openElevatorUI() {
  // Minimal panel only as backup — prefer 3D buttons inside cabin
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (!ui) return;
  elevatorOpen = true;
  const box = document.getElementById('elevator-buttons');
  if (box) {
    [...box.querySelectorAll('button')].forEach(b => {
      b.classList.remove('current');
      if (String(currentFloor) === b.textContent || (currentFloor === 'Roof' && b.textContent === 'ROOF')) {
        b.classList.add('current');
      }
    });
  }
  const label = document.getElementById('elevator-current');
  if (label) label.textContent = currentFloor === 'Roof' ? 'Now: Roof' : `Now: Floor ${currentFloor}`;
  ui.classList.remove('hidden');
}

function startElevatorRide(target) {
  if (ridingElevator || gameOver) return;
  if (target !== 'roof' && Number(target) === Number(currentFloor)) {
    showMsg('Already here');
    return;
  }
  // close HTML panel if open
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (ui) ui.classList.add('hidden');
  elevatorOpen = false;

  ridingElevator = true;
  rideTarget = target;
  ridePhase = 'moving';
  let dist = 2;
  if (target === 'roof') dist = currentFloor === 'Roof' ? 1 : (11 - Number(currentFloor || 1));
  else if (currentFloor === 'Roof') dist = Number(target);
  else dist = Math.abs(Number(target) - Number(currentFloor)) || 1;
  rideTimer = 1.0 + dist * 0.65;
  showMsg(target === 'roof' ? 'Going to Roof…' : `Going to Floor ${target}…`);
  // pull into elevator opening
  const halfL = CONFIG.corridorLength / 2;
  const side = camera.position.x >= 0 ? 1 : -1;
  camera.position.x = side * (halfL - 1.5);
  camera.position.z = 0;
}

function goToFloor(f) {
  startElevatorRide(f);
}

function updateElevatorRide(dt) {
  if (!ridingElevator) return;
  rideTimer -= dt;
  if (rideTimer > 0) return;

  if (ridePhase === 'closing') {
    ridePhase = 'moving';
    // travel time depends on distance
    let dist = 3;
    if (rideTarget === 'roof') {
      dist = currentFloor === 'Roof' ? 1 : (11 - Number(currentFloor || 1));
    } else if (currentFloor === 'Roof') {
      dist = Number(rideTarget);
    } else {
      dist = Math.abs(Number(rideTarget) - Number(currentFloor)) || 1;
    }
    rideTimer = 1.2 + dist * 0.7; // slower = more realistic
    showMsg(rideTarget === 'roof' ? 'Going to Roof…' : `Going to Floor ${rideTarget}…`);
  } else if (ridePhase === 'moving') {
    // arrive
    const mover = camera;
    if (rideTarget === 'roof') {
      mover.position.set(0, CONFIG.floors * CONFIG.floorHeight + CONFIG.playerHeight, 0);
      currentFloor = 'Roof';
      if (floorInd) floorInd.textContent = 'Roof';
      showMsg('Roof');
      ridingElevator = false;
      ridePhase = null;
      if (partsCollected >= TOTAL_PARTS) {
        setTimeout(() => {
          if (winScreen) winScreen.classList.remove('hidden');
          gameOver = true;
        }, 600);
      } else {
        showMsg('Need all 10 parts for the helicopter');
      }
    } else {
      const floorNum = Number(rideTarget);
      const y = (floorNum - 1) * CONFIG.floorHeight + CONFIG.playerHeight;
      const side = camera.position.x >= 0 ? 1 : -1;
      const halfL = CONFIG.corridorLength / 2;
      mover.position.set(side * (halfL - 1.2), y, 0);
      currentFloor = floorNum;
      if (floorInd) floorInd.textContent = `Floor ${floorNum}`;
      // open doors on arrival floor
      ridingElevator = false;
      ridePhase = null;
      showMsg(`Floor ${floorNum}`);
    }
  } else if (ridePhase === 'opening') {
    ridingElevator = false;
    ridePhase = null;
    showMsg('Doors open');
  }
}

function handleMonsterInteract(m) {
  const k = m.userData.kind;
  if (k === 'hungry' && holdingItem === 'meat') {
    holdingItem = null;
    m.userData.alive = false;
    m.visible = false;
    showMsg('Hungry Zombie is satisfied. He leaves.');
  } else if (k === 'whisper') {
    showMsg('Whisper silenced… for now.');
    m.userData.state = 'calm';
  } else {
    showMsg(m.userData.desc);
  }
}

/* -------------------- MONSTER AI -------------------- */
function updateMonsters(dt) {
  if (gameOver) return;
  const playerPos = (isMobile || !controls) ? camera.position : controls.getObject().position;

  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor !== currentFloor && currentFloor !== 'Roof') return;

    // Stunned monsters do nothing
    if (m.userData.stunned) return;

    const kind = m.userData.kind;
    const toPlayer = new THREE.Vector3().subVectors(playerPos, m.position);
    const dist = toPlayer.length();
    toPlayer.y = 0;
    toPlayer.normalize();

    // Is player looking at monster?
    const lookDir = camera.getWorldDirection(new THREE.Vector3());
    const toM = new THREE.Vector3().subVectors(m.position, camera.position).normalize();
    const lookingAt = lookDir.dot(toM) > 0.85 && dist < 12;

    if (kind === 'watcher') {
      if (lookingAt) {
        // freeze
      } else if (dist > 1.5) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      } else kill('The Watcher caught you');
    }
    else if (kind === 'gaze') {
      if (lookingAt) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 2.0) kill('You stared too long at the Gaze Beast');
      } else {
        m.userData.lookTimer = Math.max(0, m.userData.lookTimer - dt * 0.5);
      }
    }
    else if (kind === 'hungry') {
      if (dist > 1.8) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (holdingItem !== 'meat') kill('The Hungry Zombie reached you');
    }
    else if (kind === 'backtext') {
      // if player is looking roughly away from monster while close
      const away = lookDir.dot(toM) < -0.3;
      if (away && dist < 8) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.2) kill('You looked at your back…');
      } else m.userData.lookTimer = 0;
      if (dist > 2) m.position.addScaledVector(toPlayer, m.userData.speed * 0.6 * dt);
    }
    else if (kind === 'stalker') {
      // moves toward where player is going
      const predict = playerPos.clone().add(lookDir.clone().multiplyScalar(3));
      const toPred = new THREE.Vector3().subVectors(predict, m.position);
      toPred.y = 0; toPred.normalize();
      if (dist > 1.6) m.position.addScaledVector(toPred, m.userData.speed * dt);
      else kill('The Pale Girl caught you');
    }
    else if (kind === 'toy') {
      if (holdingItem === 'toy') {
        // follows calmly
        if (dist > 2.5) m.position.addScaledVector(toPlayer, 1.5 * dt);
      } else if (dist < 2.0) {
        // aggressive until toy is placed
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      }
    }
    else if (kind === 'crier') {
      if (lookingAt && Math.abs(joy.x) + Math.abs(joy.y) < 0.1 && !move.f && !move.b && !move.l && !move.r) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.5) {
          m.userData.alive = false;
          m.visible = false;
          showMsg('Blood Crier calmed down and vanished.');
        }
      } else {
        m.userData.lookTimer = 0;
        if (dist > 1.7) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
        else kill('The Blood Crier reached you');
      }
    }
    else if (kind === 'shadowstep') {
      const moving = Math.abs(joy.x) + Math.abs(joy.y) > 0.1 || move.f || move.b || move.l || move.r;
      if (moving && dist > 1.5) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (!moving) { /* frozen */ }
      else kill('Shadow Step touched you');
    }
    else if (kind === 'whisper') {
      if (m.userData.state !== 'calm' && dist < 4) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 4) kill('The Whisper Doll’s voice took you');
      }
    }
  });
}

function kill(reason) {
  if (gameOver) return;
  gameOver = true;
  showMsg(reason, 5000);
  setTimeout(() => location.reload(), 3500);
}

function tryStun() {
  if (gameOver || stunCooldown > 0 || stunActive > 0) return;
  // Stun every monster on the current floor
  let hit = 0;
  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor === currentFloor || currentFloor === 'Roof') {
      m.userData.stunned = true;
      hit++;
    }
  });
  if (hit > 0) {
    stunActive = 3;
    stunCooldown = 15;
    showMsg(`Monster stunned for 3 seconds! (${hit})`);
  } else {
    showMsg('No monster on this floor');
    stunCooldown = 2; // small anti-spam
  }
  updateStunUI();
}

function updateStunUI() {
  const desk = document.getElementById('stun-btn-desktop');
  const setState = (btn, text, disabled) => {
    if (!btn) return;
    btn.disabled = disabled;
    btn.textContent = text;
  };
  if (stunCooldown > 0) {
    const t = Math.ceil(stunCooldown) + 's';
    setState(stunBtn, t, true);
    setState(desk, t, true);
    if (stunCdEl) stunCdEl.textContent = 'Cooldown';
  } else if (stunActive > 0) {
    setState(stunBtn, 'STUNNED', true);
    setState(desk, 'STUNNED', true);
  } else {
    setState(stunBtn, 'STUN', false);
    setState(desk, 'STUN (Q)', false);
    if (stunCdEl) stunCdEl.textContent = 'Ready';
  }
}

/* -------------------- ANIMATION -------------------- */
// Cap at ~45 FPS for stable mobile performance
const FPS_LIMIT = 30;
const FRAME_TIME = 1 / FPS_LIMIT;
let fpsAccum = 0;

function animate() {
  requestAnimationFrame(animate);
  const rawDt = clock.getDelta();
  fpsAccum += rawDt;
  if (fpsAccum < FRAME_TIME) return;
  const dt = Math.min(fpsAccum, 0.05);
  fpsAccum = 0;

  if (gameOver) {
    renderer.render(scene, camera);
    return;
  }

  // Stun timers
  if (stunActive > 0) {
    stunActive -= dt;
    if (stunActive <= 0) {
      stunActive = 0;
      monsters.forEach(m => { m.userData.stunned = false; });
    }
  }
  if (stunCooldown > 0) {
    stunCooldown -= dt;
    if (stunCooldown < 0) stunCooldown = 0;
  }
  updateStunUI();

  const speed = ridingElevator ? 0 : CONFIG.playerSpeed * dt;
  const forward = new THREE.Vector3();
  const right = new THREE.Vector3();
  const mover = isMobile || !controls ? camera : controls.getObject();

  if (isMobile) {
    camera.rotation.order = 'YXZ';
    camera.rotation.y -= lookD.x;
    camera.rotation.x -= lookD.y;
    camera.rotation.x = Math.max(-1.2, Math.min(1.2, camera.rotation.x));
    lookD.x = 0; lookD.y = 0;

    camera.getWorldDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    mover.position.addScaledVector(forward, joy.y * speed);
    mover.position.addScaledVector(right, joy.x * speed);
  } else if (controls && controls.isLocked) {
    controls.getDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    if (move.f) mover.position.addScaledVector(forward, speed);
    if (move.b) mover.position.addScaledVector(forward, -speed);
    if (move.l) mover.position.addScaledVector(right, -speed);
    if (move.r) mover.position.addScaledVector(right, speed);
  }

  // Bounds
  const halfL = CONFIG.corridorLength/2 - 1;
  const halfW = CONFIG.corridorWidth/2 - 0.7;
  mover.position.x = Math.max(-halfL, Math.min(halfL, mover.position.x));
  mover.position.z = Math.max(-halfW, Math.min(halfW, mover.position.z));

  // Floor height lock
  if (currentFloor !== 'Roof') {
    const targetY = (currentFloor - 1) * CONFIG.floorHeight + CONFIG.playerHeight;
    mover.position.y += (targetY - mover.position.y) * 0.3;
  }

  // PERF: only show current floor group (+ roof if needed)
  if (scene.userData.floorGroups) {
    const cf = currentFloor === 'Roof' ? CONFIG.floors : Number(currentFloor);
    scene.userData.floorGroups.forEach((g, i) => {
      const floorNum = i + 1;
      g.visible = (floorNum === cf || floorNum === cf - 1 || floorNum === cf + 1);
    });
  }

    updateElevatorRide(dt);

  // Hint when near elevator (no auto app panel)
  {
    const pos = camera.position;
    let inElev = false;
    if (currentFloor !== 'Roof') {
      for (const el of elevators) {
        if (el.floor !== currentFloor) continue;
        const wp = new THREE.Vector3();
        el.group.getWorldPosition(wp);
        // Standing at the wall elevator opening
        if (Math.abs(pos.x - wp.x) < 2.5 && Math.abs(pos.z - wp.z) < 2.2) {
          inElev = true;
          break;
        }
      }
      // Also detect by corridor ends
      const halfL = CONFIG.corridorLength / 2;
      if (Math.abs(Math.abs(pos.x) - halfL) < 2.8 && Math.abs(pos.z) < 2.5) {
        inElev = true;
      }
    }
    insideElevator = inElev;
    if (inElev && !elevPromptShown && !gameOver && !ridingElevator) {
      elevPromptShown = true;
      showMsg('INTERACT to open floor menu', 2000);
    }
    if (!inElev) elevPromptShown = false;
  }

  // No door animation — elevators always open


  updateMonsters(dt);

  // Part spin only every other frame feel — cheap
  parts.forEach(p => {
    if (!p.userData.collected) p.rotation.y += dt * 0.8;
  });

  renderer.render(scene, camera);
}

function setupUI() {
  // Elevator buttons – large, mobile-friendly
  const box = document.getElementById('elevator-buttons');
  if (box) box.innerHTML = '';
  for (let i = 1; i <= 10; i++) {
    const b = document.createElement('button');
    b.textContent = i;
    b.type = 'button';
    const go = (e) => { e.preventDefault(); goToFloor(i); };
    b.addEventListener('click', go);
    b.addEventListener('touchend', go, { passive: false });
    box.appendChild(b);
  }
  const roofBtn = document.createElement('button');
  roofBtn.textContent = 'ROOF';
  roofBtn.className = 'roof';
  roofBtn.type = 'button';
  const goRoof = (e) => { e.preventDefault(); goToFloor('roof'); };
  roofBtn.addEventListener('click', goRoof);
  roofBtn.addEventListener('touchend', goRoof, { passive: false });
  box.appendChild(roofBtn);

  document.getElementById('elevator-close').onclick = () => {
    elevatorUI.classList.add('hidden');
    elevatorOpen = false;
  };

  // FLOORS HUD button removed — use elevator in the hall

  document.getElementById('dialogue-close').onclick = () => dialogue.classList.add('hidden');
  document.getElementById('restart-btn').onclick = () => location.reload();

  if (stunBtn) {
    stunBtn.addEventListener('click', tryStun);
    stunBtn.addEventListener('touchstart', e => { e.preventDefault(); tryStun(); }, { passive: false });
  }
  const stunDesk = document.getElementById('stun-btn-desktop');
  if (stunDesk) {
    stunDesk.addEventListener('click', tryStun);
  }

  let p = 0;
  const iv = setInterval(() => {
    p += 15;
    progressEl.style.width = Math.min(p, 95) + '%';
    if (p >= 95) clearInterval(iv);
  }, 60);
}

init().catch(console.error);

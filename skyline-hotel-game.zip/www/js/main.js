import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

/* ============================================================
   SKYLINE HOTEL – 10 FLOORS
   Brighter atmosphere + monsters with counters
   ============================================================ */

const CONFIG = {
  floors: 10,
  floorHeight: 4.5,
  corridorWidth: 7,
  corridorLength: 32,
  playerHeight: 1.7,
  playerSpeed: 5.2
};

let scene, camera, renderer, controls;
let currentFloor = 1;
let partsCollected = 0;
const TOTAL_PARTS = 10;
let move = { f: false, b: false, l: false, r: false };
let isMobile = false;
let joy = { x: 0, y: 0 };
let lookD = { x: 0, y: 0 };
let interactables = [];
let monsters = [];
let elevators = []; // {floor, side, doorL, doorR, group, zone}
let insideElevator = false;
let elevPromptShown = false;
let ridingElevator = false;
let rideTimer = 0;
let ridePhase = null; // closing | moving | opening
let rideTarget = null;
let parts = [];
let clock = new THREE.Clock();
let raycaster = new THREE.Raycaster();
let elevatorOpen = false;
let gameOver = false;
let holdingItem = null; // for toy / meat
let stunCooldown = 0;   // seconds remaining before stun can be used again
let stunActive = 0;     // seconds remaining of current stun

// DOM
const loadingEl = document.getElementById('loading');
const progressEl = document.getElementById('progress');
const hud = document.getElementById('hud');
const floorInd = document.getElementById('floor-indicator');
const partsEl = document.getElementById('parts');
const mobileControls = document.getElementById('mobile-controls');
const dialogue = document.getElementById('dialogue');
const npcNameEl = document.getElementById('npc-name');
const npcTextEl = document.getElementById('npc-text');
const winScreen = document.getElementById('win-screen');
const elevatorUI = document.getElementById('elevator-ui');
const msgEl = document.getElementById('msg');
const stunBtn = document.getElementById('stun-btn');
const stunCdEl = document.getElementById('stun-cd');

function showMsg(text, time = 3000) {
  msgEl.textContent = text;
  msgEl.classList.remove('hidden');
  setTimeout(() => msgEl.classList.add('hidden'), time);
}

async function init() {
  // MOBILE ONLY game
  isMobile = true;

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x4a4a5e);
  scene.fog = null; // fog costs FPS on mobile

  camera = new THREE.PerspectiveCamera(72, innerWidth / innerHeight, 0.1, 90);
  camera.position.set(0, CONFIG.playerHeight, 0);
  camera.rotation.order = 'YXZ';
  camera.rotation.y = -Math.PI / 2; // face +X elevator in the end wall
  camera.rotation.order = 'YXZ';

  renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', alpha: false });
  renderer.setSize(innerWidth, innerHeight);
  // Critical for mid-range phones: never above 1
  renderer.setPixelRatio(1);
  renderer.shadowMap.enabled = false;
  document.body.appendChild(renderer.domElement);

  // Cheap lighting only (point lights kill mobile FPS)
  scene.add(new THREE.AmbientLight(0xffffff, 1.4));
  scene.add(new THREE.HemisphereLight(0xffffff, 0x888899, 0.9));

  buildHotel();
  placeParts();
  placeMonsters();
  placeNPCs();

  setupMobile();
  setupKeys();
  setupUI();

  progressEl.style.width = '100%';
  setTimeout(() => {
    loadingEl.classList.add('hidden');
    hud.classList.remove('hidden');
    mobileControls.classList.remove('hidden');
  }, 700);

  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });

  animate();
}

/* -------------------- HOTEL -------------------- */
function buildHotel() {
  // Lambert = much cheaper than Standard on mobile GPUs
  const wallMat = new THREE.MeshLambertMaterial({ color: 0x6a5e52 });
  const floorMat = new THREE.MeshLambertMaterial({ color: 0x5a4e42 });
  const ceilMat  = new THREE.MeshLambertMaterial({ color: 0x4a423a });
  const carpetMat = new THREE.MeshLambertMaterial({ color: 0x8a3a3a });
  const goldMat = new THREE.MeshLambertMaterial({ color: 0xd4a84b });

  scene.userData.floorGroups = [];
  for (let f = 1; f <= CONFIG.floors; f++) {
    const y = (f - 1) * CONFIG.floorHeight;
    const g = new THREE.Group();
    g.position.y = y;
    scene.userData.floorGroups.push(g);

    // Floor
    const slab = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength + 18, 0.3, CONFIG.corridorWidth + 10),
      floorMat
    );
    slab.position.y = -0.15;
    slab.receiveShadow = true;
    g.add(slab);

    // Carpet
    const carpet = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength - 1, 0.02, 2.4),
      carpetMat
    );
    carpet.position.y = 0.01;
    g.add(carpet);

    // Ceiling
    const ceil = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength + 18, 0.2, CONFIG.corridorWidth + 10),
      ceilMat
    );
    ceil.position.y = CONFIG.floorHeight - 0.1;
    g.add(ceil);

    // Walls
    const h = CONFIG.floorHeight - 0.3;
    const long = new THREE.BoxGeometry(CONFIG.corridorLength + 2, h, 0.35);
    const n = new THREE.Mesh(long, wallMat); n.position.set(0, h/2, -CONFIG.corridorWidth/2); g.add(n);
    const s = new THREE.Mesh(long, wallMat); s.position.set(0, h/2,  CONFIG.corridorWidth/2); g.add(s);

    // End walls with CENTER OPENING for elevator (not a solid block)
    const endSideH = (CONFIG.corridorWidth + 1 - 2.6) / 2;
    for (const sx of [1, -1]) {
      const baseX = sx * (CONFIG.corridorLength/2 + 0.2);
      // left and right pillars of end wall
      for (const zSign of [-1, 1]) {
        const pillar = new THREE.Mesh(
          new THREE.BoxGeometry(0.4, h, endSideH),
          wallMat
        );
        const zOff = zSign * (CONFIG.corridorWidth/2 + 0.5 - endSideH/2);
        pillar.position.set(baseX, h/2, zOff);
        g.add(pillar);
      }
      // top lintel above elevator
      const lintel = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 2.8), wallMat);
      lintel.position.set(baseX, h - 0.25, 0);
      g.add(lintel);
    }

    // Fewer room doors (perf)
    for (const i of [-4, -2, 2, 4]) {
      const door = new THREE.Mesh(
        new THREE.BoxGeometry(1.4, 2.4, 0.1),
        new THREE.MeshLambertMaterial({ color: 0x4a3525 })
      );
      door.position.set(i * 3.5, 1.2, i > 0 ? CONFIG.corridorWidth/2 - 0.1 : -CONFIG.corridorWidth/2 + 0.1);
      g.add(door);
    }

    // No small lamps – global bright lighting only

    // Elevator doors both ends
    // Centered on each END of the hall (where crosshair aims)
    createElevator(g,  CONFIG.corridorLength/2 - 1.5, f);
    createElevator(g, -CONFIG.corridorLength/2 + 1.5, f);



    // Floor number
    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 64;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#222'; ctx.fillRect(0,0,128,64);
    ctx.fillStyle = '#d4a84b'; ctx.font = 'bold 36px system-ui';
    ctx.textAlign = 'center'; ctx.fillText('F' + f, 64, 44);
    const tex = new THREE.CanvasTexture(canvas);
    const label = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.7), new THREE.MeshBasicMaterial({ map: tex }));
    label.position.set(0, 2.4, -CONFIG.corridorWidth/2 + 0.2);
    g.add(label);

    scene.add(g);
  }

  // Roof + helicopter
  const roofY = CONFIG.floors * CONFIG.floorHeight;
  const roof = new THREE.Group();
  roof.position.y = roofY;

  const roofSlab = new THREE.Mesh(
    new THREE.BoxGeometry(42, 0.4, 32),
    new THREE.MeshStandardMaterial({ color: 0x333333 })
  );
  roofSlab.position.y = 0.2;
  roof.add(roofSlab);

  const pad = new THREE.Mesh(
    new THREE.CylinderGeometry(6, 6, 0.15, 32),
    new THREE.MeshStandardMaterial({ color: 0x222222 })
  );
  pad.position.y = 0.35;
  roof.add(pad);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(4.5, 5, 32),
    new THREE.MeshBasicMaterial({ color: 0xd4a84b, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI/2;
  ring.position.y = 0.43;
  roof.add(ring);

  const heli = createHelicopter();
  heli.position.set(0, 1.9, 0);
  roof.add(heli);

  // no point light on roof (perf)

  scene.add(roof);
}







function createElevator(parent, x, floorNum) {
  // ALWAYS OPEN portal centered on the end of the hallway (no doors)
  const side = x > 0 ? 1 : -1;
  const group = new THREE.Group();
  group.position.set(x, 0, 0);

  const gold = new THREE.MeshLambertMaterial({ color: 0xd4a84b });
  const dark = new THREE.MeshLambertMaterial({ color: 0x1a1a22 });
  const metal = new THREE.MeshLambertMaterial({ color: 0x6a6a72 });
  const green = new THREE.MeshLambertMaterial({ color: 0x33ff66 });

  // Gold frame centered on corridor (z=0) — dead ahead of player
  // Top bar
  const top = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, 2.8), gold);
  top.position.set(0, 2.85, 0);
  group.add(top);
  // Bottom sill
  const bot = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.2, 2.8), gold);
  bot.position.set(0, 0.1, 0);
  group.add(bot);
  // Left post
  const left = new THREE.Mesh(new THREE.BoxGeometry(0.35, 2.9, 0.35), gold);
  left.position.set(0, 1.45, -1.4);
  group.add(left);
  // Right post
  const right = new THREE.Mesh(new THREE.BoxGeometry(0.35, 2.9, 0.35), gold);
  right.position.set(0, 1.45, 1.4);
  group.add(right);

  // Dark open shaft (always open — no doors)
  const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.8, 2.6, 2.3), dark);
  shaft.position.set(-side * 0.4, 1.4, 0);
  group.add(shaft);

  // Cabin back wall so it looks deep
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.15, 2.5, 2.2), metal);
  back.position.set(-side * 1.4, 1.4, 0);
  group.add(back);
  const cFloor = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.1, 2.2), dark);
  cFloor.position.set(-side * 0.7, 0.05, 0);
  group.add(cFloor);

  // Green "open" light on top
  const lite = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.2, 1.8), green);
  lite.position.set(side * 0.05, 3.15, 0);
  group.add(lite);

  // Invisible hitbox for INTERACT → floor menu
  const hit = new THREE.Mesh(
    new THREE.BoxGeometry(2.5, 3.2, 3.2),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hit.position.set(-side * 0.5, 1.5, 0);
  hit.userData = { type: 'elevator', floor: floorNum };
  group.add(hit);
  interactables.push(hit);

  parent.add(group);
  elevators.push({
    floor: floorNum,
    side,
    doorL: null,
    doorR: null,
    closedZL: 0,
    closedZR: 0,
    group,
    openAmount: 1,
    targetOpen: 1
  });
}

function createHelicopter() {
  const g = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x2a2a2a, metalness: 0.5, roughness: 0.4 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(1, 2.4, 4, 12), bodyMat);
  body.rotation.z = Math.PI/2;
  g.add(body);
  const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.28, 3.2, 8), bodyMat);
  tail.rotation.z = Math.PI/2;
  tail.position.set(-2.8, 0.25, 0);
  g.add(tail);
  const rotor = new THREE.Mesh(new THREE.BoxGeometry(7.5, 0.1, 0.4), new THREE.MeshStandardMaterial({ color: 0x111 }));
  rotor.position.y = 1.25;
  g.add(rotor);
  return g;
}

/* -------------------- PARTS (1 per floor) -------------------- */
function placeParts() {
  for (let f = 1; f <= 10; f++) {
    const part = createPart(f);
    const y = (f - 1) * CONFIG.floorHeight + 0.5;
    const side = (f % 2 === 0) ? 1 : -1;
    part.position.set((Math.random() * 10 - 5), y, side * 1.8);
    part.userData = { type: 'part', id: f, collected: false, floor: f };
    scene.add(part);
    parts.push(part);
    interactables.push(part);
  }
}

function createPart(id) {
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({
    color: 0xd4a84b, metalness: 0.7, roughness: 0.3,
    emissive: 0x3a2a10, emissiveIntensity: 0.4
  });
  let mesh;
  if (id % 3 === 0) mesh = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.4, 0.55), mat);
  else if (id % 3 === 1) mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.65, 10), mat);
  else mesh = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.12, 8, 16), mat);
  g.add(mesh);
  // no point light (mobile perf)
  return g;
}

/* -------------------- MONSTERS -------------------- */

function placeMonsters() {
  // 9 enemies from concept gallery
  addMonster({
    name: 'The Watcher',
    floor: 2,
    pos: [8, 0, 1.4],
    color: 0x2a2a28,
    type: 'watcher',
    speed: 2.6,
    desc: 'Keep looking at him or he comes.'
  });
  addMonster({
    name: 'Gaze Beast',
    floor: 3,
    pos: [-9, 0, -1.5],
    color: 0x2e2a24,
    type: 'gaze',
    speed: 1.4,
    desc: 'Do not stare more than 2 seconds.'
  });
  addMonster({
    name: 'Hungry Zombie',
    floor: 4,
    pos: [6, 0, 1.6],
    color: 0x6b8a72,
    type: 'hungry',
    speed: 3.0,
    desc: 'Find meat and give it to him.'
  });
  addMonster({
    name: 'Backwatcher',
    floor: 5,
    pos: [-7, 0, -1.3],
    color: 0x1c1a17,
    type: 'backtext',
    speed: 2.0,
    desc: 'Never look behind near him.'
  });
  addMonster({
    name: 'Pale Woman',
    floor: 6,
    pos: [4, 0, 1.7],
    color: 0x141315,
    type: 'stalker',
    speed: 2.3,
    desc: 'She cuts you off. Keep changing path.'
  });
  addMonster({
    name: 'Toy Doll',
    floor: 7,
    pos: [-5, 0, -1.6],
    color: 0x2a2024,
    type: 'toy',
    speed: 1.7,
    desc: 'Put the toy in the box to calm her.'
  });
  addMonster({
    name: 'Blood Crier',
    floor: 8,
    pos: [9, 0, 1.2],
    color: 0xd8d2c6,
    type: 'crier',
    speed: 2.5,
    desc: 'Stand still and look at his face.'
  });
  addMonster({
    name: 'Shadow Step',
    floor: 9,
    pos: [-8, 0, 1.4],
    color: 0x070708,
    type: 'shadowstep',
    speed: 3.8,
    desc: 'Only moves when you move. Stand still.'
  });
  addMonster({
    name: 'Whisper Doll',
    floor: 1,
    pos: [0, 0, -2],
    color: 0x3a3228,
    type: 'whisper',
    speed: 1.1,
    desc: 'Interact to silence her whisper.'
  });
}

function addMonster(data) {
  const m = createMonsterMesh(data.color, data.name, data.type);
  const y = (data.floor - 1) * CONFIG.floorHeight;
  m.position.set(data.pos[0], y, data.pos[2]);
  m.userData = {
    type: 'monster',
    kind: data.type,
    name: data.name,
    speed: data.speed,
    floor: data.floor,
    alive: true,
    lookTimer: 0,
    state: 'idle',
    desc: data.desc,
    stunned: false
  };
  scene.add(m);
  monsters.push(m);
  interactables.push(m);
}





function createMonsterMesh(color, name, kind) {
  // Matched to Claude horror gallery concept art
  const g = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({ color: 0xb7ab97, roughness: 0.82 });
  const pale = new THREE.MeshStandardMaterial({ color: 0xd8cebd, roughness: 0.78 });
  const dead = new THREE.MeshStandardMaterial({ color: 0x6b8a72, roughness: 0.88 });
  const cloth = new THREE.MeshStandardMaterial({ color: 0x1a1a18, roughness: 0.92 });
  const clothGrey = new THREE.MeshStandardMaterial({ color: 0x4a4238, roughness: 0.9 });
  const whiteShirt = new THREE.MeshStandardMaterial({ color: 0xd8d2c6, roughness: 0.85 });
  const blackSuit = new THREE.MeshStandardMaterial({ color: 0x141315, roughness: 0.55, metalness: 0.1 });
  const hairM = new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: 1 });
  const fur = new THREE.MeshStandardMaterial({ color: 0x2e2a24, roughness: 1 });
  const blood = new THREE.MeshStandardMaterial({ color: 0x6b1414, roughness: 0.55, emissive: 0x3a0000, emissiveIntensity: 0.35 });
  const voidEye = new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: 0.2 });
  const redGlow = new THREE.MeshStandardMaterial({ color: 0x8a1414, emissive: 0x8a1414, emissiveIntensity: 2, toneMapped: false });

  if (kind === 'gaze') {
    // Gaze Beast — hunched multi-eye animal hybrid (gallery #2)
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.6, 16, 14), fur);
    body.position.set(0, 0.95, 0); body.scale.set(1.15, 0.95, 1.35); g.add(body);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.38, 14, 12), fur);
    head.position.set(0, 1.45, 0.4); g.add(head);
    const snout = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.45, 8), fur);
    snout.rotation.x = Math.PI/2; snout.position.set(0, 1.35, 0.75); g.add(snout);
    for (let i = 0; i < 12; i++) {
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 6), voidEye);
      const a = (i/12)*Math.PI*2;
      e.position.set(Math.cos(a)*0.22, 1.5+Math.sin(a)*0.14, 0.55);
      g.add(e);
      const p = new THREE.Mesh(new THREE.SphereGeometry(0.015, 6, 4), redGlow);
      p.position.copy(e.position); p.position.z += 0.03; g.add(p);
    }
    for (const s of [-1,1]) {
      const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.11, 0.55, 4, 6), fur);
      leg.position.set(s*0.28, 0.38, 0.1); g.add(leg);
    }
  } else if (kind === 'backtext') {
    // Backwatcher — face twisted backward (gallery #4)
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 0.55, 6, 10), cloth);
    torso.position.y = 1.3; g.add(torso);
    for (const s of [-1,1]) {
      const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.11, 0.75, 4, 6), fur);
      leg.position.set(s*0.13, 0.48, 0); leg.rotation.x = 0.25; g.add(leg);
      const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.55, 4, 6), cloth);
      arm.position.set(s*0.42, 1.25, 0); g.add(arm);
    }
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 14, 12), skin);
    head.position.set(0, 1.88, -0.18); head.rotation.y = Math.PI; g.add(head);
    for (const x of [-0.07, 0.07]) {
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 6), redGlow);
      e.position.set(x, 1.9, -0.36); g.add(e);
    }
  } else if (kind === 'shadowstep') {
    // Shadow Step — pure black + red eyes (gallery #8)
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.2, 1.3, 6, 10),
      new THREE.MeshStandardMaterial({ color: 0x050506, roughness: 1 }));
    body.position.y = 1.45; body.scale.x = 0.7; g.add(body);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.17, 10, 8),
      new THREE.MeshStandardMaterial({ color: 0x080809 }));
    head.position.y = 2.25; g.add(head);
    for (const x of [-0.05, 0.05]) {
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 6), redGlow);
      e.position.set(x, 2.27, 0.14); g.add(e);
    }
    // no point light
  } else if (kind === 'stalker') {
    // Pale Woman — black suit, hair over face (gallery #5)
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.28, 0.65, 6, 12), blackSuit);
    torso.position.y = 1.35; g.add(torso);
    const jacket = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.6, 0.35), blackSuit);
    jacket.position.y = 1.42; g.add(jacket);
    for (const s of [-1,1]) {
      const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.7, 4, 8), blackSuit);
      leg.position.set(s*0.12, 0.5, 0); g.add(leg);
      const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.55, 4, 6), pale);
      arm.position.set(s*0.4, 1.35, 0); arm.rotation.z = s*0.2; g.add(arm);
    }
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 14, 12), pale);
    head.position.y = 1.95; g.add(head);
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.26, 12, 10), hairM);
    hair.position.set(0, 2.0, 0.05); hair.scale.set(1.25, 1.35, 1.3); g.add(hair);
    for (let i = 0; i < 8; i++) {
      const s = new THREE.Mesh(new THREE.CapsuleGeometry(0.03, 0.55, 3, 5), hairM);
      s.position.set((i-3.5)*0.05, 1.65, 0.22); s.rotation.x = 0.55; g.add(s);
    }
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 6), voidEye);
    eye.position.set(0.09, 1.95, 0.22); g.add(eye);
  } else if (kind === 'crier') {
    // Blood Crier — white shirt, blood, open mouth (gallery #7)
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.3, 0.7, 6, 12), whiteShirt);
    torso.position.y = 1.35; g.add(torso);
    for (let i = 0; i < 3; i++) {
      const stain = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 6), blood);
      stain.position.set(-0.1+i*0.1, 1.5-i*0.15, 0.25); stain.scale.set(1.2, 0.5, 0.35); g.add(stain);
    }
    for (const s of [-1,1]) {
      const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.7, 4, 8), cloth);
      leg.position.set(s*0.13, 0.5, 0); g.add(leg);
      const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.55, 4, 6), pale);
      arm.position.set(s*0.42, 1.4, 0.1); arm.rotation.z = s*0.5; arm.rotation.x = -0.4; g.add(arm);
    }
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 14, 12), pale);
    head.position.y = 1.98; g.add(head);
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 8), hairM);
    hair.position.set(0, 2.12, -0.05); hair.scale.set(1, 0.45, 1); g.add(hair);
    for (const x of [-0.07, 0.07]) {
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 6), voidEye);
      e.position.set(x, 2.0, 0.18); g.add(e);
      const tear = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.16, 0.02), blood);
      tear.position.set(x, 1.9, 0.2); g.add(tear);
    }
    const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.12, 0.1), blood);
    mouth.position.set(0, 1.85, 0.2); g.add(mouth);
  } else if (kind === 'toy') {
    // Toy Doll — porcelain, dark dress (gallery #6)
    const dress = new THREE.Mesh(new THREE.ConeGeometry(0.5, 1.0, 12),
      new THREE.MeshStandardMaterial({ color: 0x2a2024, roughness: 0.85 }));
    dress.position.y = 0.9; g.add(dress);
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.25, 0.35, 6, 10),
      new THREE.MeshStandardMaterial({ color: 0x332630 }));
    torso.position.y = 1.45; g.add(torso);
    for (const s of [-1,1]) {
      const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.45, 4, 6), pale);
      arm.position.set(s*0.35, 1.4, 0); g.add(arm);
    }
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.23, 14, 12),
      new THREE.MeshStandardMaterial({ color: 0xeee3d3, roughness: 0.45 }));
    head.position.y = 1.9; g.add(head);
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.22, 10, 8), hairM);
    hair.position.set(0, 2.05, -0.02); hair.scale.set(1.15, 0.55, 1.1); g.add(hair);
    for (const x of [-0.07, 0.07]) {
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 6),
        new THREE.MeshStandardMaterial({ color: 0x4a6a8a }));
      e.position.set(x, 1.92, 0.2); g.add(e);
      const p = new THREE.Mesh(new THREE.SphereGeometry(0.02, 6, 4), voidEye);
      p.position.set(x, 1.92, 0.24); g.add(p);
    }
    const smile = new THREE.Mesh(new THREE.TorusGeometry(0.07, 0.015, 6, 12, Math.PI),
      new THREE.MeshStandardMaterial({ color: 0x8a3838 }));
    smile.position.set(0, 1.82, 0.2); smile.rotation.x = Math.PI; g.add(smile);
  } else if (kind === 'hungry' || kind === 'whisper') {
    // Hungry Zombie / Whisper Doll base
    const isWhisper = kind === 'whisper';
    const scale = isWhisper ? 0.85 : 1;
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.3*scale, 0.65*scale, 6, 12), clothGrey);
    torso.position.y = 1.3*scale; g.add(torso);
    if (!isWhisper) {
      const wound = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 6), blood);
      wound.position.set(0.18, 1.35, 0.28); g.add(wound);
    }
    for (const s of [-1,1]) {
      const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.1*scale, 0.7*scale, 4, 8), cloth);
      leg.position.set(s*0.12*scale, 0.48*scale, 0); g.add(leg);
      const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.08*scale, 0.55*scale, 4, 6), dead);
      arm.position.set(s*0.4*scale, 1.45*scale, 0.15); arm.rotation.z = s*0.6; arm.rotation.x = -0.8; g.add(arm);
    }
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.22*scale, 14, 12), dead);
    head.position.y = 1.95*scale; g.add(head);
    for (const x of [-0.07, 0.07]) {
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), voidEye);
      e.position.set(x*scale, 1.98*scale, 0.18*scale); g.add(e);
    }
    const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.12*scale, isWhisper?0.08:0.06, 0.06),
      new THREE.MeshStandardMaterial({ color: 0x1c1414 }));
    mouth.position.set(0, 1.86*scale, 0.2*scale); g.add(mouth);
  } else {
    // The Watcher — tall gaunt hotel man (gallery #1)
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 0.75, 6, 12), cloth);
    torso.position.y = 1.4; torso.scale.x = 0.85; g.add(torso);
    for (const s of [-1,1]) {
      const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.8, 4, 8), cloth);
      leg.position.set(s*0.11, 0.52, 0); g.add(leg);
      const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.7, 4, 6), skin);
      arm.position.set(s*0.36, 1.35, 0); arm.rotation.z = s*0.15; g.add(arm);
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 6), skin);
      hand.position.set(s*0.42, 0.9, 0.05); hand.scale.set(1, 1.4, 0.7); g.add(hand);
    }
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 14, 12), skin);
    head.position.y = 2.05; head.scale.set(0.9, 1.15, 0.9); g.add(head);
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 8), hairM);
    hair.position.set(0, 2.2, -0.04); hair.scale.set(1.05, 0.4, 1); g.add(hair);
    for (const x of [-0.07, 0.07]) {
      const sock = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), voidEye);
      sock.position.set(x, 2.05, 0.16); sock.scale.z = 0.5; g.add(sock);
      const pin = new THREE.Mesh(new THREE.SphereGeometry(0.015, 6, 4), voidEye);
      pin.position.set(x, 2.05, 0.19); g.add(pin);
    }
  }

  // Name plate
  const canvas = document.createElement('canvas');
  canvas.width = 256; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(10,0,0,0.88)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.strokeStyle = '#cc2222';
  ctx.lineWidth = 2;
  ctx.strokeRect(2, 2, 252, 60);
  ctx.fillStyle = '#ff6666';
  ctx.font = 'bold 18px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText(name, 128, 40);
  const tex = new THREE.CanvasTexture(canvas);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  spr.scale.set(1.9, 0.48, 1);
  spr.position.y = 2.6;
  g.add(spr);
  return g;
}

/* -------------------- ITEMS for counters -------------------- */
function placeNPCs() {
  // Meat on floor 4
  const meat = createItem(0x8b0000, 'meat');
  meat.position.set(-4, (4-1)*CONFIG.floorHeight + 0.4, 1.5);
  meat.userData = { type: 'item', item: 'meat' };
  scene.add(meat);
  interactables.push(meat);

  // Toy on floor 7
  const toy = createItem(0xff69b4, 'toy');
  toy.position.set(7, (7-1)*CONFIG.floorHeight + 0.4, -1.6);
  toy.userData = { type: 'item', item: 'toy' };
  scene.add(toy);
  interactables.push(toy);

  // Box on floor 7
  const box = new THREE.Mesh(
    new THREE.BoxGeometry(0.8, 0.5, 0.8),
    new THREE.MeshStandardMaterial({ color: 0x5a3a1a })
  );
  box.position.set(-2, (7-1)*CONFIG.floorHeight + 0.3, 1.7);
  box.userData = { type: 'box' };
  scene.add(box);
  interactables.push(box);
}

function createItem(color, name) {
  const g = new THREE.Group();
  const m = new THREE.Mesh(
    new THREE.SphereGeometry(0.25, 10, 8),
    new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.3 })
  );
  g.add(m);
  // no point light
  return g;
}

/* -------------------- CONTROLS -------------------- */
function setupKeys() {
  const on = (e, p) => {
    switch (e.code) {
      case 'KeyW': case 'ArrowUp':    move.f = p; break;
      case 'KeyS': case 'ArrowDown':  move.b = p; break;
      case 'KeyA': case 'ArrowLeft':  move.l = p; break;
      case 'KeyD': case 'ArrowRight': move.r = p; break;
      case 'KeyE': case 'Space': if (p) tryInteract(); break;
      case 'KeyQ': case 'KeyF': if (p) tryStun(); break;
    }
  };
  addEventListener('keydown', e => on(e, true));
  addEventListener('keyup',   e => on(e, false));
}

function setupMobile() {
  const base = document.getElementById('joystick-base');
  const stick = document.getElementById('joystick-stick');
  const lookZone = document.getElementById('look-zone');
  const interactBtn = document.getElementById('interact-btn');

  let joyId = null, lookId = null, last = { x:0, y:0 };

  base.addEventListener('touchstart', e => {
    e.preventDefault();
    joyId = e.changedTouches[0].identifier;
  }, { passive: false });

  addEventListener('touchmove', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        const r = base.getBoundingClientRect();
        const cx = r.left + r.width/2, cy = r.top + r.height/2;
        let dx = t.clientX - cx, dy = t.clientY - cy;
        const max = r.width/2 - 8;
        const len = Math.hypot(dx, dy);
        if (len > max) { dx = dx/len*max; dy = dy/len*max; }
        stick.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
        joy.x = dx / max;
        joy.y = -dy / max;
      }
      if (t.identifier === lookId) {
        lookD.x += (t.clientX - last.x) * 0.004;
        lookD.y += (t.clientY - last.y) * 0.004;
        last.x = t.clientX; last.y = t.clientY;
      }
    }
  }, { passive: false });

  addEventListener('touchend', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        joyId = null;
        stick.style.transform = 'translate(-50%, -50%)';
        joy.x = 0; joy.y = 0;
      }
      if (t.identifier === lookId) lookId = null;
    }
  });

  lookZone.addEventListener('touchstart', e => {
    e.preventDefault();
    lookId = e.changedTouches[0].identifier;
    last.x = e.changedTouches[0].clientX;
    last.y = e.changedTouches[0].clientY;
  }, { passive: false });

  interactBtn.addEventListener('touchstart', e => {
    e.preventDefault();
    tryInteract();
  }, { passive: false });
}

/* -------------------- INTERACTION + ELEVATOR -------------------- */
function tryInteract() {
  if (gameOver) return;
  // If elevator panel is already open, ignore
  if (elevatorOpen && elevatorUI && !elevatorUI.classList.contains('hidden')) return;

  const origin = camera.getWorldPosition(new THREE.Vector3());
  const dir = camera.getWorldDirection(new THREE.Vector3());
  raycaster.set(origin, dir);
  raycaster.far = 4.0;

  const hits = raycaster.intersectObjects(interactables, true);
  let obj = null;
  if (hits.length) {
    obj = hits[0].object;
    while (obj && !obj.userData.type) obj = obj.parent;
  }

  // Proximity fallback for elevators (so it always works near doors)
  if (!obj || (obj.userData.type !== 'elevator' && obj.userData.type !== 'elevator-btn')) {
    const mover = isMobile || !controls ? camera.position : controls.getObject().position;
    const nearElev = interactables.find(o => {
      if (!o.userData || (o.userData.type !== 'elevator' && o.userData.type !== 'elevator-btn')) return false;
      const wp = new THREE.Vector3();
      o.getWorldPosition(wp);
      return wp.distanceTo(mover) < 4.5 && Math.abs(wp.y - mover.y) < 3.0;
    });
    if (nearElev) obj = nearElev;
  }

  if (!obj) return;
  const d = obj.userData;

  if (d.type === 'part' && !d.collected) {
    d.collected = true;
    partsCollected++;
    partsEl.textContent = `Parts: ${partsCollected} / ${TOTAL_PARTS}`;
    obj.visible = false;
    showMsg(`Part ${d.id} collected!`);
    if (partsCollected >= TOTAL_PARTS) {
      document.getElementById('objective').textContent = 'All parts found! Go to the roof and fix the helicopter.';
    }
  }
  else if (d.type === 'floor-btn') {
    startElevatorRide(d.targetFloor);
  }
  else if (d.type === 'elevator' || d.type === 'elevator-btn') {
    openElevatorUI(); // floor menu
  }
  else if (d.type === 'item') {
    holdingItem = d.item;
    obj.visible = false;
    showMsg(`Picked up ${d.item}`);
  }
  else if (d.type === 'box' && holdingItem === 'toy') {
    holdingItem = null;
    showMsg('Toy placed in the box. Toy Girl is calm and shows the part.');
  }
  else if (d.type === 'monster') {
    handleMonsterInteract(obj);
  }
}



function openElevatorUI() {
  // Minimal panel only as backup — prefer 3D buttons inside cabin
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (!ui) return;
  elevatorOpen = true;
  const box = document.getElementById('elevator-buttons');
  if (box) {
    [...box.querySelectorAll('button')].forEach(b => {
      b.classList.remove('current');
      if (String(currentFloor) === b.textContent || (currentFloor === 'Roof' && b.textContent === 'ROOF')) {
        b.classList.add('current');
      }
    });
  }
  const label = document.getElementById('elevator-current');
  if (label) label.textContent = currentFloor === 'Roof' ? 'Now: Roof' : `Now: Floor ${currentFloor}`;
  ui.classList.remove('hidden');
}

function startElevatorRide(target) {
  if (ridingElevator || gameOver) return;
  if (target !== 'roof' && Number(target) === Number(currentFloor)) {
    showMsg('Already here');
    return;
  }
  // close HTML panel if open
  const ui = document.getElementById('elevator-ui') || elevatorUI;
  if (ui) ui.classList.add('hidden');
  elevatorOpen = false;

  ridingElevator = true;
  rideTarget = target;
  ridePhase = 'moving';
  let dist = 2;
  if (target === 'roof') dist = currentFloor === 'Roof' ? 1 : (11 - Number(currentFloor || 1));
  else if (currentFloor === 'Roof') dist = Number(target);
  else dist = Math.abs(Number(target) - Number(currentFloor)) || 1;
  rideTimer = 1.0 + dist * 0.65;
  showMsg(target === 'roof' ? 'Going to Roof…' : `Going to Floor ${target}…`);
  // pull into elevator opening
  const halfL = CONFIG.corridorLength / 2;
  const side = camera.position.x >= 0 ? 1 : -1;
  camera.position.x = side * (halfL - 1.5);
  camera.position.z = 0;
}

function goToFloor(f) {
  startElevatorRide(f);
}

function updateElevatorRide(dt) {
  if (!ridingElevator) return;
  rideTimer -= dt;
  if (rideTimer > 0) return;

  if (ridePhase === 'closing') {
    ridePhase = 'moving';
    // travel time depends on distance
    let dist = 3;
    if (rideTarget === 'roof') {
      dist = currentFloor === 'Roof' ? 1 : (11 - Number(currentFloor || 1));
    } else if (currentFloor === 'Roof') {
      dist = Number(rideTarget);
    } else {
      dist = Math.abs(Number(rideTarget) - Number(currentFloor)) || 1;
    }
    rideTimer = 1.2 + dist * 0.7; // slower = more realistic
    showMsg(rideTarget === 'roof' ? 'Going to Roof…' : `Going to Floor ${rideTarget}…`);
  } else if (ridePhase === 'moving') {
    // arrive
    const mover = camera;
    if (rideTarget === 'roof') {
      mover.position.set(0, CONFIG.floors * CONFIG.floorHeight + CONFIG.playerHeight, 0);
      currentFloor = 'Roof';
      if (floorInd) floorInd.textContent = 'Roof';
      showMsg('Roof');
      ridingElevator = false;
      ridePhase = null;
      if (partsCollected >= TOTAL_PARTS) {
        setTimeout(() => {
          if (winScreen) winScreen.classList.remove('hidden');
          gameOver = true;
        }, 600);
      } else {
        showMsg('Need all 10 parts for the helicopter');
      }
    } else {
      const floorNum = Number(rideTarget);
      const y = (floorNum - 1) * CONFIG.floorHeight + CONFIG.playerHeight;
      const side = camera.position.x >= 0 ? 1 : -1;
      const halfL = CONFIG.corridorLength / 2;
      mover.position.set(side * (halfL - 1.2), y, 0);
      currentFloor = floorNum;
      if (floorInd) floorInd.textContent = `Floor ${floorNum}`;
      // open doors on arrival floor
      ridingElevator = false;
      ridePhase = null;
      showMsg(`Floor ${floorNum}`);
    }
  } else if (ridePhase === 'opening') {
    ridingElevator = false;
    ridePhase = null;
    showMsg('Doors open');
  }
}

function handleMonsterInteract(m) {
  const k = m.userData.kind;
  if (k === 'hungry' && holdingItem === 'meat') {
    holdingItem = null;
    m.userData.alive = false;
    m.visible = false;
    showMsg('Hungry Zombie is satisfied. He leaves.');
  } else if (k === 'whisper') {
    showMsg('Whisper silenced… for now.');
    m.userData.state = 'calm';
  } else {
    showMsg(m.userData.desc);
  }
}

/* -------------------- MONSTER AI -------------------- */
function updateMonsters(dt) {
  if (gameOver) return;
  const playerPos = (isMobile || !controls) ? camera.position : controls.getObject().position;

  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor !== currentFloor && currentFloor !== 'Roof') return;

    // Stunned monsters do nothing
    if (m.userData.stunned) return;

    const kind = m.userData.kind;
    const toPlayer = new THREE.Vector3().subVectors(playerPos, m.position);
    const dist = toPlayer.length();
    toPlayer.y = 0;
    toPlayer.normalize();

    // Is player looking at monster?
    const lookDir = camera.getWorldDirection(new THREE.Vector3());
    const toM = new THREE.Vector3().subVectors(m.position, camera.position).normalize();
    const lookingAt = lookDir.dot(toM) > 0.85 && dist < 12;

    if (kind === 'watcher') {
      if (lookingAt) {
        // freeze
      } else if (dist > 1.5) {
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      } else kill('The Watcher caught you');
    }
    else if (kind === 'gaze') {
      if (lookingAt) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 2.0) kill('You stared too long at the Gaze Beast');
      } else {
        m.userData.lookTimer = Math.max(0, m.userData.lookTimer - dt * 0.5);
      }
    }
    else if (kind === 'hungry') {
      if (dist > 1.8) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (holdingItem !== 'meat') kill('The Hungry Zombie reached you');
    }
    else if (kind === 'backtext') {
      // if player is looking roughly away from monster while close
      const away = lookDir.dot(toM) < -0.3;
      if (away && dist < 8) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.2) kill('You looked at your back…');
      } else m.userData.lookTimer = 0;
      if (dist > 2) m.position.addScaledVector(toPlayer, m.userData.speed * 0.6 * dt);
    }
    else if (kind === 'stalker') {
      // moves toward where player is going
      const predict = playerPos.clone().add(lookDir.clone().multiplyScalar(3));
      const toPred = new THREE.Vector3().subVectors(predict, m.position);
      toPred.y = 0; toPred.normalize();
      if (dist > 1.6) m.position.addScaledVector(toPred, m.userData.speed * dt);
      else kill('The Pale Girl caught you');
    }
    else if (kind === 'toy') {
      if (holdingItem === 'toy') {
        // follows calmly
        if (dist > 2.5) m.position.addScaledVector(toPlayer, 1.5 * dt);
      } else if (dist < 2.0) {
        // aggressive until toy is placed
        m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      }
    }
    else if (kind === 'crier') {
      if (lookingAt && Math.abs(joy.x) + Math.abs(joy.y) < 0.1 && !move.f && !move.b && !move.l && !move.r) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 1.5) {
          m.userData.alive = false;
          m.visible = false;
          showMsg('Blood Crier calmed down and vanished.');
        }
      } else {
        m.userData.lookTimer = 0;
        if (dist > 1.7) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
        else kill('The Blood Crier reached you');
      }
    }
    else if (kind === 'shadowstep') {
      const moving = Math.abs(joy.x) + Math.abs(joy.y) > 0.1 || move.f || move.b || move.l || move.r;
      if (moving && dist > 1.5) m.position.addScaledVector(toPlayer, m.userData.speed * dt);
      else if (!moving) { /* frozen */ }
      else kill('Shadow Step touched you');
    }
    else if (kind === 'whisper') {
      if (m.userData.state !== 'calm' && dist < 4) {
        m.userData.lookTimer += dt;
        if (m.userData.lookTimer > 4) kill('The Whisper Doll’s voice took you');
      }
    }
  });
}

function kill(reason) {
  if (gameOver) return;
  gameOver = true;
  showMsg(reason, 5000);
  setTimeout(() => location.reload(), 3500);
}

function tryStun() {
  if (gameOver || stunCooldown > 0 || stunActive > 0) return;
  // Stun every monster on the current floor
  let hit = 0;
  monsters.forEach(m => {
    if (!m.userData.alive) return;
    if (m.userData.floor === currentFloor || currentFloor === 'Roof') {
      m.userData.stunned = true;
      hit++;
    }
  });
  if (hit > 0) {
    stunActive = 3;
    stunCooldown = 15;
    showMsg(`Monster stunned for 3 seconds! (${hit})`);
  } else {
    showMsg('No monster on this floor');
    stunCooldown = 2; // small anti-spam
  }
  updateStunUI();
}

function updateStunUI() {
  const desk = document.getElementById('stun-btn-desktop');
  const setState = (btn, text, disabled) => {
    if (!btn) return;
    btn.disabled = disabled;
    btn.textContent = text;
  };
  if (stunCooldown > 0) {
    const t = Math.ceil(stunCooldown) + 's';
    setState(stunBtn, t, true);
    setState(desk, t, true);
    if (stunCdEl) stunCdEl.textContent = 'Cooldown';
  } else if (stunActive > 0) {
    setState(stunBtn, 'STUNNED', true);
    setState(desk, 'STUNNED', true);
  } else {
    setState(stunBtn, 'STUN', false);
    setState(desk, 'STUN (Q)', false);
    if (stunCdEl) stunCdEl.textContent = 'Ready';
  }
}

/* -------------------- ANIMATION -------------------- */
// Cap at ~45 FPS for stable mobile performance
const FPS_LIMIT = 30;
const FRAME_TIME = 1 / FPS_LIMIT;
let fpsAccum = 0;

function animate() {
  requestAnimationFrame(animate);
  const rawDt = clock.getDelta();
  fpsAccum += rawDt;
  if (fpsAccum < FRAME_TIME) return;
  const dt = Math.min(fpsAccum, 0.05);
  fpsAccum = 0;

  if (gameOver) {
    renderer.render(scene, camera);
    return;
  }

  // Stun timers
  if (stunActive > 0) {
    stunActive -= dt;
    if (stunActive <= 0) {
      stunActive = 0;
      monsters.forEach(m => { m.userData.stunned = false; });
    }
  }
  if (stunCooldown > 0) {
    stunCooldown -= dt;
    if (stunCooldown < 0) stunCooldown = 0;
  }
  updateStunUI();

  const speed = ridingElevator ? 0 : CONFIG.playerSpeed * dt;
  const forward = new THREE.Vector3();
  const right = new THREE.Vector3();
  const mover = isMobile || !controls ? camera : controls.getObject();

  if (isMobile) {
    camera.rotation.order = 'YXZ';
    camera.rotation.y -= lookD.x;
    camera.rotation.x -= lookD.y;
    camera.rotation.x = Math.max(-1.2, Math.min(1.2, camera.rotation.x));
    lookD.x = 0; lookD.y = 0;

    camera.getWorldDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    mover.position.addScaledVector(forward, joy.y * speed);
    mover.position.addScaledVector(right, joy.x * speed);
  } else if (controls && controls.isLocked) {
    controls.getDirection(forward);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0,1,0)).normalize();
    if (move.f) mover.position.addScaledVector(forward, speed);
    if (move.b) mover.position.addScaledVector(forward, -speed);
    if (move.l) mover.position.addScaledVector(right, -speed);
    if (move.r) mover.position.addScaledVector(right, speed);
  }

  // Bounds
  const halfL = CONFIG.corridorLength/2 - 1;
  const halfW = CONFIG.corridorWidth/2 - 0.7;
  mover.position.x = Math.max(-halfL, Math.min(halfL, mover.position.x));
  mover.position.z = Math.max(-halfW, Math.min(halfW, mover.position.z));

  // Floor height lock
  if (currentFloor !== 'Roof') {
    const targetY = (currentFloor - 1) * CONFIG.floorHeight + CONFIG.playerHeight;
    mover.position.y += (targetY - mover.position.y) * 0.3;
  }

  // PERF: only show current floor group (+ roof if needed)
  if (scene.userData.floorGroups) {
    const cf = currentFloor === 'Roof' ? CONFIG.floors : Number(currentFloor);
    scene.userData.floorGroups.forEach((g, i) => {
      const floorNum = i + 1;
      g.visible = (floorNum === cf || floorNum === cf - 1 || floorNum === cf + 1);
    });
  }

    updateElevatorRide(dt);

  // Hint when near elevator (no auto app panel)
  {
    const pos = camera.position;
    let inElev = false;
    if (currentFloor !== 'Roof') {
      for (const el of elevators) {
        if (el.floor !== currentFloor) continue;
        const wp = new THREE.Vector3();
        el.group.getWorldPosition(wp);
        // Standing at the wall elevator opening
        if (Math.abs(pos.x - wp.x) < 2.5 && Math.abs(pos.z - wp.z) < 2.2) {
          inElev = true;
          break;
        }
      }
      // Also detect by corridor ends
      const halfL = CONFIG.corridorLength / 2;
      if (Math.abs(Math.abs(pos.x) - halfL) < 2.8 && Math.abs(pos.z) < 2.5) {
        inElev = true;
      }
    }
    insideElevator = inElev;
    if (inElev && !elevPromptShown && !gameOver && !ridingElevator) {
      elevPromptShown = true;
      showMsg('INTERACT to open floor menu', 2000);
    }
    if (!inElev) elevPromptShown = false;
  }

  // No door animation — elevators always open


  updateMonsters(dt);

  // Part spin only every other frame feel — cheap
  parts.forEach(p => {
    if (!p.userData.collected) p.rotation.y += dt * 0.8;
  });

  renderer.render(scene, camera);
}

function setupUI() {
  // Elevator buttons – large, mobile-friendly
  const box = document.getElementById('elevator-buttons');
  if (box) box.innerHTML = '';
  for (let i = 1; i <= 10; i++) {
    const b = document.createElement('button');
    b.textContent = i;
    b.type = 'button';
    const go = (e) => { e.preventDefault(); goToFloor(i); };
    b.addEventListener('click', go);
    b.addEventListener('touchend', go, { passive: false });
    box.appendChild(b);
  }
  const roofBtn = document.createElement('button');
  roofBtn.textContent = 'ROOF';
  roofBtn.className = 'roof';
  roofBtn.type = 'button';
  const goRoof = (e) => { e.preventDefault(); goToFloor('roof'); };
  roofBtn.addEventListener('click', goRoof);
  roofBtn.addEventListener('touchend', goRoof, { passive: false });
  box.appendChild(roofBtn);

  document.getElementById('elevator-close').onclick = () => {
    elevatorUI.classList.add('hidden');
    elevatorOpen = false;
  };

  // FLOORS HUD button removed — use elevator in the hall

  document.getElementById('dialogue-close').onclick = () => dialogue.classList.add('hidden');
  document.getElementById('restart-btn').onclick = () => location.reload();

  if (stunBtn) {
    stunBtn.addEventListener('click', tryStun);
    stunBtn.addEventListener('touchstart', e => { e.preventDefault(); tryStun(); }, { passive: false });
  }
  const stunDesk = document.getElementById('stun-btn-desktop');
  if (stunDesk) {
    stunDesk.addEventListener('click', tryStun);
  }

  let p = 0;
  const iv = setInterval(() => {
    p += 15;
    progressEl.style.width = Math.min(p, 95) + '%';
    if (p >= 95) clearInterval(iv);
  }, 60);
}

init().catch(console.error);
